"""
Alert Manager
Manages alert creation, cooldown enforcement, storage persistence,
and integration with AlertStateManager for smart popup control.
"""

import time
import threading
import logging
from dataclasses import dataclass, field
from typing import Optional, Callable

from alerts.state_manager import alert_state_manager, AlertPhase
from config.settings import settings

logger = logging.getLogger(__name__)


@dataclass
class Alert:
    id:           str
    metric:       str
    severity:     str
    message:      str
    timestamp:    float = field(default_factory=time.time)
    acknowledged: bool  = False
    resolved:     bool  = False
    resolved_at:  Optional[float] = None
    diagnosis:    str   = ""


class AlertManager:
    """
    Creates and tracks alerts with cooldown-based deduplication.
    Integrates with AlertStateManager for intelligent popup control.
    Persists alert history to encrypted local storage.
    """

    def __init__(self):
        self._alerts:     list[Alert]      = []
        self._last_alert: dict[str, float] = {}
        self._lock        = threading.Lock()
        self._notification_callbacks: list[Callable] = []

        # Load persisted history
        self._restore()

    # ── Public interface ───────────────────────────────────────────────────

    def process_violations(self, violations: list, diagnosis: str = "") -> list[Alert]:
        """
        Process a list of ThresholdViolation objects.
        Returns newly created Alert objects (respecting cooldowns).
        """
        from agent.detector import ThresholdViolation
        new_alerts: list[Alert] = []
        now = time.time()

        with self._lock:
            for v in violations:
                cooldown_key = f"{v.metric}_{v.severity.value}"
                cooldowns    = settings.alert_cooldowns
                cooldown     = cooldowns.get(v.severity.value, 300)
                last_t       = self._last_alert.get(cooldown_key, 0)

                if now - last_t < cooldown:
                    continue  # Still in cooldown window

                alert = Alert(
                    id       = f"alert_{int(now*1000)}_{v.metric}",
                    metric   = v.metric,
                    severity = v.severity.value,
                    message  = v.message,
                    diagnosis= diagnosis,
                )
                self._alerts.append(alert)
                self._last_alert[cooldown_key] = now
                new_alerts.append(alert)

                # Enforce max history
                max_hist = settings.get("alerts", "max_history", default=100)
                if len(self._alerts) > max_hist:
                    self._alerts = self._alerts[-max_hist:]

                # Trigger smart popup state machine
                alert_state_manager.on_violation_detected(
                    metric    = v.metric,
                    severity  = v.severity.value,
                    message   = v.message,
                    alert_id  = alert.id,
                    diagnosis = diagnosis,
                )

                # Fire notification callbacks
                for cb in self._notification_callbacks:
                    try:
                        threading.Thread(
                            target = cb, args=(alert,), daemon=True
                        ).start()
                    except Exception as exc:
                        logger.debug(f"Notification callback error: {exc}")

        if new_alerts:
            self._persist()

        return new_alerts

    def acknowledge(self, alert_id: str) -> bool:
        with self._lock:
            for a in self._alerts:
                if a.id == alert_id:
                    a.acknowledged = True
                    self._persist()
                    alert_state_manager.on_user_acknowledged(alert_id)
                    return True
        return False

    def resolve(self, alert_id: str) -> bool:
        with self._lock:
            for a in self._alerts:
                if a.id == alert_id and not a.resolved:
                    a.resolved     = True
                    a.resolved_at  = time.time()
                    self._persist()
                    alert_state_manager.on_violation_cleared(a.metric)
                    return True
        return False

    def resolve_metric(self, metric: str):
        """Auto-resolve all active alerts for a metric."""
        with self._lock:
            changed = False
            for a in self._alerts:
                if a.metric == metric and not a.resolved:
                    a.resolved    = True
                    a.resolved_at = time.time()
                    changed = True
        if changed:
            self._persist()
            alert_state_manager.on_violation_cleared(metric)

    def get_active_alerts(self) -> list[Alert]:
        with self._lock:
            return [a for a in self._alerts if not a.resolved]

    def get_all_alerts(self, limit: int = 50) -> list[Alert]:
        with self._lock:
            return list(reversed(self._alerts[-limit:]))

    def get_alert_summary(self) -> dict:
        active   = self.get_active_alerts()
        critical = sum(1 for a in active if a.severity == "critical")
        warnings = sum(1 for a in active if a.severity == "warning")
        return {
            "total_active": len(active),
            "critical":     critical,
            "warnings":     warnings,
            "info":         len(active) - critical - warnings,
        }

    def add_notification_callback(self, fn: Callable):
        self._notification_callbacks.append(fn)

    # ── Persistence ────────────────────────────────────────────────────────

    def _persist(self):
        try:
            from utils.storage import get_storage
            store = get_storage()
            data  = [
                {
                    "id": a.id, "metric": a.metric, "severity": a.severity,
                    "message": a.message, "timestamp": a.timestamp,
                    "acknowledged": a.acknowledged, "resolved": a.resolved,
                    "resolved_at": a.resolved_at, "diagnosis": a.diagnosis,
                }
                for a in self._alerts[-100:]
            ]
            store.set("alerts", "history", data)
        except Exception as exc:
            logger.debug(f"Alert persistence error: {exc}")

    def _restore(self):
        try:
            from utils.storage import get_storage
            store = get_storage()
            data  = store.get("alerts", "history", default=[])
            self._alerts = [
                Alert(
                    id           = d["id"],
                    metric       = d["metric"],
                    severity     = d["severity"],
                    message      = d["message"],
                    timestamp    = d.get("timestamp", 0),
                    acknowledged = d.get("acknowledged", False),
                    resolved     = d.get("resolved", False),
                    resolved_at  = d.get("resolved_at"),
                    diagnosis    = d.get("diagnosis", ""),
                )
                for d in data
            ]
            logger.info(f"Restored {len(self._alerts)} alerts from storage")
        except Exception as exc:
            logger.debug(f"Alert restore error: {exc}")
            self._alerts = []
