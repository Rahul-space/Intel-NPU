"""
Configuration Manager
Loads config/config.json and exposes typed settings to the rest of the app.
Hot-reloads when the config file changes on disk.
"""

import json
import os
import sys
import logging
import threading
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ── Locate config file ─────────────────────────────────────────────────────
def _find_config_root() -> Path:
    """Return the project root whether running from source or as a .exe."""
    if getattr(sys, "frozen", False):
        # Inside PyInstaller bundle → config is next to the .exe
        return Path(sys.executable).parent
    # Running from source
    return Path(__file__).parent.parent


CONFIG_ROOT   = _find_config_root()
CONFIG_PATH   = CONFIG_ROOT / "config" / "config.json"
DEFAULT_CONFIG_PATH = Path(__file__).parent / "config.json"


class Settings:
    """
    Singleton settings object.
    Access any config value via dot-chained helpers or raw dict access.
    """

    _instance: Optional["Settings"] = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._data: dict = {}
                cls._instance._mtime: float = 0.0
                cls._instance._load()
        return cls._instance

    # ── Load / reload ──────────────────────────────────────────────────────

    def _load(self):
        """Load config from disk. Falls back to built-in defaults."""
        path = self._resolve_path()
        try:
            raw = path.read_text(encoding="utf-8")
            self._data  = json.loads(raw)
            self._mtime = path.stat().st_mtime
            logger.info(f"Config loaded from {path}")
        except Exception as exc:
            logger.warning(f"Config load failed ({exc}). Using built-in defaults.")
            self._data = self._built_in_defaults()

    def _resolve_path(self) -> Path:
        """Return path to an existing config file, creating one if missing."""
        if CONFIG_PATH.exists():
            return CONFIG_PATH
        # First run: copy default config next to exe / into project root
        try:
            CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
            if DEFAULT_CONFIG_PATH.exists():
                CONFIG_PATH.write_text(DEFAULT_CONFIG_PATH.read_text(encoding="utf-8"), encoding="utf-8")
                logger.info(f"Created config at {CONFIG_PATH}")
            else:
                CONFIG_PATH.write_text(json.dumps(self._built_in_defaults(), indent=2), encoding="utf-8")
        except Exception as exc:
            logger.warning(f"Could not write default config: {exc}")
        return CONFIG_PATH

    def reload_if_changed(self):
        """Call this periodically to pick up config file edits."""
        try:
            path = self._resolve_path()
            mtime = path.stat().st_mtime
            if mtime > self._mtime:
                logger.info("Config file changed — reloading")
                self._load()
        except Exception:
            pass

    # ── Typed accessors ────────────────────────────────────────────────────

    def get(self, *keys: str, default: Any = None) -> Any:
        """Nested key access. settings.get('thresholds','cpu','warning')."""
        node = self._data
        for k in keys:
            if isinstance(node, dict):
                node = node.get(k)
                if node is None:
                    return default
            else:
                return default
        return node

    # ── Convenience properties ─────────────────────────────────────────────

    @property
    def host(self) -> str:
        return self.get("server", "host", default="127.0.0.1")

    @property
    def port(self) -> int:
        return int(self.get("server", "port", default=8765))

    @property
    def dashboard_url(self) -> str:
        return f"http://{self.host}:{self.port}"

    @property
    def intervals(self) -> dict:
        return self.get("monitoring", "intervals", default={
            "cpu": 5, "memory": 10, "disk": 60,
            "network": 30, "gpu": 5, "processes": 10, "analysis": 15
        })

    @property
    def window_size(self) -> int:
        return int(self.get("monitoring", "window_size", default=12))

    @property
    def sustained_ratio(self) -> float:
        return float(self.get("monitoring", "sustained_ratio", default=0.70))

    @property
    def thresholds(self) -> dict:
        return self.get("thresholds", default={
            "cpu":             {"warning": 60.0, "critical": 85.0},
            "memory":          {"warning": 50.0, "critical": 80.0},
            "disk":            {"warning": 75.0, "critical": 90.0},
            "gpu":             {"warning": 60.0, "critical": 90.0},
            "network_latency": {"warning": 200.0, "critical": 500.0},
        })

    @property
    def health_weights(self) -> dict:
        return self.get("health_weights", default={
            "cpu": 0.30, "memory": 0.30, "disk": 0.20,
            "network": 0.10, "gpu": 0.10
        })

    @property
    def alert_cooldowns(self) -> dict:
        return self.get("alerts", "cooldown_seconds", default={
            "critical": 120, "warning": 300, "info": 600
        })

    @property
    def popup_reminder_seconds(self) -> int:
        return int(self.get("alerts", "popup_reminder_seconds", default=30))

    @property
    def auto_open_chatbot(self) -> bool:
        return bool(self.get("alerts", "auto_open_chatbot", default=True))

    @property
    def desktop_notifications(self) -> bool:
        return bool(self.get("alerts", "desktop_notifications", default=True))

    @property
    def ollama_host(self) -> str:
        return self.get("ai", "ollama_host", default="http://127.0.0.1:11434")

    @property
    def model_priority(self) -> list:
        return self.get("ai", "model_priority", default=["phi3", "phi3:mini"])

    @property
    def generation_options(self) -> dict:
        return self.get("ai", "generation", default={
            "temperature": 0.3, "top_p": 0.9, "top_k": 40,
            "num_predict": 1024, "num_ctx": 4096, "repeat_penalty": 1.1
        })

    @property
    def service_name(self) -> str:
        return self.get("service", "name", default="SysAssistAgent")

    @property
    def service_display_name(self) -> str:
        return self.get("service", "display_name", default="Workplace AI Monitoring Agent")

    @property
    def service_description(self) -> str:
        return self.get("service", "description", default="AI-powered endpoint monitoring agent")

    @property
    def log_level(self) -> str:
        return self.get("logging", "level", default="INFO")

    @property
    def log_max_bytes(self) -> int:
        return int(self.get("logging", "max_bytes", default=5_242_880))  # 5 MB

    @property
    def log_backup_count(self) -> int:
        return int(self.get("logging", "backup_count", default=5))

    @property
    def log_dir(self) -> Path:
        d = CONFIG_ROOT / self.get("logging", "log_dir", default="logs")
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def data_dir(self) -> Path:
        d = CONFIG_ROOT / self.get("storage", "data_dir", default="data")
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def encrypt_storage(self) -> bool:
        return bool(self.get("storage", "encrypt", default=True))

    @property
    def max_forecast_hours(self) -> int:
        return int(self.get("predictions", "max_forecast_hours", default=168))

    @property
    def min_samples_required(self) -> int:
        return int(self.get("predictions", "min_samples_required", default=4))

    # ── Update at runtime ──────────────────────────────────────────────────

    def update(self, *keys: str, value: Any):
        """Update a config value and write back to disk."""
        node = self._data
        for k in keys[:-1]:
            node = node.setdefault(k, {})
        node[keys[-1]] = value
        self._save()

    def _save(self):
        try:
            path = self._resolve_path()
            path.write_text(json.dumps(self._data, indent=2), encoding="utf-8")
        except Exception as exc:
            logger.error(f"Failed to save config: {exc}")

    # ── Built-in defaults (last resort) ───────────────────────────────────

    @staticmethod
    def _built_in_defaults() -> dict:
        return {
            "version": "2.2.0",
            "server": {"host": "127.0.0.1", "port": 8765, "auto_open_browser": True},
            "monitoring": {"intervals": {"cpu": 5, "memory": 10, "disk": 60, "network": 30, "gpu": 5, "processes": 10, "analysis": 15}, "window_size": 12, "sustained_ratio": 0.70},
            "thresholds": {"cpu": {"warning": 60.0, "critical": 85.0}, "memory": {"warning": 50.0, "critical": 80.0}, "disk": {"warning": 75.0, "critical": 90.0}, "gpu": {"warning": 60.0, "critical": 90.0}, "network_latency": {"warning": 200.0, "critical": 500.0}},
            "health_weights": {"cpu": 0.30, "memory": 0.30, "disk": 0.20, "network": 0.10, "gpu": 0.10},
            "alerts": {"cooldown_seconds": {"critical": 120, "warning": 300, "info": 600}, "popup_reminder_seconds": 30, "max_history": 100, "desktop_notifications": True, "auto_open_chatbot": True},
            "ai": {"ollama_host": "http://127.0.0.1:11434", "model_priority": ["phi3", "phi3:mini", "phi3:latest"], "generation": {"temperature": 0.3, "top_p": 0.9, "top_k": 40, "num_predict": 1024, "num_ctx": 4096, "repeat_penalty": 1.1}, "availability_check_interval": 30},
            "service": {"name": "SysAssistAgent", "display_name": "SysAssist AI Monitoring Agent", "description": "AI-powered endpoint monitoring agent", "start_type": "automatic"},
            "logging": {"level": "INFO", "max_bytes": 5242880, "backup_count": 5, "log_dir": "logs"},
            "storage": {"encrypt": True, "data_dir": "data"},
            "predictions": {"max_forecast_hours": 168, "min_samples_required": 4},
        }

    def to_dict(self) -> dict:
        return dict(self._data)


# ── Module-level singleton ─────────────────────────────────────────────────
settings = Settings()
