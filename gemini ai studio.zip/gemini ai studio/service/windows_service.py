"""
Windows Service Wrapper
Registers and runs SysAssist as a proper Windows NT service using pywin32.

The service:
  • Starts automatically on boot (before user login)
  • Runs the monitoring agent + FastAPI server in the background
  • Survives closing any terminal window
  • Controllable via Services.msc or sc.exe

Usage (from install_agent.py):
    python service/windows_service.py install
    python service/windows_service.py start
    python service/windows_service.py stop
    python service/windows_service.py remove
"""

import sys
import os
import time
import threading
import logging

# ── Ensure project root is on sys.path ────────────────────────────────────
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
if getattr(sys, "frozen", False):
    sys.path.insert(0, sys._MEIPASS)

# ── Mark as service mode (suppresses console log handler) ─────────────────
os.environ["SYSASSIST_SERVICE_MODE"] = "1"

# ── Windows event loop policy ──────────────────────────────────────────────
import platform
if platform.system() == "Windows":
    import asyncio as _asyncio
    _asyncio.set_event_loop_policy(_asyncio.WindowsProactorEventLoopPolicy())

import asyncio

try:
    import win32serviceutil
    import win32service
    import win32event
    import servicemanager
    import win32api
    _PYWIN32_AVAILABLE = True
except ImportError:
    _PYWIN32_AVAILABLE = False

logger = logging.getLogger("sysassist.service")


# ── Service class ──────────────────────────────────────────────────────────

if _PYWIN32_AVAILABLE:

    class SysAssistService(win32serviceutil.ServiceFramework):
        """Windows NT Service that hosts the SysAssist monitoring agent."""

        _svc_name_         = "SysAssistAgent"
        _svc_display_name_ = "SysAssist AI Monitoring Agent"
        _svc_description_  = (
            "AI-powered endpoint monitoring, anomaly detection, and "
            "automated remediation agent. Runs the SysAssist dashboard "
            "at http://127.0.0.1:8765."
        )

        def __init__(self, args):
            win32serviceutil.ServiceFramework.__init__(self, args)
            self._stop_event  = win32event.CreateEvent(None, 0, 0, None)
            self._agent_thread: threading.Thread = None
            self._loop: asyncio.AbstractEventLoop = None

        # ── Service control handlers ───────────────────────────────────────

        def SvcStop(self):
            logger.info("Service stop requested")
            self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
            win32event.SetEvent(self._stop_event)
            if self._loop and self._loop.is_running():
                self._loop.call_soon_threadsafe(self._loop.stop)

        def SvcDoRun(self):
            servicemanager.LogMsg(
                servicemanager.EVENTLOG_INFORMATION_TYPE,
                servicemanager.PYS_SERVICE_STARTED,
                (self._svc_name_, ""),
            )
            logger.info("SysAssist service starting …")
            self._run_agent()

        # ── Agent runner ───────────────────────────────────────────────────

        def _run_agent(self):
            """Start the full monitoring stack in a dedicated async loop."""
            try:
                self._setup_logging()
                from main import main as agent_main

                self._loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self._loop)

                self._agent_thread = threading.Thread(
                    target  = lambda: self._loop.run_until_complete(agent_main()),
                    daemon  = True,
                    name    = "sysassist-agent",
                )
                self._agent_thread.start()

                # Block the service main thread until stop is requested
                win32event.WaitForSingleObject(
                    self._stop_event,
                    win32event.INFINITE,
                )
            except Exception as exc:
                logger.exception(f"Service crashed: {exc}")
                servicemanager.LogErrorMsg(f"SysAssist service error: {exc}")

        def _setup_logging(self):
            from utils.logger import setup_logging
            from config.settings import settings
            setup_logging(
                level        = settings.log_level,
                log_dir      = settings.log_dir,
                max_bytes    = settings.log_max_bytes,
                backup_count = settings.log_backup_count,
            )


# ── Command-line helpers ───────────────────────────────────────────────────

def install_service():
    """Install the Windows service."""
    if not _PYWIN32_AVAILABLE:
        print("ERROR: pywin32 is not installed. Run: pip install pywin32")
        return False

    # Use the path to the current executable or script
    if getattr(sys, "frozen", False):
        exe = sys.executable
    else:
        exe = f'"{sys.executable}" "{os.path.abspath(__file__)}"'

    try:
        from config.settings import settings
        win32serviceutil.InstallService(
            pythonClassString = f"{__name__}.SysAssistService",
            serviceName       = settings.service_name,
            displayName       = settings.service_display_name,
            description       = settings.service_description,
            startType         = win32service.SERVICE_AUTO_START,
            exeName           = exe,
        )
        print(f"✓ Service '{settings.service_name}' installed")
        return True
    except Exception as exc:
        print(f"✗ Install failed: {exc}")
        return False


def start_service():
    if not _PYWIN32_AVAILABLE:
        return False
    try:
        from config.settings import settings
        win32serviceutil.StartService(settings.service_name)
        print(f"✓ Service '{settings.service_name}' started")
        return True
    except Exception as exc:
        print(f"✗ Start failed: {exc}")
        return False


def stop_service():
    if not _PYWIN32_AVAILABLE:
        return False
    try:
        from config.settings import settings
        win32serviceutil.StopService(settings.service_name)
        print(f"✓ Service '{settings.service_name}' stopped")
        return True
    except Exception as exc:
        print(f"✗ Stop failed: {exc}")
        return False


def remove_service():
    if not _PYWIN32_AVAILABLE:
        return False
    try:
        from config.settings import settings
        win32serviceutil.RemoveService(settings.service_name)
        print(f"✓ Service '{settings.service_name}' removed")
        return True
    except Exception as exc:
        print(f"✗ Remove failed: {exc}")
        return False


def service_status():
    if not _PYWIN32_AVAILABLE:
        return "pywin32 not available"
    try:
        from config.settings import settings
        status = win32serviceutil.QueryServiceStatus(settings.service_name)
        state_map = {
            win32service.SERVICE_STOPPED:          "STOPPED",
            win32service.SERVICE_START_PENDING:    "STARTING",
            win32service.SERVICE_STOP_PENDING:     "STOPPING",
            win32service.SERVICE_RUNNING:          "RUNNING",
            win32service.SERVICE_CONTINUE_PENDING: "RESUMING",
            win32service.SERVICE_PAUSE_PENDING:    "PAUSING",
            win32service.SERVICE_PAUSED:           "PAUSED",
        }
        return state_map.get(status[1], f"UNKNOWN({status[1]})")
    except Exception as exc:
        return f"NOT INSTALLED ({exc})"


# ── Entry point when run directly ─────────────────────────────────────────

if __name__ == "__main__":
    if not _PYWIN32_AVAILABLE:
        print("pywin32 is required for Windows service mode.")
        print("Install with: pip install pywin32")
        sys.exit(1)

    if len(sys.argv) == 1:
        # Called by SCM (Service Control Manager) — run the service
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(SysAssistService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        # Called from command line: install / start / stop / remove
        win32serviceutil.HandleCommandLine(SysAssistService)
