# """
# SysAssist — Universal Entry Point
# ===================================
# Handles all launch modes via CLI flags:

#   (no flags)       → Auto: tray + agent (development/user mode)
#   --agent          → Run monitoring agent + FastAPI only (service mode)
#   --tray           → Run system tray only (assumes agent already running)
#   --install        → Install Windows service + startup entry
#   --uninstall      → Remove Windows service + startup entry
#   --service        → Called by Windows SCM (internal, do not use directly)
#   --headless       → Agent + browser, no tray icon

# The .exe built by PyInstaller calls this file.
# Windows Service Control Manager calls this file with no args (routes to --service).
# """

# # ── MUST be first ──────────────────────────────────────────────────────────
# import multiprocessing
# multiprocessing.freeze_support()

# import sys
# import os
# import platform

# # ── Path fix ───────────────────────────────────────────────────────────────
# if getattr(sys, "frozen", False):
#     sys.path.insert(0, sys._MEIPASS)
#     sys.path.insert(0, os.path.dirname(sys.executable))
# else:
#     sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# # ── Windows event-loop policy ──────────────────────────────────────────────
# if platform.system() == "Windows":
#     import asyncio as _asyncio
#     _asyncio.set_event_loop_policy(_asyncio.WindowsProactorEventLoopPolicy())

# import asyncio
# import threading
# import webbrowser
# import time
# import socket
# import logging


# # ── Logging (lazy — avoid importing settings before path is fixed) ─────────
# def _bootstrap_logging():
#     try:
#         from utils.logger import setup_logging, CrashHandler
#         from config.settings import settings
#         log = setup_logging(
#             level        = settings.log_level,
#             log_dir      = settings.log_dir,
#             max_bytes    = settings.log_max_bytes,
#             backup_count = settings.log_backup_count,
#         )
#         CrashHandler(log)
#         return log
#     except Exception:
#         logging.basicConfig(level=logging.INFO,
#                             format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")
#         return logging.getLogger("sysassist")


# # ── Core agent runner ──────────────────────────────────────────────────────

# def _run_uvicorn(app) -> None:
#     import uvicorn
#     loop = asyncio.new_event_loop()
#     asyncio.set_event_loop(loop)
#     config = uvicorn.Config(
#         app,
#         host       = "127.0.0.1",
#         port       = _get_port(),
#         log_level  = "warning",
#         loop       = "asyncio",
#         reload     = False,
#         access_log = False,
#     )
#     server = uvicorn.Server(config)
#     loop.run_until_complete(server.serve())


# def _get_port() -> int:
#     try:
#         from config.settings import settings
#         return settings.port
#     except Exception:
#         return 8765


# def _wait_for_server(timeout: float = 20.0) -> bool:
#     deadline = time.time() + timeout
#     while time.time() < deadline:
#         try:
#             with socket.create_connection(("127.0.0.1", _get_port()), timeout=0.5):
#                 return True
#         except (ConnectionRefusedError, OSError):
#             time.sleep(0.25)
#     return False


# async def _run_agent_core(open_browser: bool = True):
#     """Core async function: starts scheduler + FastAPI server."""
#     from config.settings import settings
#     from agent.scheduler import MetricScheduler
#     from alerts.manager  import AlertManager
#     from alerts.state_manager import alert_state_manager
#     from api.server      import create_app

#     logger = logging.getLogger("sysassist.main")
#     logger.info("Initialising monitoring agent …")

#     scheduler     = MetricScheduler()
#     alert_manager = AlertManager()
#     alert_state_manager.start()

#     app = create_app(scheduler, alert_manager)

#     server_thread = threading.Thread(
#         target  = _run_uvicorn,
#         args    = (app,),
#         daemon  = True,
#         name    = "uvicorn",
#     )
#     server_thread.start()
#     logger.info("Uvicorn started in background thread")

#     if _wait_for_server(20.0):
#         logger.info(f"✓ Dashboard at {settings.dashboard_url}")
#         if open_browser:
#             await asyncio.sleep(1.0)
#             webbrowser.open(settings.dashboard_url)
#     else:
#         logger.error("Server did not start in 20 s — check logs")

#     # Hot-reload config every 60 s
#     async def _config_reload():
#         while True:
#             await asyncio.sleep(60)
#             settings.reload_if_changed()

#     asyncio.create_task(_config_reload())

#     logger.info("Metric scheduler running …")
#     await scheduler.start()


# # ── Launch mode functions ──────────────────────────────────────────────────

# def run_agent(open_browser: bool = False):
#     """Run the monitoring agent (FastAPI + scheduler) — no tray, no browser."""
#     _bootstrap_logging()
#     logger = logging.getLogger("sysassist.main")
#     logger.info("Starting in AGENT mode (service/headless)")

#     def _thread():
#         loop = asyncio.new_event_loop()
#         asyncio.set_event_loop(loop)
#         try:
#             loop.run_until_complete(_run_agent_core(open_browser=open_browser))
#         except Exception as exc:
#             logger.exception(f"Agent crashed: {exc}")
#         finally:
#             loop.close()

#     t = threading.Thread(target=_thread, daemon=False, name="agent-main")
#     t.start()
#     t.join()


# def run_full(open_browser: bool = True):
#     """Run agent + tray in the same process (development / user-install mode)."""
#     log = _bootstrap_logging()
#     logger = logging.getLogger("sysassist.main")
#     logger.info("Starting in FULL mode (agent + tray)")

#     _print_banner()

#     # Start agent in background thread
#     def _agent_thread():
#         loop = asyncio.new_event_loop()
#         asyncio.set_event_loop(loop)
#         try:
#             loop.run_until_complete(_run_agent_core(open_browser=False))
#         except Exception as exc:
#             logger.exception(f"Agent crashed: {exc}")

#     agent_t = threading.Thread(target=_agent_thread, daemon=True, name="agent")
#     agent_t.start()

#     # Wait for server then launch tray (tray blocks main thread)
#     _wait_for_server(25.0)

#     if open_browser:
#         try:
#             from config.settings import settings
#             webbrowser.open(settings.dashboard_url)
#         except Exception:
#             pass

#     try:
#         from tray_app import main as tray_main
#         tray_main()
#     except ImportError:
#         logger.warning("tray_app not available — running headless")
#         agent_t.join()


# def run_tray_only():
#     """Run tray only — assumes agent backend is already running."""
#     _bootstrap_logging()
#     from tray_app import main as tray_main
#     tray_main()


# def run_install():
#     _bootstrap_logging()
#     from install_agent import main as install_main
#     install_main()


# def run_uninstall():
#     _bootstrap_logging()
#     from uninstall_agent import main as uninstall_main
#     uninstall_main()


# def run_as_service():
#     """Called by Windows SCM — hand off to the service wrapper."""
#     os.environ["SYSASSIST_SERVICE_MODE"] = "1"
#     _bootstrap_logging()
#     try:
#         import servicemanager
#         from service.windows_service import SysAssistService
#         servicemanager.Initialize()
#         servicemanager.PrepareToHostSingle(SysAssistService)
#         servicemanager.StartServiceCtrlDispatcher()
#     except ImportError:
#         # pywin32 not installed — fall back to headless agent
#         run_agent(open_browser=False)


# # ── Banner ─────────────────────────────────────────────────────────────────

# def _print_banner():
#     try:
#         from config.settings import settings
#         url = settings.dashboard_url
#     except Exception:
#         url = "http://127.0.0.1:8765"
#     print(f"""
# ╔══════════════════════════════════════════════════════════╗
# ║          SysAssist AI  ·  v2.2.0                         ║
# ║     Endpoint Monitoring & Remediation Agent              ║
# ╠══════════════════════════════════════════════════════════╣
# ║  Engine   : Phi-3 via Ollama (local, offline-capable)    ║
# ║  Dashboard: {url:<44s}║
# ║  Press Ctrl+C or use tray icon to stop                   ║
# ╚══════════════════════════════════════════════════════════╝
# """)


# # ── CLI routing ────────────────────────────────────────────────────────────

# def main():
#     args = set(sys.argv[1:])

#     if "--install" in args:
#         run_install()

#     elif "--uninstall" in args:
#         run_uninstall()

#     elif "--agent" in args:
#         # Pure agent mode (no tray, no browser) — used by Windows service
#         run_agent(open_browser=False)

#     elif "--tray" in args:
#         # Tray only — backend assumed to be running (launched by service)
#         run_tray_only()

#     elif "--headless" in args:
#         # Agent + browser, no tray
#         run_agent(open_browser=True)

#     elif "--service" in args or len(sys.argv) == 1 and os.environ.get("SYSASSIST_SERVICE_MODE") == "1":
#         # Windows SCM called us
#         run_as_service()

#     else:
#         # Default: full mode (agent + tray + browser)
#         run_full(open_browser=True)


# if __name__ == "__main__":
#     try:
#         main()
#     except KeyboardInterrupt:
#         logging.getLogger("sysassist").info("Shutdown — goodbye!")
#     except Exception as exc:
#         logging.getLogger("sysassist").exception(f"Fatal: {exc}")
#         if getattr(sys, "frozen", False):
#             input("\nPress Enter to close …")









# ── MUST be first ─────────────────────────────────────────────
import multiprocessing
multiprocessing.freeze_support()

import sys
import os
import platform
import asyncio
import threading
import webbrowser
import time
import socket
import logging
import signal

# ── SINGLE INSTANCE LOCK ─────────────────────────────────────
_instance_socket = None

def _ensure_single_instance():
    global _instance_socket
    _instance_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        _instance_socket.bind(("127.0.0.1", 65432))
    except OSError:
        print("⚠️ Another instance already running. Exiting...")
        sys.exit(0)


# ── GLOBAL SHUTDOWN EVENT ────────────────────────────────────
shutdown_event = threading.Event()

def _handle_shutdown(signum, frame):
    logging.getLogger("sysassist").info(f"Shutdown signal received: {signum}")
    shutdown_event.set()


# Register signals
signal.signal(signal.SIGINT, _handle_shutdown)
signal.signal(signal.SIGTERM, _handle_shutdown)


# ── Path Fix ─────────────────────────────────────────────────
if getattr(sys, "frozen", False):
    sys.path.insert(0, sys._MEIPASS)
    sys.path.insert(0, os.path.dirname(sys.executable))
else:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ── Windows Event Loop Fix ───────────────────────────────────
if platform.system() == "Windows":
    import asyncio as _asyncio
    _asyncio.set_event_loop_policy(_asyncio.WindowsProactorEventLoopPolicy())


# ── Logging ─────────────────────────────────────────────────
def _bootstrap_logging():
    try:
        from utils.logger import setup_logging, CrashHandler
        from config.settings import settings

        log = setup_logging(
            level=settings.log_level,
            log_dir=settings.log_dir,
            max_bytes=settings.log_max_bytes,
            backup_count=settings.log_backup_count,
        )
        CrashHandler(log)
        return log
    except Exception:
        logging.basicConfig(level=logging.INFO)
        return logging.getLogger("sysassist")


# ── SERVER ──────────────────────────────────────────────────
def _get_port():
    try:
        from config.settings import settings
        return settings.port
    except:
        return 8765


def _run_uvicorn(app):
    import uvicorn

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    config = uvicorn.Config(
        app,
        host="127.0.0.1",
        port=_get_port(),
        log_level="warning",
        access_log=False,
    )

    server = uvicorn.Server(config)
    loop.run_until_complete(server.serve())


def _wait_for_server(timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", _get_port()), timeout=1):
                return True
        except:
            time.sleep(0.3)
    return False


# ── AGENT CORE ──────────────────────────────────────────────
_browser_opened = False

async def _run_agent_core(open_browser=True):
    global _browser_opened

    from config.settings import settings
    from agent.scheduler import MetricScheduler
    from alerts.manager import AlertManager
    from alerts.state_manager import alert_state_manager
    from api.server import create_app

    logger = logging.getLogger("sysassist")

    scheduler = MetricScheduler()
    alert_manager = AlertManager()
    alert_state_manager.start()

    app = create_app(scheduler, alert_manager)

    # Start API server
    server_thread = threading.Thread(
        target=_run_uvicorn,
        args=(app,),
        daemon=True
    )
    server_thread.start()

    if _wait_for_server():
        logger.info(f"Dashboard ready at {settings.dashboard_url}")

        if open_browser and not _browser_opened:
            _browser_opened = True
            webbrowser.open(settings.dashboard_url)

    # Run scheduler
    task = asyncio.create_task(scheduler.start())

    # Wait for shutdown
    while not shutdown_event.is_set():
        await asyncio.sleep(1)

    logger.info("Shutting down agent...")

    task.cancel()
    try:
        await task
    except:
        pass


# ── MODES ───────────────────────────────────────────────────
def run_agent(open_browser=False):
    _bootstrap_logging()

    def _thread():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(_run_agent_core(open_browser))

    t = threading.Thread(target=_thread)
    t.start()
    t.join()


def run_full(open_browser=True):
    logger = _bootstrap_logging()

    # Start agent
    def _agent_thread():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(_run_agent_core(open_browser=False))

    agent_t = threading.Thread(target=_agent_thread, daemon=True)
    agent_t.start()

    _wait_for_server()

    if open_browser:
        from config.settings import settings
        webbrowser.open(settings.dashboard_url)

    try:
        from tray_app import main as tray_main
        tray_main()
    except Exception as e:
        logger.exception("Tray crashed — not restarting")


def run_tray_only():
    _bootstrap_logging()
    from tray_app import main as tray_main
    tray_main()


def run_install():
    _bootstrap_logging()
    from install_agent import main as install_main
    install_main()


def run_uninstall():
    _bootstrap_logging()
    from uninstall_agent import main as uninstall_main
    uninstall_main()


def run_as_service():
    os.environ["SYSASSIST_SERVICE_MODE"] = "1"
    _bootstrap_logging()

    try:
        import servicemanager
        from service.windows_service import SysAssistService

        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(SysAssistService)
        servicemanager.StartServiceCtrlDispatcher()

    except ImportError:
        run_agent(False)


# ── MAIN ────────────────────────────────────────────────────
def main():
    _ensure_single_instance()

    args = set(sys.argv[1:])

    if "--install" in args:
        run_install()

    elif "--uninstall" in args:
        run_uninstall()

    elif "--agent" in args:
        run_agent(False)

    elif "--tray" in args:
        run_tray_only()

    elif "--headless" in args:
        run_agent(True)

    elif "--service" in args or (
        len(sys.argv) == 1 and os.environ.get("SYSASSIST_SERVICE_MODE") == "1"
    ):
        run_as_service()

    else:
        run_full(True)


# ── ENTRY ───────────────────────────────────────────────────
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.exception(f"Fatal error: {e}")