#!/usr/bin/env python3
"""
copy_renderer.py
================
Copies the existing ui/index.html to renderer/index.html
and injects the Electron-specific enhancements:

1. Removes the <head> Google Fonts link (works offline in Electron)
2. Adds Electron window controls (min/max/close) to the topbar
3. Adds CSP meta tag
4. Makes all fetch() calls use the absolute backend URL
   (needed because Electron loads from file:// in production)

Run this after modifying ui/index.html to keep renderer/ in sync.
"""

import re
from pathlib import Path

SRC  = Path(__file__).parent / "ui" / "index.html"
DEST = Path(__file__).parent / "renderer" / "index.html"
DEST.parent.mkdir(parents=True, exist_ok=True)

html = SRC.read_text(encoding="utf-8")

# ── 1. Add CSP for Electron (allow localhost API calls) ─────────────
csp = '''<meta http-equiv="Content-Security-Policy"
      content="default-src 'self' http://127.0.0.1:8765 ws://127.0.0.1:8765; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com data:"/>'''

html = html.replace("<meta charset=\"UTF-8\"/>",
                    "<meta charset=\"UTF-8\"/>\n" + csp)

# ── 2. Inject Electron window control buttons in topbar ─────────────
# Add drag region style and window controls
topbar_patch = """
  <!-- Electron: make topbar draggable -->
  <style>
    .topbar { -webkit-app-region: drag; }
    .topbar-actions, .topbar-badge, .topbar-online, .nav-item, .icon-btn, .avatar,
    button, input, textarea, select, .collapse-btn, .metric-card,
    .chat-input-area, .proc-toolbar, #diagnosis-overlay { -webkit-app-region: no-drag; }

    /* Electron window control buttons */
    .el-controls {
      display: flex; align-items: center; gap: 4px;
      -webkit-app-region: no-drag;
      margin-left: 4px;
    }
    .el-btn {
      width: 28px; height: 22px;
      border-radius: 4px;
      border: 1px solid rgba(255,255,255,0.06);
      background: rgba(255,255,255,0.04);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer; color: #7a8094; font-size: 11px;
      transition: all 0.15s;
    }
    .el-btn:hover { background: rgba(255,255,255,0.1); color: #e8eaf0; }
    .el-btn.close:hover { background: rgba(239,68,68,0.15); color: #ef4444; border-color: rgba(239,68,68,0.3); }
    body { -webkit-user-select: none; }
    .chat-input, .proc-search, input, textarea { -webkit-user-select: text; }

    /* No border radius on window in Electron (OS handles it) */
    body { border-radius: 0; }
  </style>
"""
html = html.replace("</head>", topbar_patch + "\n</head>")

# ── 3. Add window control buttons to topbar HTML ────────────────────
el_controls = """    <div class="el-controls" id="el-win-controls">
      <div class="el-btn" onclick="elMinimize()" title="Minimize">─</div>
      <div class="el-btn" onclick="elMaximize()" title="Maximize">□</div>
      <div class="el-btn close" onclick="elClose()" title="Hide to tray">✕</div>
    </div>"""

html = html.replace("</header>", el_controls + "\n  </header>")

# ── 4. Inject Electron JS bridge at end of <script> block ───────────
electron_js = """
// ═══════════════════════════════════════════════
//  ELECTRON INTEGRATION
// ═══════════════════════════════════════════════
const IS_ELECTRON = !!(window.electronAPI);
const API_BASE    = IS_ELECTRON ? 'http://127.0.0.1:8765' : '';

// Override fetch to use absolute URL in Electron
if (IS_ELECTRON) {
  const _origFetch = window.fetch;
  window.fetch = function(url, opts) {
    if (typeof url === 'string' && url.startsWith('/')) {
      url = API_BASE + url;
    }
    return _origFetch(url, opts);
  };

  // Override WebSocket URL
  const _OrigWS = window.WebSocket;
  window.WebSocket = function(url, protocols) {
    if (url.startsWith('ws://') && url.includes('localhost')) return new _OrigWS(url, protocols);
    if (url.startsWith('/ws') || url === 'ws') url = `ws://127.0.0.1:8765/ws`;
    return new _OrigWS(url, protocols);
  };
}

// Window controls
function elMinimize() { /* Electron handles via OS */ }
function elMaximize() { /* Electron handles via OS */ }
function elClose() {
  if (window.electronAPI) window.electronAPI.hideDashboard();
  else window.close();
}

// Show/hide window controls only in Electron
document.addEventListener('DOMContentLoaded', () => {
  const controls = document.getElementById('el-win-controls');
  if (!IS_ELECTRON && controls) controls.style.display = 'none';
});
"""
html = html.replace("</script>", electron_js + "\n</script>")

DEST.write_text(html, encoding="utf-8")
print(f"  ✓  renderer/index.html created ({DEST.stat().st_size // 1024} KB)")
print(f"  ✓  Electron: drag region, CSP, window controls, API URL patching")


if __name__ == "__main__":
    main_html = SRC
    if not main_html.exists():
        print(f"  ✗  Source not found: {main_html}")
        exit(1)
    print(f"\n  Patching {SRC.name} → {DEST}\n")
