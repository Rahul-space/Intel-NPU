# -*- mode: python ; coding: utf-8 -*-
"""
SysAssist PyInstaller Spec  —  v2.2.0
======================================
Produces a single SysAssist.exe that handles ALL modes:

    SysAssist.exe               → Full mode: agent + tray + browser
    SysAssist.exe --install     → Install Windows service + startup
    SysAssist.exe --uninstall   → Remove service + startup
    SysAssist.exe --agent       → Agent only (called by Windows service)
    SysAssist.exe --tray        → Tray only (called after service starts)
    SysAssist.exe --headless    → Agent + browser, no tray

AV-SAFE SETTINGS:
  upx = False          → UPX disabled: #1 cause of AV false positives
  console = True       → Keep console visible during testing; set False for prod
  uac_admin = False    → No UAC prompt on launch; install_agent requests elevation
"""

from pathlib import Path
block_cipher = None
ROOT = Path(SPECPATH)

# ── Collect package data ───────────────────────────────────────────────────
try:
    from PyInstaller.utils.hooks import collect_data_files, collect_submodules
    _starlette_data = collect_data_files("starlette")
    _plyer_data     = collect_data_files("plyer")
except Exception:
    _starlette_data = []
    _plyer_data     = []

datas = [
    (str(ROOT / "ui"),             "ui"),
    (str(ROOT / "config"),         "config"),
] + _starlette_data + _plyer_data

hiddenimports = [
    # ── asyncio / Windows event loop ───────────────────────────────────────
    "asyncio",
    "asyncio.windows_events",
    "asyncio.windows_utils",
    "asyncio.base_events",
    "asyncio.tasks",
    "asyncio.futures",

    # ── uvicorn ────────────────────────────────────────────────────────────
    "uvicorn", "uvicorn.main", "uvicorn.config", "uvicorn.logging",
    "uvicorn.loops", "uvicorn.loops.auto", "uvicorn.loops.asyncio",
    "uvicorn.protocols", "uvicorn.protocols.http", "uvicorn.protocols.http.auto",
    "uvicorn.protocols.http.h11_impl",
    "uvicorn.protocols.websockets", "uvicorn.protocols.websockets.auto",
    "uvicorn.protocols.websockets.websockets_impl",
    "uvicorn.protocols.websockets.wsproto_impl",
    "uvicorn.lifespan", "uvicorn.lifespan.on", "uvicorn.lifespan.off",
    "uvicorn.supervisors",

    # ── HTTP/WS ─────────────────────────────────────────────────────────────
    "h11", "h11._connection", "h11._events", "h11._readers", "h11._writers",
    "websockets", "websockets.legacy", "websockets.legacy.server",
    "websockets.legacy.client", "websockets.frames",
    "wsproto", "wsproto.connection", "wsproto.events", "wsproto.frame_protocol",

    # ── FastAPI / Starlette ────────────────────────────────────────────────
    "fastapi", "fastapi.routing", "fastapi.responses", "fastapi.middleware",
    "fastapi.middleware.cors", "fastapi.staticfiles", "fastapi.websockets",
    "starlette", "starlette.routing", "starlette.requests", "starlette.responses",
    "starlette.websockets", "starlette.middleware", "starlette.middleware.cors",
    "starlette.staticfiles", "starlette.background", "starlette.concurrency",
    "starlette.datastructures", "starlette.exceptions", "starlette.types",
    "anyio", "anyio._backends._asyncio", "anyio.abc", "sniffio",

    # ── Pydantic ───────────────────────────────────────────────────────────
    "pydantic", "pydantic.v1", "pydantic_core",
    "pydantic.deprecated.class_validators",

    # ── psutil ─────────────────────────────────────────────────────────────
    "psutil", "psutil._pswindows", "psutil._pslinux", "psutil._psosx",
    "psutil._psposix", "psutil._psutil_windows", "psutil._common",

    # ── cryptography (encrypted storage) ──────────────────────────────────
    "cryptography", "cryptography.fernet",
    "cryptography.hazmat", "cryptography.hazmat.primitives",
    "cryptography.hazmat.primitives.ciphers",
    "cryptography.hazmat.primitives.hashes",
    "cryptography.hazmat.primitives.padding",
    "cryptography.hazmat.backends",
    "cryptography.hazmat.backends.openssl",

    # ── plyer (desktop notifications) ─────────────────────────────────────
    "plyer", "plyer.platforms",
    "plyer.platforms.win", "plyer.platforms.win.notification",
    "plyer.platforms.macosx", "plyer.platforms.macosx.notification",
    "plyer.platforms.linux", "plyer.platforms.linux.notification",

    # ── pystray (system tray) ──────────────────────────────────────────────
    "pystray", "pystray._win32", "pystray._darwin", "pystray._gtk",
    "pystray._appindicator",

    # ── Pillow (tray icon drawing) ─────────────────────────────────────────
    "PIL", "PIL.Image", "PIL.ImageDraw", "PIL.ImageFont", "PIL.ImageFilter",

    # ── pywin32 (Windows service) ──────────────────────────────────────────
    "win32serviceutil", "win32service", "win32event",
    "servicemanager", "win32api", "win32con",
    "pywintypes", "win32security",

    # ── winreg (startup registration) ─────────────────────────────────────
    "winreg",

    # ── Standard library (PyInstaller sometimes misses these) ─────────────
    "platform", "subprocess", "socket", "shutil", "tempfile",
    "threading", "multiprocessing", "multiprocessing.freeze_support",
    "queue", "collections", "dataclasses", "enum", "pathlib",
    "urllib", "urllib.request", "urllib.error", "urllib.parse",
    "json", "logging", "logging.handlers", "time", "os", "sys",
    "hashlib", "base64", "ctypes", "ctypes.windll",
    "webbrowser", "winreg",

    # ── Project packages ───────────────────────────────────────────────────
    "config", "config.settings",
    "utils", "utils.logger", "utils.storage",
    "agent", "agent.buffer", "agent.collector", "agent.detector",
    "agent.analyzer", "agent.health", "agent.context_builder", "agent.scheduler",
    "ai", "ai.diagnostic",
    "api", "api.server",
    "alerts", "alerts.manager", "alerts.state_manager",
    "remediation", "remediation.actions",
    "service", "service.windows_service",
    "tray_app", "install_agent", "uninstall_agent",
]

a = Analysis(
    [str(ROOT / "main.py")],
    pathex        = [str(ROOT)],
    binaries      = [],
    datas         = datas,
    hiddenimports = hiddenimports,
    hookspath     = [],
    hooksconfig   = {},
    runtime_hooks = [],
    excludes      = [
        "tkinter", "matplotlib", "numpy", "scipy", "pandas",
        "cv2", "jupyter", "IPython", "notebook", "test", "unittest", "doctest",
        "anthropic", "httpx", "httpcore", "openai", "aiohttp", "requests", "boto3",
    ],
    win_no_prefer_redirects = False,
    win_private_assemblies  = False,
    cipher                  = block_cipher,
    noarchive               = False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name         = "SysAssist",
    debug        = False,
    bootloader_ignore_signals = False,
    strip        = False,

    # ── AV safety: UPX disabled ────────────────────────────────────────────
    upx          = False,
    upx_exclude  = [],

    runtime_tmpdir = None,

    # Keep console=True while validating .exe works.
    # Change to False for silent production builds.
    console      = True,

    disable_windowed_traceback = False,
    target_arch  = None,
    codesign_identity   = None,
    entitlements_file   = None,

    # Windows metadata
    icon         = None,    # str(ROOT / "assets" / "icon.ico")
    uac_admin    = False,   # install_agent.py requests elevation itself
    uac_uiaccess = False,
)
