"""
Workplace Assist — Application Collector
Aggregates process data into application-level insights with 60-min timeline.
"""
import logging, re, time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional
import psutil

logger = logging.getLogger(__name__)

_APP_NAME_MAP = {
    "chrome":"Google Chrome","msedge":"Microsoft Edge","firefox":"Mozilla Firefox",
    "opera":"Opera","brave":"Brave Browser","iexplore":"Internet Explorer",
    "code":"VS Code","pycharm":"PyCharm","idea":"IntelliJ IDEA","devenv":"Visual Studio",
    "eclipse":"Eclipse","webstorm":"WebStorm","vim":"Vim","nvim":"Neovim",
    "outlook":"Microsoft Outlook","excel":"Microsoft Excel","winword":"Microsoft Word",
    "powerpnt":"Microsoft PowerPoint","onenote":"OneNote","teams":"Microsoft Teams",
    "slack":"Slack","zoom":"Zoom","skype":"Skype","notion":"Notion",
    "explorer":"Windows Explorer","svchost":"Windows Services","lsass":"Windows Security",
    "dwm":"Desktop Window Manager","searchindexer":"Windows Search",
    "onedrive":"OneDrive","dropbox":"Dropbox","googledrivefs":"Google Drive",
    "vlc":"VLC Media Player","spotify":"Spotify","discord":"Discord",
    "msmpeng":"Windows Defender","mcshield":"McAfee","avgnt":"Avast",
    "windowsterminal":"Windows Terminal","powershell":"PowerShell","cmd":"Command Prompt",
    "bash":"Bash Shell","node":"Node.js","python":"Python","python3":"Python",
    "java":"Java","docker":"Docker Desktop","postgres":"PostgreSQL",
    "mysql":"MySQL","mongod":"MongoDB","redis-server":"Redis","nginx":"Nginx",
}

_DEVICE_CLASS_THRESHOLDS = {
    "high": {"cpu_warn":20.0,"cpu_crit":40.0,"mem_gb_warn":2.0,"mem_gb_crit":4.0},
    "mid":  {"cpu_warn":12.0,"cpu_crit":25.0,"mem_gb_warn":1.0,"mem_gb_crit":2.0},
    "low":  {"cpu_warn": 6.0,"cpu_crit":12.0,"mem_gb_warn":0.5,"mem_gb_crit":1.0},
}

def _resolve_name(proc_name:str)->str:
    base=re.sub(r'\.(exe|app|bin|py|sh)$','',proc_name.lower().strip())
    return _APP_NAME_MAP.get(base, proc_name.split('.')[0].title())

def _device_class(ram_gb:float, cores:int)->str:
    score=ram_gb+cores*2
    return "high" if score>=24 else "mid" if score>=12 else "low"

@dataclass
class AppSample:
    ts:float; cpu:float; mem_mb:float; active:bool; anomaly:bool=False

@dataclass
class AppInsight:
    name:str
    cpu_now:float=0.0; mem_mb_now:float=0.0
    health_score:int=100; health_label:str="Healthy"; health_color:str="green"
    device_class:str="mid"; baseline_cpu:float=12.0; behavior:str="Normal"
    proc_count:int=0
    history:deque=field(default_factory=lambda:deque(maxlen=60))

    @property
    def history_list(self)->List[dict]:
        return [{"ts":s.ts,"cpu":s.cpu,"mem":s.mem_mb,"active":s.active,"anomaly":s.anomaly}
                for s in self.history]

class AppCollector:
    ACTIVITY_THRESHOLD=0.5

    def __init__(self):
        self._apps:Dict[str,AppInsight]={}
        self._device_class="mid"
        self._thresholds=_DEVICE_CLASS_THRESHOLDS["mid"]
        self._detect_device()

    def _detect_device(self):
        try:
            ram=psutil.virtual_memory().total/1e9
            cores=psutil.cpu_count(logical=False) or 2
            self._device_class=_device_class(ram,cores)
            self._thresholds=_DEVICE_CLASS_THRESHOLDS[self._device_class]
        except Exception: pass

    def collect(self, raw_procs:Optional[List[dict]]=None)->Dict[str,AppInsight]:
        now=time.time()
        procs=raw_procs or self._query_procs()
        grouped:dict=defaultdict(list)
        for p in procs:
            pname = p.get("name","Unknown") if isinstance(p,dict) else getattr(p,"name","Unknown")
            grouped[_resolve_name(pname)].append(p)

        for app_name,group in grouped.items():
            def _v(p,k,d=0):
                return p.get(k,d) if isinstance(p,dict) else getattr(p,k,d)
            agg_cpu=sum(_v(p,"cpu_percent") for p in group)
            agg_mem=sum(_v(p,"memory_mb")   for p in group)
            if app_name not in self._apps:
                ai=AppInsight(name=app_name,device_class=self._device_class,
                              baseline_cpu=self._thresholds["cpu_warn"])
                # Pre-fill 59 idle buckets so timeline shows full 1-hour window
                for i in range(59):
                    ai.history.appendleft(AppSample(ts=now-(59-i)*60,cpu=0,mem_mb=0,active=False))
                self._apps[app_name]=ai
            app=self._apps[app_name]
            app.cpu_now=round(agg_cpu,2); app.mem_mb_now=round(agg_mem,1)
            app.proc_count=len(group)
            is_anom=agg_cpu>self._thresholds["cpu_crit"]
            is_act=agg_cpu>self.ACTIVITY_THRESHOLD
            app.history.append(AppSample(ts=now,cpu=round(agg_cpu,2),mem_mb=round(agg_mem,1),
                                          active=is_act,anomaly=is_anom))
            cpu_r=min(agg_cpu/max(self._thresholds["cpu_crit"],1),1)
            mem_r=min(agg_mem/(self._thresholds["mem_gb_crit"]*1024),1)
            score=max(0,int(100-cpu_r*60-mem_r*40))
            app.health_score=score
            if score>=80: app.health_label="Healthy"; app.health_color="green"
            elif score>=55: app.health_label="Moderate"; app.health_color="orange"
            else: app.health_label="Critical"; app.health_color="red"
            if agg_cpu>self._thresholds["cpu_crit"]: app.behavior="High Load"
            elif agg_cpu>self._thresholds["cpu_warn"]: app.behavior="Elevated"
            elif all(s.cpu<0.5 for s in list(app.history)[-5:]): app.behavior="Background"
            else: app.behavior="Normal" if agg_cpu>0.5 else "Idle"
        return self._apps

    def _query_procs(self)->List[dict]:
        result=[]
        for p in psutil.process_iter(['pid','name','cpu_percent','memory_info','status','username']):
            try:
                info=p.info; mi=info.get('memory_info')
                result.append({'name':info.get('name','?'),'pid':info.get('pid',0),
                    'cpu_percent':info.get('cpu_percent',0) or 0,
                    'memory_mb':(mi.rss/1024/1024) if mi else 0,
                    'status':info.get('status','?'),'username':info.get('username','')})
            except (psutil.NoSuchProcess,psutil.AccessDenied): pass
        return result

    def get_all_apps(self)->List[dict]:
        apps=sorted(self._apps.values(),key=lambda a:-a.cpu_now)
        return [{"name":a.name,"cpu":a.cpu_now,"mem_mb":a.mem_mb_now,
                 "health_score":a.health_score,"health_label":a.health_label,
                 "health_color":a.health_color,"behavior":a.behavior,
                 "device_class":self._device_class,"baseline_cpu":a.baseline_cpu,
                 "proc_count":a.proc_count,"history":a.history_list[-60:]}
                for a in apps if a.cpu_now>0.01 or a.mem_mb_now>10]

    @property
    def device_class(self)->str: return self._device_class
    @property
    def thresholds(self)->dict: return self._thresholds

app_collector=AppCollector()
