"""
System metrics collector using psutil.
Gathers CPU, memory, disk, GPU, network, and process data.
"""
import psutil
import platform
import subprocess
import time
from typing import Optional
from dataclasses import dataclass, field


@dataclass
class SystemMetrics:
    cpu_percent: float = 0.0
    cpu_freq_mhz: float = 0.0
    cpu_core_count: int = 0
    memory_percent: float = 0.0
    memory_used_gb: float = 0.0
    memory_total_gb: float = 0.0
    disk_percent: float = 0.0
    disk_used_gb: float = 0.0
    disk_total_gb: float = 0.0
    disk_read_mbps: float = 0.0
    disk_write_mbps: float = 0.0
    gpu_percent: float = 0.0
    gpu_memory_percent: float = 0.0
    gpu_name: str = "N/A"
    network_sent_mbps: float = 0.0
    network_recv_mbps: float = 0.0
    network_latency_ms: float = 0.0
    timestamp: float = field(default_factory=time.time)


@dataclass
class ProcessInfo:
    pid: int
    name: str
    cpu_percent: float
    memory_mb: float
    status: str
    username: str
    threads: int
    cpu_bar_color: str = "green"


class MetricsCollector:
    """Collects system performance metrics."""

    def __init__(self):
        self._last_net_io = psutil.net_io_counters()
        self._last_disk_io = psutil.disk_io_counters()
        self._last_io_time = time.time()
        self._gpu_available = self._check_gpu()

    def _check_gpu(self) -> bool:
        try:
            import subprocess
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=2
            )
            return result.returncode == 0
        except Exception:
            return False

    def collect(self) -> SystemMetrics:
        metrics = SystemMetrics()
        now = time.time()
        elapsed = now - self._last_io_time

        # CPU
        metrics.cpu_percent = psutil.cpu_percent(interval=None)
        try:
            freq = psutil.cpu_freq()
            metrics.cpu_freq_mhz = freq.current if freq else 0.0
        except Exception:
            metrics.cpu_freq_mhz = 0.0
        metrics.cpu_core_count = psutil.cpu_count(logical=True) or 0

        # Memory
        mem = psutil.virtual_memory()
        metrics.memory_percent = mem.percent
        metrics.memory_used_gb = mem.used / (1024 ** 3)
        metrics.memory_total_gb = mem.total / (1024 ** 3)

        # Disk
        disk = psutil.disk_usage("/")
        metrics.disk_percent = disk.percent
        metrics.disk_used_gb = disk.used / (1024 ** 3)
        metrics.disk_total_gb = disk.total / (1024 ** 3)

        # Disk I/O
        try:
            curr_disk = psutil.disk_io_counters()
            if curr_disk and self._last_disk_io and elapsed > 0:
                read_bytes = curr_disk.read_bytes - self._last_disk_io.read_bytes
                write_bytes = curr_disk.write_bytes - self._last_disk_io.write_bytes
                metrics.disk_read_mbps = max(0, (read_bytes / elapsed) / (1024 ** 2))
                metrics.disk_write_mbps = max(0, (write_bytes / elapsed) / (1024 ** 2))
            self._last_disk_io = curr_disk
        except Exception:
            pass

        # Network
        try:
            curr_net = psutil.net_io_counters()
            if curr_net and self._last_net_io and elapsed > 0:
                sent = curr_net.bytes_sent - self._last_net_io.bytes_sent
                recv = curr_net.bytes_recv - self._last_net_io.bytes_recv
                metrics.network_sent_mbps = max(0, (sent / elapsed) / (1024 ** 2))
                metrics.network_recv_mbps = max(0, (recv / elapsed) / (1024 ** 2))
            self._last_net_io = curr_net
        except Exception:
            pass

        # Network latency (ping local router)
        metrics.network_latency_ms = self._measure_latency()

        # GPU
        if self._gpu_available:
            gpu_data = self._collect_gpu()
            metrics.gpu_percent = gpu_data.get("util", 0.0)
            metrics.gpu_memory_percent = gpu_data.get("mem_pct", 0.0)
            metrics.gpu_name = gpu_data.get("name", "GPU")
        else:
            metrics.gpu_percent = 0.0
            metrics.gpu_name = "N/A"

        self._last_io_time = now
        metrics.timestamp = now
        return metrics

    def _measure_latency(self) -> float:
        """Ping localhost as a baseline latency indicator."""
        try:
            start = time.time()
            # Simple socket connect to measure local stack latency
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.5)
            try:
                s.connect(("8.8.8.8", 53))
            except Exception:
                pass
            s.close()
            return round((time.time() - start) * 1000, 2)
        except Exception:
            return 0.0

    def _collect_gpu(self) -> dict:
        try:
            result = subprocess.run(
                ["nvidia-smi",
                 "--query-gpu=utilization.gpu,memory.used,memory.total,name",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=2
            )
            if result.returncode == 0:
                parts = result.stdout.strip().split(",")
                if len(parts) >= 4:
                    util = float(parts[0].strip())
                    mem_used = float(parts[1].strip())
                    mem_total = float(parts[2].strip())
                    name = parts[3].strip()
                    mem_pct = (mem_used / mem_total * 100) if mem_total > 0 else 0
                    return {"util": util, "mem_pct": mem_pct, "name": name}
        except Exception:
            pass
        return {}

    def get_top_processes(self, n: int = 15) -> list[ProcessInfo]:
        """Return top N processes by CPU usage."""
        processes = []
        try:
            for proc in psutil.process_iter(
                ["pid", "name", "cpu_percent", "memory_info", "status", "username", "num_threads"]
            ):
                try:
                    info = proc.info
                    mem_mb = (info["memory_info"].rss / (1024 ** 2)) if info.get("memory_info") else 0
                    cpu = info.get("cpu_percent") or 0.0
                    color = "red" if cpu > 30 else ("orange" if cpu > 10 else ("yellow" if cpu > 5 else "green"))
                    processes.append(ProcessInfo(
                        pid=info["pid"],
                        name=info.get("name", "unknown"),
                        cpu_percent=round(cpu, 1),
                        memory_mb=round(mem_mb, 1),
                        status=info.get("status", "unknown"),
                        username=info.get("username", "") or "",
                        threads=info.get("num_threads", 1) or 1,
                        cpu_bar_color=color,
                    ))
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception:
            pass

        processes.sort(key=lambda p: p.cpu_percent, reverse=True)
        return processes[:n]

    def get_system_info(self) -> dict:
        return {
            "os": platform.system(),
            "os_version": platform.version(),
            "hostname": platform.node(),
            "processor": platform.processor(),
            "cpu_cores": psutil.cpu_count(logical=False),
            "cpu_threads": psutil.cpu_count(logical=True),
            "total_memory_gb": round(psutil.virtual_memory().total / (1024 ** 3), 2),
            "python_version": platform.python_version(),
        }
