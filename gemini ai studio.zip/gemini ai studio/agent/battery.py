# """Workplace Assist — Battery Insights Collector"""
# import time, logging
# from collections import deque
# from dataclasses import dataclass, field
# from typing import List, Optional
# import psutil

# logger = logging.getLogger(__name__)

# @dataclass
# class BatterySnapshot:
#     ts:float; percent:float; plugged:bool; secs_left:Optional[float]

# class BatteryCollector:
#     def __init__(self):
#         self._history:deque=deque(maxlen=60)
#         self._drain_history:deque=deque(maxlen=10)
#         self._last_pct:Optional[float]=None
#         self._last_ts:Optional[float]=None

#     def collect(self)->dict:
#         now=time.time()
#         try:
#             bat=psutil.sensors_battery()
#         except Exception:
#             bat=None

#         if bat is None:
#             return {"available":False,"reason":"No battery detected — desktop or unsupported OS"}

#         pct=round(bat.percent,1)
#         plugged=bat.power_plugged
#         secs=bat.secsleft if bat.secsleft not in (psutil.POWER_TIME_UNKNOWN,psutil.POWER_TIME_UNLIMITED) else None

#         snap=BatterySnapshot(ts=now,percent=pct,plugged=plugged,secs_left=secs)
#         self._history.append(snap)

#         # Drain rate (% per hour)
#         drain_rate=0.0
#         if self._last_pct is not None and self._last_ts is not None and not plugged:
#             elapsed_h=(now-self._last_ts)/3600
#             if elapsed_h>0:
#                 drain_rate=round((self._last_pct-pct)/elapsed_h,2)
#                 if drain_rate>0:
#                     self._drain_history.append(drain_rate)
#         if not plugged:
#             self._last_pct=pct; self._last_ts=now

#         avg_drain=round(sum(self._drain_history)/len(self._drain_history),2) if self._drain_history else 0.0

#         # Health score (simple heuristic: based on charge level + drain rate)
#         health=min(100,max(0,int(pct-(max(0,avg_drain-10)*2))))
#         if health>=80: hlabel,hcolor="Good","green"
#         elif health>=50: hlabel,hcolor="Fair","orange"
#         else: hlabel,hcolor="Poor","red"

#         # Top draining processes (CPU-heavy ones when on battery)
#         draining_apps=[]
#         if not plugged:
#             try:
#                 procs=sorted(psutil.process_iter(['pid','name','cpu_percent']),
#                              key=lambda p:-(p.info.get('cpu_percent') or 0))[:5]
#                 draining_apps=[{"name":p.info['name'],"cpu":round(p.info.get('cpu_percent') or 0,1)}
#                                for p in procs]
#             except Exception: pass

#         # Charging pattern
#         snaps=list(self._history)
#         charged_snaps=[s for s in snaps if s.plugged]
#         charging_pct=round(len(charged_snaps)/max(len(snaps),1)*100)

#         # Est remaining
#         hrs_left=None
#         if secs and secs>0:
#             hrs_left=round(secs/3600,1)
#         elif avg_drain>0 and not plugged:
#             hrs_left=round(pct/avg_drain,1)

#         # Optimization suggestions
#         suggestions=[]
#         if avg_drain>15: suggestions.append("Unusually high drain rate detected — check background processes")
#         if not plugged and pct<20: suggestions.append("Battery below 20% — connect charger soon")
#         if draining_apps and draining_apps[0].get('cpu',0)>20:
#             suggestions.append(f"'{draining_apps[0]['name']}' is consuming significant CPU — consider closing it")
#         if charging_pct<10 and not plugged: suggestions.append("Frequent short-charge cycles detected — consider full charge cycles")
#         if not suggestions: suggestions.append("Battery health is within normal operating parameters")

#         history=[{"ts":s.ts,"percent":s.percent,"plugged":s.plugged} for s in snaps]

#         return {
#             "available":True,"percent":pct,"plugged":plugged,
#             "health_score":health,"health_label":hlabel,"health_color":hcolor,
#             "drain_rate_per_hr":avg_drain,"hours_remaining":hrs_left,
#             "charging_pct_time":charging_pct,"top_draining_apps":draining_apps,
#             "suggestions":suggestions,"history":history[-60:],
#         }

# battery_collector=BatteryCollector()








import time, subprocess, re, logging
from collections import deque
from dataclasses import dataclass
from typing import List, Optional
import psutil

logger = logging.getLogger(__name__)

@dataclass
class BatterySnapshot:
    ts: float; percent: float; plugged: bool; secs_left: Optional[float]

class BatteryCollector:
    def __init__(self):
        self._history = deque(maxlen=60)
        self._drain_history = deque(maxlen=10)
        self._last_pct = None
        self._last_ts = None

    def _query_wmi_battery(self, path: str, property: str) -> Optional[int]:
        """Queries Windows WMI for hardware-level battery data."""
        try:
            cmd = f"wmic /namespace:\\\\root\\wmi path {path} get {property}"
            out = subprocess.check_output(cmd, shell=True).decode()
            match = re.search(r'\d+', out)
            return int(match.group()) if match else None
        except Exception as e:
            logger.debug(f"WMI Query failed for {property}: {e}")
            return None

    def collect(self) -> dict:
        now = time.time()
        try:
            bat = psutil.sensors_battery()
        except Exception:
            bat = None

        if bat is None:
            return {"available": False, "reason": "No battery detected"}

        # Basic Stats
        pct = round(bat.percent, 1)
        plugged = bat.power_plugged
        secs = bat.secsleft if bat.secsleft not in (psutil.POWER_TIME_UNKNOWN, psutil.POWER_TIME_UNLIMITED) else None

        # --- REAL HARDWARE HEALTH CALCULATION ---
        design_cap = self._query_wmi_battery("BatteryStaticData", "DesignedCapacity")
        full_cap = self._query_wmi_battery("BatteryFullChargedCapacity", "FullChargedCapacity")
        cycle_count = self._query_wmi_battery("BatteryCycleCount", "CycleCount")

        if design_cap and full_cap:
            health = int((full_cap / design_cap) * 100)
        else:
            # Fallback to a safe estimate if WMI fails (common on some VMs)
            health = 100 

        # Determine Label and Color
        if health >= 85: hlabel, hcolor = "Excellent", "green"
        elif health >= 70: hlabel, hcolor = "Good", "green"
        elif health >= 50: hlabel, hcolor = "Fair", "orange"
        else: hlabel, hcolor = "Poor", "red"

        # Drain Rate (% per hour)
        drain_rate = 0.0
        if self._last_pct is not None and self._last_ts is not None and not plugged:
            elapsed_h = (now - self._last_ts) / 3600
            if elapsed_h > 0:
                drain_rate = round((self._last_pct - pct) / elapsed_h, 2)
                if drain_rate > 0:
                    self._drain_history.append(drain_rate)
        
        self._last_pct = pct; self._last_ts = now
        avg_drain = round(sum(self._drain_history)/len(self._drain_history), 2) if self._drain_history else 0.0

        # Charging pattern
        snaps = list(self._history)
        charged_snaps = [s for s in snaps if s.plugged]
        charging_pct = round(len(charged_snaps)/max(len(snaps), 1)*100)

        # History for charts
        self._history.append(BatterySnapshot(ts=now, percent=pct, plugged=plugged, secs_left=secs))
        history_list = [{"ts": s.ts, "percent": s.percent, "plugged": s.plugged} for s in self._history]

        # Top Draining Apps
        draining_apps = []
        if not plugged:
            try:
                procs = sorted(psutil.process_iter(['pid', 'name', 'cpu_percent']),
                               key=lambda p: -(p.info.get('cpu_percent') or 0))[:5]
                draining_apps = [{"name": p.info['name'], "cpu": round(p.info.get('cpu_percent') or 0, 1)} for p in procs]
            except: pass

        # Suggestions
        suggestions = []
        if health < 70: suggestions.append(f"Battery health is at {health}% - physical capacity is degrading.")
        if cycle_count and cycle_count > 500: suggestions.append(f"High cycle count ({cycle_count}) detected.")
        if avg_drain > 15: suggestions.append("High drain rate - check background power usage.")
        if not suggestions: suggestions.append("Battery is performing within normal hardware specs.")

        # FINAL RETURN (Matching your Frontend Schema)
        return {
            "available": True,
            "percent": pct,
            "plugged": plugged,
            "health_score": health,      # Now Real Hardware Health
            "health_label": hlabel,
            "health_color": hcolor,
            "drain_rate_per_hr": avg_drain,
            "hours_remaining": round(secs/3600, 1) if secs else None,
            "charging_pct_time": charging_pct,
            "top_draining_apps": draining_apps,
            "suggestions": suggestions,
            "history": history_list[-60:],
            # Extra hardware-only data in case you want to expand the UI later
            "hardware_raw": {
                "cycle_count": cycle_count,
                "design_mwh": design_cap,
                "full_charge_mwh": full_cap
            }
        }

battery_collector = BatteryCollector()