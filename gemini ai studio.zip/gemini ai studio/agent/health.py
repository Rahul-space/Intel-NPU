"""
Health score engine.
Produces a 0-100 score representing overall system wellness.
"""
from dataclasses import dataclass
from agent.collector import SystemMetrics


@dataclass
class HealthScore:
    score: int              # 0 - 100
    grade: str              # A, B, C, D, F
    label: str              # Healthy, Degraded, Critical
    color: str              # green, yellow, orange, red
    breakdown: dict[str, int]
    summary: str


# Weights for each subsystem
WEIGHTS = {
    "cpu": 0.30,
    "memory": 0.30,
    "disk": 0.20,
    "network": 0.10,
    "gpu": 0.10,
}


def _score_metric(value: float, warning: float, critical: float) -> int:
    """Returns 0-100 score for a single metric (higher = healthier)."""
    if value <= warning * 0.5:
        return 100
    elif value <= warning:
        # Linear interpolation from 100 → 75
        ratio = (value - warning * 0.5) / (warning * 0.5)
        return int(100 - ratio * 25)
    elif value <= critical:
        # Linear interpolation from 75 → 25
        ratio = (value - warning) / (critical - warning)
        return int(75 - ratio * 50)
    else:
        # Critical zone: 25 → 0
        ratio = min(1.0, (value - critical) / critical)
        return max(0, int(25 - ratio * 25))


class HealthScoreEngine:
    def compute(self, metrics: SystemMetrics) -> HealthScore:
        scores = {
            "cpu": _score_metric(metrics.cpu_percent, 60.0, 85.0),
            "memory": _score_metric(metrics.memory_percent, 50.0, 80.0),
            "disk": _score_metric(metrics.disk_percent, 75.0, 90.0),
            "network": _score_metric(metrics.network_latency_ms, 200.0, 500.0),
            "gpu": _score_metric(metrics.gpu_percent, 60.0, 90.0) if metrics.gpu_percent > 0 else 100,
        }

        # Weighted average
        if metrics.gpu_percent <= 0:
            # Redistribute GPU weight to CPU/Memory
            adjusted_weights = {
                "cpu": 0.35, "memory": 0.35, "disk": 0.20, "network": 0.10, "gpu": 0.0
            }
        else:
            adjusted_weights = WEIGHTS

        total = sum(scores[k] * adjusted_weights[k] for k in scores)
        score = max(0, min(100, int(total)))

        if score >= 85:
            grade, label, color = "A", "Healthy", "#00d4aa"
        elif score >= 70:
            grade, label, color = "B", "Good", "#86efac"
        elif score >= 55:
            grade, label, color = "C", "Degraded", "#fbbf24"
        elif score >= 35:
            grade, label, color = "D", "Stressed", "#f97316"
        else:
            grade, label, color = "F", "Critical", "#ef4444"

        summary = self._build_summary(score, label, scores)

        return HealthScore(
            score=score,
            grade=grade,
            label=label,
            color=color,
            breakdown=scores,
            summary=summary,
        )

    def _build_summary(self, score: int, label: str, scores: dict) -> str:
        worst = min(scores.items(), key=lambda x: x[1])
        if score >= 85:
            return "All systems operating normally."
        elif score >= 70:
            return f"System performing well. Minor pressure on {worst[0].upper()}."
        elif score >= 55:
            return f"Performance degraded. {worst[0].upper()} is the primary bottleneck."
        elif score >= 35:
            return f"System under significant stress. Attention required on {worst[0].upper()}."
        else:
            return f"Critical system state! {worst[0].upper()} requires immediate attention."
