"""
Workplace Assist — Agentic AI Engine  v2.3.0
=================================================
ONE FILE. Fully agentic backend using AutoGen v0.4 (autogen-agentchat).
Local-only: Ollama via OpenAI-compatible endpoint.

What makes this AGENTIC (not Gen AI):
  Gen AI  → pack a context blob into a prompt → get text back. One shot.
  Agentic → agents DECIDE what tools to call, in what order, based on
            what they find. The LLM controls the investigation flow.

  Example: Agent calls get_system_metrics() → sees CPU 91% → decides to
  call get_top_processes() → finds chrome.exe → proposes kill_process().
  That chain of decisions based on real data = agency.

APPROVAL GATE — remediations NEVER execute without user approval:
  Agent builds plan → UI shows proposal → user clicks Approve/Dismiss
  Only on Approve does the agent call any action tool.

Install:
  pip install autogen-agentchat autogen-ext[openai]

Ollama:
  ollama pull llama3.2   # or phi3, mistral, etc.
"""

import asyncio
import json
import logging
import socket
import time
import threading
import urllib.request
import uuid
from typing import Optional, Callable

from agent.context_builder import DiagnosticContext

logger = logging.getLogger(__name__)

# ── AutoGen v0.4 ──────────────────────────────────────────────────────────
try:
    from autogen_agentchat.agents import AssistantAgent
    from autogen_agentchat.teams import RoundRobinGroupChat
    from autogen_agentchat.conditions import TextMentionTermination, MaxMessageTermination
    from autogen_ext.models.openai import OpenAIChatCompletionClient
    AUTOGEN_OK = True
    logger.info("[AgenticAI] autogen-agentchat loaded ✓")
except ImportError as _e:
    AUTOGEN_OK = False
    logger.warning(f"[AgenticAI] autogen-agentchat not installed: {_e}")
    logger.warning("  Run: pip install autogen-agentchat autogen-ext[openai]")

# ─────────────────────────────────────────────────────────────────
#  SYSTEM PROMPTS
# ─────────────────────────────────────────────────────────────────

_DIAG_PROMPT = """\
You are the Cognix Diagnostician — a Windows endpoint performance expert.
You have READ-ONLY tools. Investigate the live system and report findings.

Protocol (always in this order):
  1. get_system_metrics()        → baseline, always call this first
  2. get_active_violations()     → what thresholds are breached?
  3. CPU > 70%  → get_top_processes(10)
  4. MEM > 65%  → get_top_processes(10) + get_metric_trend('memory')
  5. DISK > 80% → check disk values from metrics
  6. get_predictions()           → is this getting worse?
  7. get_metric_history(12)      → spike or sustained problem?

Output format (required):
## Findings
**Current State:** [key metrics with real values from tools]
**Issues Detected:** [named processes, exact %s — or "None" if healthy]
**Root Cause:** [1-2 sentence explanation]
**Severity:** CRITICAL | WARNING | INFO | HEALTHY
**Urgency:** immediate / monitor / none

Be specific. Quote actual numbers. Name actual processes.
Do NOT suggest fixes — the Remediator handles that."""

_REM_PROMPT = """\
You are the Cognix Remediator. You receive Diagnostician findings and
build a safe remediation plan. You NEVER execute tools until the user
approves by typing APPROVED.

Available actions:
  kill_process(pid, reason)   — kill a process (get PID from get_top_processes)
  clear_temp_files()          — delete temp files, safe, recovers 1-10 GB
  reset_network()             — flush DNS + reset Winsock (~5s interruption)
  optimize_memory()           — empty Windows standby cache, always safe

PHASE 1 — after receiving findings, output ONLY this plan format:
---REMEDIATION PLAN---
Issue: [what was found]
Actions:
  1. [action_name(args)] — [reason] — Risk: LOW/MEDIUM
  2. ...
Waiting for your approval. Reply APPROVED to execute, or DISMISSED to cancel.
---END PLAN---

PHASE 2 — only after seeing APPROVED in the conversation:
  Call each tool in your plan. Report the result of each.
  Then output: REMEDIATION_COMPLETE

Safety rules — NEVER violate:
  ✗ Do NOT call action tools before seeing APPROVED
  ✗ Do NOT kill: lsass.exe, csrss.exe, winlogon.exe, smss.exe, services.exe
  ✗ Do NOT reset_network if latency < 100ms
  ✓ clear_temp_files and optimize_memory are always safe choices"""

_CHAT_PROMPT = """You are Cognix — a friendly, expert device assistant running on this Windows machine.
You have live tools to check the real system state before answering.

CRITICAL RULES — ALWAYS FOLLOW:
  1. NEVER return raw JSON, dictionaries, or code to the user. Ever.
     Always convert tool results into plain conversational English.
  2. ALWAYS call tools before answering questions about the system.
     Do not guess or use cached context — get live data first.
  3. Be concise. 2-4 sentences or a small bullet list — not walls of text.
  4. Use plain language. The user is not a developer.

RESPONSE STYLE — GOOD EXAMPLES:
  User: "Is my system ok?"
  → Call get_system_metrics(), then reply:
    "Your system looks healthy — score 87/100. CPU at 12%, memory 48%, disk 31%. Nothing to worry about."

  User: "What's using the most CPU?"
  → Call get_top_processes(8), then reply:
    "**chrome.exe** is the top consumer at 18% CPU, followed by `node.exe` at 12%. Everything else is under 5%."

  User: "Check my battery"
  → Call get_battery_status(), then reply:
    "Battery is at 74%, currently charging. Health score 82/100 — good condition."

  User: "Is my disk space ok?"
  → Call get_system_metrics(), then reply:
    "Disk is at 61% used (245 GB of 400 GB free). You have some room but it is worth monitoring."

FOR FIX REQUESTS: investigate → explain what you found in plain English →
  propose what you will do → ask the user: "Want me to go ahead? Reply **yes** to proceed."
  Only call action tools (kill_process, clear_temp_files etc.) after the user says yes.

TOOL ORDER for general status questions:
  1. get_system_metrics()     — always first
  2. get_active_violations()  — any active alerts?
  3. get_top_processes(8)     — if CPU or memory is high"""



# ─────────────────────────────────────────────────────────────────
#  PROTECTED PROCESSES — never kill these
# ─────────────────────────────────────────────────────────────────
_PROTECTED = {
    "lsass.exe", "csrss.exe", "winlogon.exe", "smss.exe",
    "services.exe", "wininit.exe", "system", "registry",
}


# ─────────────────────────────────────────────────────────────────
#  TOOL FACTORY  — closures over live state
# ─────────────────────────────────────────────────────────────────

def _make_tools(state, remediation, battery_col=None, security_col=None):
    """
    Returns (read_tools, action_tools) — plain Python closures over
    live AgentState and RemediationEngine.
    AutoGen v0.4 accepts plain functions directly as tools.
    """

    # ── READ TOOLS ───────────────────────────────────────────────

    def get_system_metrics() -> dict:
        """Get live CPU%, memory%, disk%, network latency ms, GPU%, and health score/label."""
        if not state or not state.latest_metrics:
            return {"error": "Metrics not yet collected, retry in a few seconds"}
        m, h = state.latest_metrics, state.latest_health
        return {
            "cpu_percent":        round(m.cpu_percent, 1),
            "cpu_cores":          m.cpu_core_count,
            "memory_percent":     round(m.memory_percent, 1),
            "memory_used_gb":     round(m.memory_used_gb, 1),
            "memory_total_gb":    round(m.memory_total_gb, 1),
            "disk_percent":       round(m.disk_percent, 1),
            "disk_used_gb":       round(m.disk_used_gb, 1),
            "disk_total_gb":      round(m.disk_total_gb, 1),
            "disk_read_mbps":     round(m.disk_read_mbps, 2),
            "disk_write_mbps":    round(m.disk_write_mbps, 2),
            "network_latency_ms": round(m.network_latency_ms),
            "network_sent_mbps":  round(m.network_sent_mbps, 2),
            "network_recv_mbps":  round(m.network_recv_mbps, 2),
            "gpu_percent":        round(m.gpu_percent, 1),
            "gpu_name":           m.gpu_name,
            "health_score":       h.score if h else 0,
            "health_label":       h.label if h else "Unknown",
            "as_of":              time.strftime("%H:%M:%S", time.localtime(m.timestamp)),
        }

    def get_top_processes(limit: int = 10) -> list:
        """Get top N processes by CPU%. limit: 1-20. Each entry has pid, name,
        cpu_percent, memory_mb, status. Use pid values for kill_process()."""
        if not state:
            return []
        return [
            {"pid": p.pid, "name": p.name,
             "cpu_percent": round(p.cpu_percent, 1),
             "memory_mb": round(p.memory_mb), "status": p.status}
            for p in state.latest_processes[:min(int(limit), 20)]
        ]

    def get_active_violations() -> list:
        """Get current threshold violations. Empty list means system is healthy.
        Each has: metric, severity (warning|critical), current_value, threshold,
        message, sustained_seconds."""
        if not state:
            return []
        return [
            {"metric": v.metric, "severity": v.severity.value,
             "current_value": round(v.current_value, 1),
             "threshold": v.threshold, "message": v.message,
             "sustained_seconds": round(v.sustained_seconds)}
            for v in state.active_violations
        ]

    def get_metric_trend(metric: str) -> dict:
        """Trend for a metric: 'cpu'|'memory'|'disk'|'network_latency'.
        Returns direction (rising/stable/falling), slope, change_rate.
        Use to tell if a high reading is a spike or a growing problem."""
        valid = ("cpu", "memory", "disk", "network_latency")
        if metric not in valid:
            return {"error": f"metric must be one of: {', '.join(valid)}"}
        if not state or not state.latest_context:
            return {"metric": metric, "direction": "unknown"}
        t = state.latest_context.trends.get(metric)
        if not t:
            return {"metric": metric, "direction": "stable", "note": "Not enough data yet"}
        return {"metric": metric, "direction": t.get("direction", "stable"),
                "slope": round(t.get("slope", 0), 3),
                "change_rate_pct": round(t.get("change_rate", 0), 2)}

    def get_predictions() -> list:
        """Predictive forecasts for CPU/memory/disk.
        Returns time_to_critical_hours and predicted values at 1h/24h.
        Empty list = no concerning trends."""
        if not state or not state.latest_context:
            return []
        return state.latest_context.predictions or []

    def get_metric_history(points: int = 12) -> dict:
        """Last N snapshots (~5s each, max 60 = ~5 min).
        Useful for spotting spikes vs sustained problems."""
        if not state:
            return {"error": "State unavailable"}
        pts = state.metric_history[-min(int(points), 60):]
        return {"count": len(pts), "interval_seconds": 5, "history": pts}

    def get_system_info() -> dict:
        """Static device info: hostname, OS, CPU model, total RAM, architecture."""
        return state.system_info if state else {}

    def get_battery_status() -> dict:
        """Battery level%, plugged_in, time_left_minutes, health score.
        Returns error for desktops/VMs without a battery."""
        try:
            import psutil
            b = psutil.sensors_battery()
            if not b:
                return {"error": "No battery (desktop or VM)"}
            result = {"percent": round(b.percent, 1), "plugged_in": b.power_plugged,
                      "time_left_minutes": round(b.secsleft / 60) if b.secsleft and b.secsleft > 0 else None}
            if battery_col:
                try:
                    result.update(battery_col.collect())
                except Exception:
                    pass
            return result
        except Exception as e:
            return {"error": str(e)}

    def get_security_status() -> dict:
        """AV/BitLocker/firewall compliance status, overall score, detected threats."""
        if not security_col:
            return {"error": "Security collector not bound"}
        try:
            return security_col.collect()
        except Exception as e:
            return {"error": str(e)}

    # ── ACTION TOOLS (only call after APPROVED) ──────────────────

    def kill_process(pid: int, reason: str = "") -> dict:
        """Kill a process by PID. Get pid from get_top_processes().
        ONLY call this after user has approved the remediation plan.
        Protected system processes are automatically blocked."""
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        try:
            import psutil
            proc = psutil.Process(int(pid))
            if proc.name().lower() in _PROTECTED:
                return {"success": False,
                        "message": f"BLOCKED: '{proc.name()}' is a protected system process"}
        except Exception:
            pass
        logger.info(f"[Tool] kill_process pid={pid} reason={reason!r}")
        r = remediation.kill_process(int(pid))
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    def clear_temp_files() -> dict:
        """Delete Windows temp files. Safe. Typically recovers 1-10 GB.
        ONLY call this after user has approved the remediation plan."""
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        logger.info("[Tool] clear_temp_files")
        r = remediation.clear_temp_files()
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    def reset_network() -> dict:
        """Flush DNS cache and reset Winsock (~5s network interruption).
        Use when latency > 200ms. ONLY call after user approval."""
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        logger.info("[Tool] reset_network")
        r = remediation.reset_network()
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    def optimize_memory() -> dict:
        """Empty Windows standby cache. Safe, Windows refills as needed.
        ONLY call after user has approved the remediation plan."""
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        logger.info("[Tool] optimize_memory")
        r = remediation.optimize_memory()
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    read_tools   = [get_system_metrics, get_top_processes, get_active_violations,
                    get_metric_trend, get_predictions, get_metric_history,
                    get_system_info, get_battery_status, get_security_status]
    action_tools = [kill_process, clear_temp_files, reset_network, optimize_memory]

    return read_tools, action_tools


# ─────────────────────────────────────────────────────────────────
#  OLLAMA  single-shot client (fallback when AutoGen not installed)
# ─────────────────────────────────────────────────────────────────

_SYSTEM_PROMPT_FALLBACK = """\
You are Workplace Assist, an expert endpoint performance diagnostics assistant.
Be concise. Reference specific values. Use **bold** for key terms.
Use `backticks` for process names. Number all recommendations.
If healthy, say so in 1-2 lines. Never invent data."""

class _OllamaClient:
    def __init__(self, base_url="http://127.0.0.1:11434", timeout=120):
        self.base_url = base_url.rstrip("/")
        self.timeout  = timeout

    def is_running(self) -> bool:
        try:
            with socket.create_connection(("127.0.0.1", 11434), timeout=2):
                return True
        except OSError:
            return False

    def list_models(self) -> list:
        try:
            with urllib.request.urlopen(
                urllib.request.Request(f"{self.base_url}/api/tags"), timeout=5
            ) as r:
                return [m.get("name", "") for m in json.loads(r.read()).get("models", [])]
        except Exception:
            return []

    def chat(self, messages: list, model: str, options: dict) -> str:
        payload = json.dumps({"model": model, "messages": messages,
                              "stream": False, "options": options}).encode()
        req = urllib.request.Request(
            f"{self.base_url}/api/chat", data=payload,
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            return json.loads(r.read()).get("message", {}).get("content", "").strip()


# ─────────────────────────────────────────────────────────────────
#  PENDING PROPOSAL  — approval gate state
# ─────────────────────────────────────────────────────────────────

class _Proposal:
    """A remediation plan waiting for user approval."""
    def __init__(self, session_id: str, findings: str, plan_text: str, trigger: str):
        self.session_id  = session_id
        self.findings    = findings
        self.plan_text   = plan_text
        self.trigger     = trigger          # 'analyze' | 'chat' | 'monitor'
        self.created_at  = time.time()
        self.approved    = False
        self.dismissed   = False
        self._event      = asyncio.Event()  # set when user decides

    def to_dict(self) -> dict:
        return {"session_id": self.session_id, "findings": self.findings,
                "plan_text": self.plan_text, "trigger": self.trigger,
                "created_at": self.created_at}


# ─────────────────────────────────────────────────────────────────
#  MAIN ENGINE  (public facade — api/server.py talks only to this)
# ─────────────────────────────────────────────────────────────────

class AIDiagnosticEngine:
    """
    Agentic AI engine backed by AutoGen v0.4 + local Ollama.

    Same public interface as the original engine — api/server.py unchanged
    except for the three new approval endpoints added in server.py.

    Architecture:
      analyze_context() → Diagnostician agent (read tools only, no approval needed)
      chat()            → ChatAssistant agent (all tools, asks before acting)
      Approval gate     → approve(session_id) / dismiss(session_id)

    Fallback when AutoGen not installed:
      Single-shot Ollama → rule-based text responses
    """

    GENERATION_DEFAULTS = {
        "temperature": 0.3, "top_p": 0.9, "top_k": 40,
        "num_predict": 1024, "num_ctx": 4096, "repeat_penalty": 1.1,
    }

    def __init__(self):
        self._ollama        = _OllamaClient()
        self._ollama_model: Optional[str] = None
        self._gen_opts      = dict(self.GENERATION_DEFAULTS)
        self._available     = None
        self._last_check    = 0.0
        self._provider      = "local"

        # AutoGen model client (set by set_local_model)
        self._model_client  = None

        # Live tool references (set by bind_tools)
        self._read_tools    = []
        self._action_tools  = []

        # WebSocket broadcast (set by bind_tools)
        self._broadcast: Optional[Callable] = None

        # Pending proposals waiting for user decision
        self._proposals: dict[str, _Proposal] = {}

        logger.info(
            f"[AgenticAI] AutoGen available: {AUTOGEN_OK} — "
            f"{'agentic mode' if AUTOGEN_OK else 'single-shot fallback mode'}"
        )

    # ──────────────────────────────────────────────────────────────
    #  SETUP  (called from server.py create_app)
    # ──────────────────────────────────────────────────────────────

    def bind_tools(self, state, remediation_engine,
                   battery_collector=None, security_collector=None,
                   broadcast_fn: Optional[Callable] = None):
        """
        Wire live AgentState + RemediationEngine into the tool closures.
        Must be called after the scheduler starts. Called from server.py.
        """
        self._read_tools, self._action_tools = _make_tools(
            state, remediation_engine, battery_collector, security_collector
        )
        self._broadcast = broadcast_fn
        logger.info(f"[AgenticAI] Tools bound — "
                    f"{len(self._read_tools)} read, {len(self._action_tools)} action")

    def set_local_model(self, model_name: str) -> dict:
        """Set the Ollama model. Builds the AutoGen model client."""
        self._ollama_model = model_name
        self._available    = None
        self._last_check   = 0.0

        if not self._ollama.is_running():
            return {"provider": "local", "model": model_name,
                    "available": False, "message": "Ollama is not running"}

        if not AUTOGEN_OK:
            return {
                "provider": "local", "model": model_name,
                "available": True, "agentic": False,
                "message": (
                    f"Ollama connected ({model_name}) — single-shot mode. "
                    "Run: pip install autogen-agentchat autogen-ext[openai] for agentic mode."
                ),
            }

        try:
            base = "http://127.0.0.1:11434/v1"
            self._model_client = OpenAIChatCompletionClient(
                model    = model_name,
                base_url = base,
                api_key  = "ollama",
                model_capabilities={
                    "vision": False,
                    "function_calling": True,
                    "json_output": False,
                },
            )
            logger.info(f"[AgenticAI] Model client ready: {model_name}")
            return {
                "provider": "local", "model": model_name,
                "available": True, "agentic": True,
                "message": f"Agentic AI ready — {model_name} via Ollama",
            }
        except Exception as e:
            self._model_client = None
            logger.error(f"[AgenticAI] set_model error: {e}")
            return {"provider": "local", "model": model_name,
                    "available": False, "message": str(e)[:200]}

    # ──────────────────────────────────────────────────────────────
    #  APPROVAL GATE
    # ──────────────────────────────────────────────────────────────

    def approve_proposal(self, session_id: str) -> bool:
        p = self._proposals.get(session_id)
        if not p or p._event.is_set():
            return False
        p.approved = True
        p._event.set()
        logger.info(f"[AgenticAI] Proposal approved: {session_id}")
        return True

    def dismiss_proposal(self, session_id: str) -> bool:
        p = self._proposals.get(session_id)
        if not p or p._event.is_set():
            return False
        p.dismissed = True
        p._event.set()
        logger.info(f"[AgenticAI] Proposal dismissed: {session_id}")
        return True

    def get_pending_proposals(self) -> list:
        now = time.time()
        return [p.to_dict() for p in self._proposals.values()
                if not p._event.is_set() and (now - p.created_at) < 300]

    # ──────────────────────────────────────────────────────────────
    #  MAIN PUBLIC INTERFACE  (async — called directly from server.py)
    # ──────────────────────────────────────────────────────────────

    async def analyze_context_async(self, context: DiagnosticContext) -> str:
        """
        Agentic tab analysis — called by Analyze Now button on every tab.
        Diagnostician uses live tools to investigate. Read-only, no approval needed.
        Returns formatted markdown text for the UI.
        """
        if not self._model_client:
            return self._fallback_analyze(context)

        try:
            diag = AssistantAgent(
                name           = "Diagnostician",
                model_client   = self._model_client,
                system_message = _DIAG_PROMPT,
                tools          = self._read_tools,
            )
            term  = TextMentionTermination("## Findings") | MaxMessageTermination(12)
            team  = RoundRobinGroupChat([diag], termination_condition=term)
            ctx   = self._format_context(context)
            result = await team.run(
                task=f"System snapshot (use tools for live data):\n{ctx}\n\n"
                     "Investigate now and produce your ## Findings report."
            )
            text = self._last_message(result)
            return text if text else "System appears healthy — no issues detected."

        except Exception as e:
            logger.error(f"[AgenticAI] analyze error: {e}", exc_info=True)
            return self._fallback_analyze(context)

    async def chat_async(self, user_message: str,
                         context: Optional[DiagnosticContext] = None,
                         history: Optional[list] = None) -> str:
        """
        Agentic chat — agent fetches live data with tools before answering.
        For remediation requests: agent proposes → user approves → agent executes.
        """
        if not self._model_client:
            return self._fallback_chat(user_message, context)

        try:
            ctx_text = self._format_context(context) if context else \
                       "No context. Use get_system_metrics() for current data."

            hist_text = ""
            if history:
                hist_text = "\n[Recent conversation]\n" + "\n".join(
                    f"{t.get('role','?').upper()}: {(t.get('content') or '')[:300]}"
                    for t in history[-6:]
                ) + "\n"

            agent = AssistantAgent(
                name           = "CognixAssistant",
                model_client   = self._model_client,
                system_message = _CHAT_PROMPT,
                tools          = self._read_tools + self._action_tools,
            )
            term   = MaxMessageTermination(8)
            team   = RoundRobinGroupChat([agent], termination_condition=term)
            result = await team.run(
                task=f"System context:\n{ctx_text}\n{hist_text}\nUser: {user_message}"
            )
            response = self._last_message(result)

            # If agent is asking for approval to execute, register a proposal
            if response and any(kw in response.lower() for kw in
               ("shall i proceed", "reply yes", "want me to", "approve",
                "should i kill", "want me to clear", "type yes", "say yes")):
                sid = uuid.uuid4().hex[:10]
                prop = _Proposal(sid, ctx_text, response, trigger="chat")
                self._proposals[sid] = prop
                await self._push({
                    "type": "agent_proposal",
                    "session_id": sid,
                    "trigger": "chat",
                    "plan_text": response,
                })

            return response or "All clear — system appears healthy."

        except Exception as e:
            logger.error(f"[AgenticAI] chat error: {e}", exc_info=True)
            return self._fallback_chat(user_message, context)

    # ──────────────────────────────────────────────────────────────
    #  SYNC WRAPPERS  (kept for backward-compat with any sync callers)
    # ──────────────────────────────────────────────────────────────

    def analyze_context(self, context: DiagnosticContext) -> str:
        """Sync wrapper — only used from the alert callback (non-async context)."""
        return self._fallback_analyze(context)

    def chat(self, user_message: str, context=None, history=None) -> str:
        """Sync wrapper — only used when AutoGen is unavailable."""
        return self._fallback_chat(user_message, context)

    # ──────────────────────────────────────────────────────────────
    #  STATUS & CONFIG
    # ──────────────────────────────────────────────────────────────

    @property
    def available(self) -> bool:
        now = time.time()
        if self._available is not None and (now - self._last_check) < 30:
            return self._available
        self._last_check = now
        self._available  = self._ollama.is_running()
        return self._available

    @property
    def model_name(self) -> str:
        return self._ollama_model or "not configured"

    def get_status(self) -> dict:
        running = self._ollama.is_running()
        models  = self._ollama.list_models() if running else []
        return {
            "provider":          "local",
            "model":             self.model_name,
            "available":         running,
            "ollama_running":    running,
            "ollama_models":     models,
            "agentic_enabled":   AUTOGEN_OK,
            "agentic_active":    self._model_client is not None,
            "autogen_installed": AUTOGEN_OK,
            "pending_proposals": len(self.get_pending_proposals()),
        }

    def get_ollama_models(self) -> list:
        return self._ollama.list_models()

    def set_generation_options(self, opts: dict):
        self._gen_opts.update(opts)

    # ──────────────────────────────────────────────────────────────
    #  INTERNAL HELPERS
    # ──────────────────────────────────────────────────────────────

    def _last_message(self, result) -> str:
        """Extract last meaningful text from AutoGen v0.4 TaskResult."""
        try:
            msgs = result.messages if hasattr(result, "messages") else []
            for msg in reversed(msgs):
                content = getattr(msg, "content", None) or \
                          (msg.get("content") if isinstance(msg, dict) else None)
                if isinstance(content, str):
                    content = content.strip()
                    if content and len(content) > 15:
                        return content
        except Exception:
            pass
        return ""

    def _format_context(self, ctx) -> str:
        """Compact snapshot for agent prompts."""
        if not ctx:
            return "No snapshot. Call get_system_metrics()."
        m, h = ctx.metrics, ctx.health
        lines = [
            f"Health: {h.get('score','?')}/100 — {h.get('label','?')}",
            f"CPU: {m.get('cpu_percent',0):.1f}%  "
            f"MEM: {m.get('memory_percent',0):.1f}%  "
            f"DISK: {m.get('disk_percent',0):.1f}%  "
            f"NET: {m.get('network_latency_ms',0):.0f}ms",
        ]
        if ctx.violations:
            for v in ctx.violations[:3]:
                lines.append(f"  [{v.get('severity','').upper()}] {v.get('message','')}")
        lines.append("→ Use tools to get fresh live data.")
        return "\n".join(lines)

    async def _push(self, data: dict):
        """Broadcast to all WebSocket clients."""
        if self._broadcast:
            try:
                await self._broadcast(data)
            except Exception as e:
                logger.debug(f"[AgenticAI] broadcast error: {e}")

    # ── Fallbacks when AutoGen / Ollama unavailable ────────────────

    def _fallback_analyze(self, context) -> str:
        """Single-shot Ollama fallback for analyze_context."""
        if self._ollama.is_running() and self._ollama_model:
            prompt = (
                "Analyze the following real-time system diagnostic data. "
                "Identify issues, explain root causes, give numbered steps:\n\n"
                f"{context.to_prompt_text()}"
            )
            try:
                msgs = [{"role": "system", "content": _SYSTEM_PROMPT_FALLBACK},
                        {"role": "user",   "content": prompt}]
                return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] fallback analyze error: {e}")
        return self._rule_based("analyze", context)

    def _fallback_chat(self, user_message: str, context) -> str:
        """Single-shot Ollama fallback for chat."""
        if self._ollama.is_running() and self._ollama_model:
            ctx_text = self._format_context(context) if context else ""
            msgs = [{"role": "system",    "content": _SYSTEM_PROMPT_FALLBACK},
                    {"role": "user",      "content": f"[System]\n{ctx_text}"},
                    {"role": "assistant", "content": "Understood."},
                    {"role": "user",      "content": user_message}]
            try:
                return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] fallback chat error: {e}")
        return self._rule_based(user_message, context)

    def _rule_based(self, prompt: str, context) -> str:
        """Keyword-based response when nothing else is available."""
        p = prompt.lower()
        hdr = ""
        if context:
            m, h = context.metrics, context.health
            sc   = h.get("score", 0)
            ic   = "✅" if sc >= 85 else "⚠️" if sc >= 55 else "🔴"
            hdr  = (f"{ic} **Health {sc}/100 — {h.get('label','?')}** | "
                    f"CPU `{m.get('cpu_percent',0):.1f}%` "
                    f"MEM `{m.get('memory_percent',0):.1f}%` "
                    f"DISK `{m.get('disk_percent',0):.1f}%`\n\n")
            if context.violations:
                v = context.violations[0]
                return (hdr + f"⚠ **{v.get('severity','').upper()}** — {v.get('message','')}\n\n"
                        "> Start Ollama and select a model in **AI Settings** for agentic analysis.")

        if any(k in p for k in ("cpu", "processor")):
            return hdr + "**CPU high** — check Processes tab, kill top consumer."
        if any(k in p for k in ("memory", "ram")):
            return hdr + "**Memory high** — restart browsers/IDEs or use Optimize Memory."
        if any(k in p for k in ("disk", "storage", "space")):
            return hdr + "**Disk** — run Clear Temp Files from the Remediation panel."
        if any(k in p for k in ("network", "latency", "dns")):
            return hdr + "**Network** — use Reset Network to flush DNS and Winsock."
        if context and any(k in p for k in ("health", "status", "ok", "analyze")):
            sc = context.health.get("score", 0)
            return hdr + f"Health score: {sc}/100. " + context.health.get("summary", "")

        return (hdr or "") + (
            "⚙ **AI not configured** — Ollama not running or no model selected.\n\n"
            "Go to **AI Settings → Local LLM**, pick a model, click Connect.\n"
            "Then agents can investigate and fix issues autonomously."
        )





# """
# Workplace Assist — AI Diagnostic Engine
# ============================================
# Supports three provider modes:

#   1. LOCAL  — Any Ollama model installed on the device (phi3, llama3, mistral, etc.)
#   2. CLAUDE — Anthropic Claude API (claude-3-5-haiku, claude-3-5-sonnet, etc.)
#   3. OPENAI — OpenAI API (gpt-4o-mini, gpt-4o, gpt-3.5-turbo, etc.)

# All three share the same SYSTEM_PROMPT and chat() / analyze_context() interface.
# Switching providers is done at runtime via set_provider().
# """

# import json
# import logging
# import socket
# import time
# import urllib.request
# import urllib.error
# from typing import Optional

# from agent.context_builder import DiagnosticContext

# logger = logging.getLogger(__name__)

# # ── Shared system prompt ───────────────────────────────────────────────────
# SYSTEM_PROMPT = """You are Workplace Assist, an expert endpoint performance diagnostics assistant embedded directly on this device.

# Your role:
# 1. Analyze real-time CPU, memory, disk, network and process telemetry
# 2. Identify root causes of performance issues with precision
# 3. Name specific processes and metrics responsible for problems
# 4. Give numbered, immediately actionable remediation steps
# 5. Predict and warn about upcoming issues based on metric trends

# Rules:
# - Be concise but thorough. Lead with the most critical finding.
# - Always reference specific values from the provided data.
# - Use **bold** for key terms. Use `backticks` for process names and commands.
# - Format recommendations as a numbered list.
# - If the system is healthy, say so clearly in 1-2 lines.
# - Never invent data not present in the context."""

# # ── Ollama client (stdlib only, no requests) ───────────────────────────────

# class OllamaClient:
#     def __init__(self, base_url: str = "http://127.0.0.1:11434", timeout: int = 180):
#         self.base_url = base_url.rstrip("/")
#         self.timeout  = timeout
#         self._model   = None

#     def is_running(self) -> bool:
#         try:
#             with socket.create_connection(("127.0.0.1", 11434), timeout=2):
#                 return True
#         except OSError:
#             return False

#     def list_models(self) -> list:
#         try:
#             req = urllib.request.Request(f"{self.base_url}/api/tags")
#             with urllib.request.urlopen(req, timeout=5) as r:
#                 data = json.loads(r.read().decode())
#             return [m.get("name", "") for m in data.get("models", [])]
#         except Exception:
#             return []

#     def chat(self, messages: list, model: str, options: dict) -> str:
#         payload = json.dumps({
#             "model":    model,
#             "messages": messages,
#             "stream":   False,
#             "options":  options,
#         }).encode()
#         req = urllib.request.Request(
#             f"{self.base_url}/api/chat", data=payload,
#             headers={"Content-Type": "application/json"}, method="POST",
#         )
#         with urllib.request.urlopen(req, timeout=self.timeout) as r:
#             return json.loads(r.read().decode()).get("message", {}).get("content", "").strip()

#     def generate(self, prompt: str, system: str, model: str, options: dict) -> str:
#         payload = json.dumps({
#             "model": model, "prompt": prompt, "system": system,
#             "stream": False, "options": options,
#         }).encode()
#         req = urllib.request.Request(
#             f"{self.base_url}/api/generate", data=payload,
#             headers={"Content-Type": "application/json"}, method="POST",
#         )
#         with urllib.request.urlopen(req, timeout=self.timeout) as r:
#             return json.loads(r.read().decode()).get("response", "").strip()

# # ── Claude API client (stdlib only) ───────────────────────────────────────
# class ClaudeClient:
#     BASE = "https://api.anthropic.com/v1/messages"
#     MODELS = [
#         "claude-haiku-4-5-20251001",
#         "claude-sonnet-4-5",
#         "claude-opus-4-5",
#         "claude-3-5-haiku-20241022",
#         "claude-3-5-sonnet-20241022",
#         "claude-3-opus-20240229",
#     ]

#     def __init__(self, api_key: str, model: str = "claude-haiku-4-5-20251001", timeout: int = 60):
#         self.api_key = api_key
#         self.model   = model
#         self.timeout = timeout

#     def chat(self, messages: list, max_tokens: int = 1024) -> str:
#         # Separate system message from user/assistant turns
#         system = SYSTEM_PROMPT
#         turns  = [m for m in messages if m["role"] in ("user", "assistant")]

#         payload = json.dumps({
#             "model":      self.model,
#             "max_tokens": max_tokens,
#             "system":     system,
#             "messages":   turns,
#         }).encode()

#         req = urllib.request.Request(
#             self.BASE, data=payload,
#             headers={
#                 "Content-Type":      "application/json",
#                 "x-api-key":         self.api_key,
#                 "anthropic-version": "2023-06-01",
#             },
#             method="POST",
#         )
#         try:
#             with urllib.request.urlopen(req, timeout=self.timeout) as r:
#                 data = json.loads(r.read().decode())
#             return data["content"][0]["text"].strip()
#         except urllib.error.HTTPError as e:
#             body = e.read().decode()
#             raise RuntimeError(f"Claude API error {e.code}: {body}") from e

# # ── OpenAI API client (stdlib only) ───────────────────────────────────────
# class OpenAIClient:
#     BASE = "https://api.openai.com/v1/chat/completions"
#     MODELS = [
#         "gpt-4o-mini",
#         "gpt-4o",
#         "gpt-4-turbo",
#         "gpt-3.5-turbo",
#         "o1-mini",
#         "o3-mini",
#     ]

#     def __init__(self, api_key: str, model: str = "gpt-4o-mini", timeout: int = 60):
#         self.api_key = api_key
#         self.model   = model
#         self.timeout = timeout

#     def chat(self, messages: list, max_tokens: int = 1024) -> str:
#         # Prepend system message
#         all_msgs = [{"role": "system", "content": SYSTEM_PROMPT}] + [
#             m for m in messages if m["role"] in ("user", "assistant")
#         ]
#         payload = json.dumps({
#             "model":      self.model,
#             "messages":   all_msgs,
#             "max_tokens": max_tokens,
#         }).encode()

#         req = urllib.request.Request(
#             self.BASE, data=payload,
#             headers={
#                 "Content-Type":  "application/json",
#                 "Authorization": f"Bearer {self.api_key}",
#             },
#             method="POST",
#         )
#         try:
#             with urllib.request.urlopen(req, timeout=self.timeout) as r:
#                 data = json.loads(r.read().decode())
#             return data["choices"][0]["message"]["content"].strip()
#         except urllib.error.HTTPError as e:
#             body = e.read().decode()
#             raise RuntimeError(f"OpenAI API error {e.code}: {body}") from e
# class NvidiaClient:
#     BASE = "https://integrate.api.nvidia.com/v1"

#     MODELS = [
#         "nvidia/nemotron-3-super-120b-a12b",
#         "openai/gpt-oss-120b",
#         "stepfun-ai/step-3.5-flash",
#         "mistralai/devstral-2-123b-instruct-2512",
#         "meta/llama3-70b-instruct",
        
#     ]

#     def __init__(self, api_key: str,
#                  model: str = "nvidia/nemotron-3-super-120b-a12b",
#                  timeout: int = 120):
#         self.api_key = api_key
#         self.model   = model
#         self.timeout = timeout

#     def chat(self, messages: list, max_tokens: int = 1024) -> str:
#         all_msgs = [{"role": "system", "content": SYSTEM_PROMPT}] + [
#             m for m in messages if m["role"] in ("user", "assistant")
#         ]

#         payload = json.dumps({
#             "model": self.model,
#             "messages": all_msgs,
#             "temperature": 0.7,
#             "top_p": 0.95,
#             "max_tokens": max_tokens
#         }).encode()

#         req = urllib.request.Request(
#             f"{self.BASE}/chat/completions",
#             data=payload,
#             headers={
#                 "Content-Type": "application/json",
#                 "Authorization": f"Bearer {self.api_key}",
#             },
#             method="POST",
#         )

#         try:
#             with urllib.request.urlopen(req, timeout=self.timeout) as r:
#                 raw = r.read().decode()

#             # 🔍 Debug (keep temporarily)
#             # print("RAW NVIDIA RESPONSE:", raw)

#             data = json.loads(raw)

#             return self._extract_content(data)

#         except urllib.error.HTTPError as e:
#             body = e.read().decode()

#             try:
#                 err_json = json.loads(body)
#             except:
#                 err_json = {"error": body}

#             raise RuntimeError(
#                 f"NVIDIA API error {e.code}: {err_json}"
#             ) from e

#         except Exception as e:
#             raise RuntimeError(f"NVIDIA Client error: {str(e)}") from e

#     # ✅ Robust response parser
#     def _extract_content(self, data: dict) -> str:
#         try:
#             choices = data.get("choices", [])
#             if not choices:
#                 return "No choices returned from model"

#             msg = choices[0].get("message", {})

#             # ✅ Standard content
#             content = msg.get("content")
#             if content:
#                 return content.strip()

#             # ✅ Some models return reasoning separately
#             reasoning = msg.get("reasoning_content")
#             if reasoning:
#                 return reasoning.strip()

#             # ✅ Tool-based responses
#             tool_calls = msg.get("tool_calls")
#             if tool_calls:
#                 return json.dumps(tool_calls)

#             # ✅ Last fallback (important for debugging)
#             return json.dumps(msg) or "Empty response from model"

#         except Exception as e:
#             return f"Response parsing error: {str(e)}"

# # ── Main multi-provider engine ─────────────────────────────────────────────

# class AIDiagnosticEngine:
#     """
#     Runtime-switchable AI engine.
#     Providers: 'local' (Ollama) | 'claude' | 'openai' | 'nvidia'
#     """

#     GENERATION_DEFAULTS = {
#         "temperature":    0.3,
#         "top_p":          0.9,
#         "top_k":          40,
#         "num_predict":    1024,
#         "num_ctx":        4096,
#         "repeat_penalty": 1.1,
#     }

#     def __init__(self):
#         self._provider: str  = "local"   # 'local' | 'claude' | 'openai'
#         self._ollama         = OllamaClient()
#         self._ollama_model   = None
#         self._claude: Optional[ClaudeClient] = None
#         self._openai: Optional[OpenAIClient] = None
#         self._nvidia: Optional[NvidiaClient] = None
#         self._available      = None
#         self._last_check     = 0.0
#         self._gen_options    = dict(self.GENERATION_DEFAULTS)

#     # ── Provider management ────────────────────────────────────────────────
#     def set_nvidia_key(self, api_key: str,
#         model: str = "nvidia/nemotron-3-super-120b-a12b") -> dict:
#         """Configure NVIDIA API key and model."""
#         self._provider = "nvidia"
#         self._nvidia   = NvidiaClient(api_key=api_key, model=model)
#         self._available  = None
#         self._last_check = 0.0
#         try:
#             self._nvidia.chat(
#             [{"role": "user", "content": "ping"}],
#             max_tokens=10
#         )
#             self._available = True
#             msg = f"NVIDIA API connected ({model})"
#         except Exception as e:
#             self._available = False
#             msg = f"NVIDIA API error: {str(e)[:100]}"
#         return {
#             "provider":  "nvidia",
#             "model":     model,
#             "available": self._available,
#             "message":   msg,
#         }
#     def set_local_model(self, model_name: str) -> dict:
#         """Select a specific Ollama model by name."""
#         self._provider     = "local"
#         self._ollama_model = model_name
#         self._available    = None
#         self._last_check   = 0.0
#         ok = self.available
#         return {
#             "provider":  "local",
#             "model":     self._ollama_model or "none",
#             "available": ok,
#             "message":   f"Connected to {model_name}" if ok else "Ollama not running",
#         }

#     def set_claude_key(self, api_key: str, model: str = "claude-haiku-4-5-20251001") -> dict:
#         """Configure Claude API key and model."""
#         self._provider = "claude"
#         self._claude   = ClaudeClient(api_key=api_key, model=model)
#         self._available = None
#         self._last_check = 0.0
#         # Quick validation attempt
#         try:
#             self._claude.chat([{"role": "user", "content": "ping"}], max_tokens=5)
#             self._available = True
#             msg = f"Claude API connected ({model})"
#         except Exception as e:
#             self._available = False
#             msg = f"Claude API error: {str(e)[:100]}"
#         return {
#             "provider":  "claude",
#             "model":     model,
#             "available": self._available,
#             "message":   msg,
#         }

#     def set_openai_key(self, api_key: str, model: str = "gpt-4o-mini") -> dict:
#         """Configure OpenAI API key and model."""
#         self._provider = "openai"
#         self._openai   = OpenAIClient(api_key=api_key, model=model)
#         self._available = None
#         self._last_check = 0.0
#         try:
#             self._openai.chat([{"role": "user", "content": "ping"}], max_tokens=5)
#             self._available = True
#             msg = f"OpenAI API connected ({model})"
#         except Exception as e:
#             self._available = False
#             msg = f"OpenAI API error: {str(e)[:100]}"
#         return {
#             "provider":  "openai",
#             "model":     model,
#             "available": self._available,
#             "message":   msg,
#         }

#     def set_generation_options(self, opts: dict):
#         self._gen_options.update(opts)

#     # ── Availability ───────────────────────────────────────────────────────

#     @property
#     def available(self) -> bool:
#         now = time.time()
#         if self._available is not None and (now - self._last_check) < 30:
#             return self._available
#         self._last_check = now

#         if self._provider == "local":
#             if not self._ollama.is_running():
#                 self._available = False
#                 return False
#             if self._ollama_model:
#                 # Verify the chosen model exists
#                 available_models = self._ollama.list_models()
#                 self._available = any(
#                     self._ollama_model.lower() == m.lower() or
#                     m.lower().startswith(self._ollama_model.lower())
#                     for m in available_models
#                 )
#             else:
#                 # Auto-select first available model
#                 models = self._ollama.list_models()
#                 if models:
#                     self._ollama_model = models[0]
#                     self._available    = True
#                 else:
#                     self._available = False
#         elif self._provider == "claude":
#             self._available = self._claude is not None
#         elif self._provider == "openai":
#             self._available = self._openai is not None
#         elif self._provider == "nvidia":
#             self._available = self._nvidia is not None
#         else:
#             self._available = False

#         return self._available

#     @property
#     def model_name(self) -> str:
#         if self._provider == "local":
#             return self._ollama_model or "rule-based"
#         elif self._provider == "claude":
#             return self._claude.model if self._claude else "claude (no key)"
#         elif self._provider == "openai":
#             return self._openai.model if self._openai else "openai (no key)"
#         elif self._provider == "nvidia":
#             return self._nvidia.model if self._nvidia else "openai (no key)"
#         return "rule-based"

#     # ── Public interface ───────────────────────────────────────────────────

#     def analyze_context(self, context: DiagnosticContext) -> str:
#         prompt = (
#             "Analyze the following real-time system diagnostic data. "
#             "Identify issues, explain root causes, and provide specific actionable steps:\n\n"
#             f"{context.to_prompt_text()}"
#         )
#         return self._infer_single(prompt)

#     def chat(
#         self,
#         user_message: str,
#         context: Optional[DiagnosticContext] = None,
#         history: Optional[list] = None,
#     ) -> str:
#         if not self.available:
#             return self._rule_based(user_message, context)

#         messages: list = []

#         if context:
#             ctx_block = self._compact_ctx(context)
#             messages.append({"role": "user",      "content": f"[CURRENT SYSTEM STATE]\n{ctx_block}"})
#             messages.append({"role": "assistant",  "content": "Understood. I have the current system state. What would you like to know?"})

#         if history:
#             for t in history[-6:]:
#                 if t.get("role") in ("user", "assistant") and t.get("content"):
#                     messages.append(t)

#         messages.append({"role": "user", "content": user_message})

#         try:
#             return self._infer_chat(messages)
#         except Exception as exc:
#             logger.error(f"[{self._provider}] chat error: {exc}")
#             self._available = None
#             return self._rule_based(user_message, context)

#     def get_status(self) -> dict:
#         running = self._ollama.is_running() if self._provider == "local" else None
#         models  = self._ollama.list_models() if (self._provider == "local" and running) else []
#         return {
#             "provider":       self._provider,
#             "model":          self.model_name,
#             "available":      self.available,
#             "ollama_running": running,
#             "ollama_models":  models,
#             "claude_models":  ClaudeClient.MODELS,
#             "openai_models":  OpenAIClient.MODELS,
#             "nvidia_models": NvidiaClient.MODELS,
#         }

#     def get_ollama_models(self) -> list:
#         return self._ollama.list_models()

#     # ── Internal inference ─────────────────────────────────────────────────

#     def _infer_single(self, prompt: str) -> str:
#         if not self.available:
#             return self._rule_based(prompt, None)
#         try:
#             if self._provider == "local":
#                 return self._ollama.generate(prompt, SYSTEM_PROMPT, self._ollama_model, self._gen_options)
#             elif self._provider in ("claude", "openai",'nvidia'):
#                 return self._infer_chat([{"role": "user", "content": prompt}])
#         except Exception as exc:
#             logger.error(f"[{self._provider}] infer error: {exc}")
#             self._available = None
#             return self._rule_based(prompt, None)

#     def _infer_chat(self, messages: list) -> str:
#         if self._provider == "local":
#             full = [{"role": "system", "content": SYSTEM_PROMPT}] + messages
#             return self._ollama.chat(full, self._ollama_model, self._gen_options)
#         elif self._provider == "claude":
#             return self._claude.chat(messages)
#         elif self._provider == "openai":
#             return self._openai.chat(messages)
#         elif self._provider == "nvidia":
#             return self._nvidia.chat(messages)
#         raise ValueError(f"Unknown provider: {self._provider}")

#     def _compact_ctx(self, ctx: DiagnosticContext) -> str:
#         m = ctx.metrics
#         h = ctx.health
#         lines = [
#             f"Health: {h.get('score','?')}/100 — {h.get('label','?')}",
#             f"CPU: {m.get('cpu_percent',0):.1f}%  MEM: {m.get('memory_percent',0):.1f}%  "
#             f"DISK: {m.get('disk_percent',0):.1f}%  NET latency: {m.get('network_latency_ms',0):.0f}ms",
#         ]
#         if ctx.violations:
#             lines.append(f"ACTIVE ALERTS ({len(ctx.violations)}):")
#             for v in ctx.violations[:4]:
#                 lines.append(f"  [{v.get('severity','').upper()}] {v.get('message','')}")
#         if ctx.top_processes:
#             lines.append("Top processes (CPU):")
#             for p in ctx.top_processes[:5]:
#                 lines.append(f"  {p.get('name','?'):20s}  CPU:{p.get('cpu_percent',0):5.1f}%  MEM:{p.get('memory_mb',0):6.0f}MB")
#         if ctx.predictions:
#             for pr in ctx.predictions[:2]:
#                 if pr.get("time_to_critical_hours"):
#                     lines.append(f"PREDICTION: {pr.get('message','')}")
#         return "\n".join(lines)

#     # ── Rule-based fallback ────────────────────────────────────────────────

#     def _rule_based(self, prompt: str, context: Optional[DiagnosticContext]) -> str:
#         p = prompt.lower()
#         header = ""
#         if context:
#             m = context.metrics
#             h = context.health
#             score = h.get("score", 0)
#             icon  = "✅" if score >= 85 else "⚠️" if score >= 55 else "🔴"
#             header = (
#                 f"{icon} **Health: {score}/100 — {h.get('label','?')}**\n"
#                 f"CPU `{m.get('cpu_percent',0):.1f}%` · "
#                 f"Memory `{m.get('memory_percent',0):.1f}%` · "
#                 f"Disk `{m.get('disk_percent',0):.1f}%`\n\n"
#             )
#             if context.violations:
#                 v = context.violations[0]
#                 return (
#                     header
#                     + f"⚠ **Active Alert [{v.get('severity','').upper()}]**\n{v.get('message','')}\n\n"
#                     + "**Recommended Actions:**\n"
#                     + "1. Open **Processes** tab — sort by CPU or Memory\n"
#                     + "2. Click **Kill** on non-critical high-usage processes\n"
#                     + "3. Run **Clear Temp Files** to free disk and I/O pressure\n\n"
#                     + "> 💡 Configure an LLM in the AI Settings panel for detailed analysis."
#                 )

#         if any(k in p for k in ("cpu", "processor", "load")):
#             return header + "**CPU Analysis**\n\nCommon causes of high CPU:\n- Browser tabs running heavy JavaScript or video\n- Background antivirus / Windows Update scans\n- Developer tools: compilers, bundlers, test runners\n\n**Actions:**\n1. Check **Processes → CPU** for the top consumer\n2. Close idle browser tabs or restart the browser\n3. Use **Kill Process** for non-critical runaway tasks"

#         if any(k in p for k in ("memory", "ram", "mem", "leak")):
#             return header + "**Memory Analysis**\n\nCommon causes:\n- Long-running apps with memory leaks (browsers, Electron apps, IDEs)\n- Virtual machines or Docker containers with reserved memory\n\n**Actions:**\n1. Check **Processes → Memory** — look for apps > 1 GB\n2. Restart browsers and IDEs if open for days\n3. Click **Optimize Memory** in the remediation panel"

#         if any(k in p for k in ("disk", "storage", "space", "full")):
#             return header + "**Disk Analysis**\n\nCommon causes:\n- Temp files and crash dumps from installers/apps\n- Log files from web servers, databases, or dev tools\n\n**Actions:**\n1. Click **Clear Temp Files** — typically recovers 1–10 GB\n2. Use WizTree or WinDirStat to find largest folders\n3. Delete `node_modules` in unused projects"

#         if any(k in p for k in ("network", "internet", "latency", "slow", "dns")):
#             return header + "**Network Analysis**\n\nCommon causes:\n- Background sync (OneDrive, Dropbox) saturating upload\n- Stale DNS cache causing resolution delays\n\n**Actions:**\n1. Click **Reset Network** to flush DNS and reset Winsock\n2. Pause cloud sync apps temporarily\n3. Run `ping 8.8.8.8 -t` to check for packet loss"

#         if any(k in p for k in ("health", "overview", "status", "analyze", "summary")):
#             if context:
#                 score = context.health.get("score", 0)
#                 label = context.health.get("label", "Unknown")
#                 icon  = "✅" if score >= 85 else "⚠️" if score >= 55 else "🔴"
#                 return f"{icon} **System Health: {score}/100 — {label}**\n\n{context.health.get('summary', '')}\n\n**Next steps:**\n- Open **Processes** to review the workload\n- If score < 70, kill the heaviest non-essential process\n- Run **Clear Temp Files** for a quick win on disk\n\n> 💡 Configure an LLM in the AI Settings panel for full AI analysis."

#         provider_hint = {
#             "local":  "> 💡 Start Ollama and select a model in the AI Settings panel.",
#             "claude": "> 💡 Enter your Claude API key in the AI Settings panel.",
#             "openai": "> 💡 Enter your OpenAI API key in the AI Settings panel.",
#             "nvidia": "> 💡 Enter your Nvidia API key in the AI Settings panel.",
#         }.get(self._provider, "> 💡 Configure an LLM in the AI Settings panel.")

#         return (
#             header
#             + "**Workplace Assist — Rule-Based Mode**\n\n"
#             + "AI inference is not configured. Monitoring, alerts, and remediation all work normally.\n\n"
#             + "**Ask about:** CPU · Memory · Disk · Network · Health Overview\n\n"
#             + provider_hint
#         )
