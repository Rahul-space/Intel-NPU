"""
generate_icons.py
=================
Generates all tray icon PNG files and a Windows .ico file
from scratch using Pillow. No design tools needed.

Run once before building:
    python generate_icons.py

Creates in electron/assets/:
    icon.ico          — Windows app + installer icon (256x256 multi-res)
    tray-green.png    — Healthy (teal circle)
    tray-yellow.png   — Degraded (amber circle)
    tray-red.png      — Critical (red circle)
    tray-loading.png  — Starting (grey circle)
"""

import sys
import struct
import zlib
from pathlib import Path

ASSETS = Path(__file__).parent / "electron" / "assets"
ASSETS.mkdir(parents=True, exist_ok=True)


def make_png_bytes(width, height, bg_color, text_color, letter="S", badge_color=None):
    """
    Pure-Python PNG generator (no Pillow required).
    Generates a simple coloured circle with letter 'S'.
    """
    try:
        from PIL import Image, ImageDraw, ImageFont
        return _make_png_pillow(width, height, bg_color, text_color, letter, badge_color)
    except ImportError:
        return _make_minimal_png(width, height, bg_color)


def _make_png_pillow(width, height, bg_color, text_color, letter, badge_color):
    from PIL import Image, ImageDraw, ImageFont

    img  = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Dark background square with rounded corners
    pad = max(1, width // 8)
    draw.rounded_rectangle([0, 0, width-1, height-1], radius=width//6, fill=(13, 15, 20, 255))

    # Coloured circle
    cr = width // 2 - pad
    cx, cy = width // 2, height // 2
    draw.ellipse([cx-cr, cy-cr, cx+cr, cy+cr], fill=bg_color)

    # Letter
    try:
        font_size = int(width * 0.45)
        font = ImageFont.truetype("arial.ttf", font_size)
    except Exception:
        font = ImageFont.load_default()

    bbox = draw.textbbox((0, 0), letter, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    tx = cx - tw // 2 - bbox[0]
    ty = cy - th // 2 - bbox[1]
    draw.text((tx, ty), letter, fill=text_color, font=font)

    import io
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def _make_minimal_png(width, height, fill_color):
    """Fallback: solid-colour PNG without Pillow."""
    r, g, b = fill_color[:3]
    a = fill_color[3] if len(fill_color) > 3 else 255

    def to_bytes(w, h, pixels):
        def chunk(name, data):
            crc = zlib.crc32(name + data) & 0xFFFFFFFF
            return struct.pack('>I', len(data)) + name + data + struct.pack('>I', crc)

        raw = b''
        for row in pixels:
            raw += b'\x00' + bytes([v for px in row for v in px])
        compressed = zlib.compress(raw)

        sig   = b'\x89PNG\r\n\x1a\n'
        ihdr  = chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
        idat  = chunk(b'IDAT', compressed)
        iend  = chunk(b'IEND', b'')
        return sig + ihdr + idat + iend

    pixels = [[(r, g, b)] * width for _ in range(height)]
    return to_bytes(width, height, pixels)


def save_icon(filename, width, height, bg_color, text_color=(13, 15, 20), letter="S"):
    data = make_png_bytes(width, height, bg_color, text_color, letter)
    path = ASSETS / filename
    path.write_bytes(data)
    print(f"  ✓  {path.name}  ({width}x{height})")


def save_ico(filename):
    """Convert tray-green.png to .ico with multiple resolutions."""
    try:
        from PIL import Image
        src = ASSETS / "icon-256.png"
        if not src.exists():
            print(f"  ⚠  {src} not found — skipping .ico")
            return
        img = Image.open(src).convert("RGBA")
        sizes = [(16,16), (32,32), (48,48), (64,64), (128,128), (256,256)]
        ico_path = ASSETS / filename
        img.save(ico_path, format="ICO", sizes=sizes)
        print(f"  ✓  {ico_path.name}  (multi-resolution ICO)")
    except ImportError:
        print("  ⚠  Pillow not installed — .ico not generated (tray PNG will be used)")
    except Exception as e:
        print(f"  ⚠  ICO generation failed: {e}")


def main():
    print("""
╔══════════════════════════════════════════════════════╗
║    SysAssist — Icon Generator                        ║
╚══════════════════════════════════════════════════════╝
""")
    print(f"  Output: {ASSETS}\n")

    TEAL   = (0,  212, 160, 255)
    AMBER  = (245, 158, 11, 255)
    RED    = (239, 68,  68, 255)
    GREY   = (80,  85,  100, 255)
    DARK   = (13,  15,  20)

    # Tray icons (16x16 displayed by Windows)
    save_icon("tray-green.png",   64, 64, TEAL,  DARK)
    save_icon("tray-yellow.png",  64, 64, AMBER, DARK)
    save_icon("tray-red.png",     64, 64, RED,   DARK)
    save_icon("tray-loading.png", 64, 64, GREY,  DARK)

    # High-res for app icon
    save_icon("icon-256.png",    256, 256, TEAL, DARK)
    save_icon("icon-128.png",    128, 128, TEAL, DARK)
    save_icon("icon-64.png",      64,  64, TEAL, DARK)

    # Windows .ico
    save_ico("icon.ico")

    print("\n  All icons generated ✓")
    print("  Now run: npm run build\n")


if __name__ == "__main__":
    main()
