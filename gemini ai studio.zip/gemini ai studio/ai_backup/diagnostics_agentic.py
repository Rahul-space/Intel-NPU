# """
# Workplace Assist — Agentic AI Engine  v2.3.0
# =================================================
# ONE FILE. Fully agentic backend using AutoGen v0.4 (autogen-agentchat).
# Local-only: Ollama via OpenAI-compatible endpoint.

# What makes this AGENTIC (not Gen AI):
#   Gen AI  → pack a context blob into a prompt → get text back. One shot.
#   Agentic → agents DECIDE what tools to call, in what order, based on
#             what they find. The LLM controls the investigation flow.

#   Example: Agent calls get_system_metrics() → sees CPU 91% → decides to
#   call get_top_processes() → finds chrome.exe → proposes kill_process().
#   That chain of decisions based on real data = agency.

# APPROVAL GATE — remediations NEVER execute without user approval:
#   Agent builds plan → UI shows proposal → user clicks Approve/Dismiss
#   Only on Approve does the agent call any action tool.

# Install:
#   pip install autogen-agentchat autogen-ext[openai]

# Ollama:
#   ollama pull llama3.2   # or phi3, mistral, etc.
# """

# import asyncio
# import json
# import logging
# import socket
# import time
# import threading
# import urllib.request
# import uuid
# from typing import Optional, Callable

# from agent.context_builder import DiagnosticContext

# logger = logging.getLogger(__name__)

# # ── AutoGen v0.4 ──────────────────────────────────────────────────────────
# try:
#     from autogen_agentchat.agents import AssistantAgent
#     from autogen_agentchat.teams import RoundRobinGroupChat
#     from autogen_agentchat.conditions import TextMentionTermination, MaxMessageTermination
#     from autogen_ext.models.openai import OpenAIChatCompletionClient
#     AUTOGEN_OK = True
#     logger.info("[AgenticAI] autogen-agentchat loaded ✓")
# except ImportError as _e:
#     AUTOGEN_OK = False
#     logger.warning(f"[AgenticAI] autogen-agentchat not installed: {_e}")
#     logger.warning("  Run: pip install autogen-agentchat autogen-ext[openai]")

# # ─────────────────────────────────────────────────────────────────
# #  SYSTEM PROMPTS
# # ─────────────────────────────────────────────────────────────────

# _DIAG_PROMPT = """\
# You are the Cognix Diagnostician — a Windows endpoint performance expert.
# You have READ-ONLY tools. Investigate the live system and report findings.

# Protocol (always in this order):
#   1. get_system_metrics()        → baseline, always call this first
#   2. get_active_violations()     → what thresholds are breached?
#   3. CPU > 70%  → get_top_processes(10)
#   4. MEM > 65%  → get_top_processes(10) + get_metric_trend('memory')
#   5. DISK > 80% → check disk values from metrics
#   6. get_predictions()           → is this getting worse?
#   7. get_metric_history(12)      → spike or sustained problem?

# Output format (required):
# ## Findings
# **Current State:** [key metrics with real values from tools]
# **Issues Detected:** [named processes, exact %s — or "None" if healthy]
# **Root Cause:** [1-2 sentence explanation]
# **Severity:** CRITICAL | WARNING | INFO | HEALTHY
# **Urgency:** immediate / monitor / none

# Be specific. Quote actual numbers. Name actual processes.
# Do NOT suggest fixes — the Remediator handles that."""

# _REM_PROMPT = """\
# You are the Cognix Remediator. You receive Diagnostician findings and
# build a safe remediation plan. You NEVER execute tools until the user
# approves by typing APPROVED.

# Available actions:
#   kill_process(pid, reason)   — kill a process (get PID from get_top_processes)
#   clear_temp_files()          — delete temp files, safe, recovers 1-10 GB
#   reset_network()             — flush DNS + reset Winsock (~5s interruption)
#   optimize_memory()           — empty Windows standby cache, always safe

# PHASE 1 — after receiving findings, output ONLY this plan format:
# ---REMEDIATION PLAN---
# Issue: [what was found]
# Actions:
#   1. [action_name(args)] — [reason] — Risk: LOW/MEDIUM
#   2. ...
# Waiting for your approval. Reply APPROVED to execute, or DISMISSED to cancel.
# ---END PLAN---

# PHASE 2 — only after seeing APPROVED in the conversation:
#   Call each tool in your plan. Report the result of each.
#   Then output: REMEDIATION_COMPLETE

# Safety rules — NEVER violate:
#   ✗ Do NOT call action tools before seeing APPROVED
#   ✗ Do NOT kill: lsass.exe, csrss.exe, winlogon.exe, smss.exe, services.exe
#   ✗ Do NOT reset_network if latency < 100ms
#   ✓ clear_temp_files and optimize_memory are always safe choices"""

# _CHAT_PROMPT = """You are Cognix — a friendly, expert device assistant running on this Windows machine.
# You have live tools to check the real system state before answering.

# CRITICAL RULES — ALWAYS FOLLOW:
#   1. NEVER return raw JSON, dictionaries, or code to the user. Ever.
#      Always convert tool results into plain conversational English.
#   2. ALWAYS call tools before answering questions about the system.
#      Do not guess or use cached context — get live data first.
#   3. Be concise. 2-4 sentences or a small bullet list — not walls of text.
#   4. Use plain language. The user is not a developer.

# RESPONSE STYLE — GOOD EXAMPLES:
#   User: "Is my system ok?"
#   → Call get_system_metrics(), then reply:
#     "Your system looks healthy — score 87/100. CPU at 12%, memory 48%, disk 31%. Nothing to worry about."

#   User: "What's using the most CPU?"
#   → Call get_top_processes(8), then reply:
#     "**chrome.exe** is the top consumer at 18% CPU, followed by `node.exe` at 12%. Everything else is under 5%."

#   User: "Check my battery"
#   → Call get_battery_status(), then reply:
#     "Battery is at 74%, currently charging. Health score 82/100 — good condition."

#   User: "Is my disk space ok?"
#   → Call get_system_metrics(), then reply:
#     "Disk is at 61% used (245 GB of 400 GB free). You have some room but it is worth monitoring."

# FOR FIX REQUESTS: investigate → explain what you found in plain English →
#   propose what you will do → ask the user: "Want me to go ahead? Reply **yes** to proceed."
#   Only call action tools (kill_process, clear_temp_files etc.) after the user says yes.

# TOOL ORDER for general status questions:
#   1. get_system_metrics()     — always first
#   2. get_active_violations()  — any active alerts?
#   3. get_top_processes(8)     — if CPU or memory is high"""



# # ─────────────────────────────────────────────────────────────────
# #  PROTECTED PROCESSES — never kill these
# # ─────────────────────────────────────────────────────────────────
# _PROTECTED = {
#     "lsass.exe", "csrss.exe", "winlogon.exe", "smss.exe",
#     "services.exe", "wininit.exe", "system", "registry",
# }


# # ─────────────────────────────────────────────────────────────────
# #  TOOL FACTORY  — closures over live state
# # ─────────────────────────────────────────────────────────────────

# def _make_tools(state, remediation, battery_col=None, security_col=None):
#     """
#     Returns (read_tools, action_tools) — plain Python closures over
#     live AgentState and RemediationEngine.
#     AutoGen v0.4 accepts plain functions directly as tools.
#     """

#     # ── READ TOOLS ───────────────────────────────────────────────

#     def get_system_metrics() -> dict:
#         """Get live CPU%, memory%, disk%, network latency ms, GPU%, and health score/label."""
#         if not state or not state.latest_metrics:
#             return {"error": "Metrics not yet collected, retry in a few seconds"}
#         m, h = state.latest_metrics, state.latest_health
#         return {
#             "cpu_percent":        round(m.cpu_percent, 1),
#             "cpu_cores":          m.cpu_core_count,
#             "memory_percent":     round(m.memory_percent, 1),
#             "memory_used_gb":     round(m.memory_used_gb, 1),
#             "memory_total_gb":    round(m.memory_total_gb, 1),
#             "disk_percent":       round(m.disk_percent, 1),
#             "disk_used_gb":       round(m.disk_used_gb, 1),
#             "disk_total_gb":      round(m.disk_total_gb, 1),
#             "disk_read_mbps":     round(m.disk_read_mbps, 2),
#             "disk_write_mbps":    round(m.disk_write_mbps, 2),
#             "network_latency_ms": round(m.network_latency_ms),
#             "network_sent_mbps":  round(m.network_sent_mbps, 2),
#             "network_recv_mbps":  round(m.network_recv_mbps, 2),
#             "gpu_percent":        round(m.gpu_percent, 1),
#             "gpu_name":           m.gpu_name,
#             "health_score":       h.score if h else 0,
#             "health_label":       h.label if h else "Unknown",
#             "as_of":              time.strftime("%H:%M:%S", time.localtime(m.timestamp)),
#         }

#     def get_top_processes(limit: int = 10) -> list:
#         """Get top N processes by CPU%. limit: 1-20. Each entry has pid, name,
#         cpu_percent, memory_mb, status. Use pid values for kill_process()."""
#         if not state:
#             return []
#         return [
#             {"pid": p.pid, "name": p.name,
#              "cpu_percent": round(p.cpu_percent, 1),
#              "memory_mb": round(p.memory_mb), "status": p.status}
#             for p in state.latest_processes[:min(int(limit), 20)]
#         ]

#     def get_active_violations() -> list:
#         """Get current threshold violations. Empty list means system is healthy.
#         Each has: metric, severity (warning|critical), current_value, threshold,
#         message, sustained_seconds."""
#         if not state:
#             return []
#         return [
#             {"metric": v.metric, "severity": v.severity.value,
#              "current_value": round(v.current_value, 1),
#              "threshold": v.threshold, "message": v.message,
#              "sustained_seconds": round(v.sustained_seconds)}
#             for v in state.active_violations
#         ]

#     def get_metric_trend(metric: str) -> dict:
#         """Trend for a metric: 'cpu'|'memory'|'disk'|'network_latency'.
#         Returns direction (rising/stable/falling), slope, change_rate.
#         Use to tell if a high reading is a spike or a growing problem."""
#         valid = ("cpu", "memory", "disk", "network_latency")
#         if metric not in valid:
#             return {"error": f"metric must be one of: {', '.join(valid)}"}
#         if not state or not state.latest_context:
#             return {"metric": metric, "direction": "unknown"}
#         t = state.latest_context.trends.get(metric)
#         if not t:
#             return {"metric": metric, "direction": "stable", "note": "Not enough data yet"}
#         return {"metric": metric, "direction": t.get("direction", "stable"),
#                 "slope": round(t.get("slope", 0), 3),
#                 "change_rate_pct": round(t.get("change_rate", 0), 2)}

#     def get_predictions() -> list:
#         """Predictive forecasts for CPU/memory/disk.
#         Returns time_to_critical_hours and predicted values at 1h/24h.
#         Empty list = no concerning trends."""
#         if not state or not state.latest_context:
#             return []
#         return state.latest_context.predictions or []

#     def get_metric_history(points: int = 12) -> dict:
#         """Last N snapshots (~5s each, max 60 = ~5 min).
#         Useful for spotting spikes vs sustained problems."""
#         if not state:
#             return {"error": "State unavailable"}
#         pts = state.metric_history[-min(int(points), 60):]
#         return {"count": len(pts), "interval_seconds": 5, "history": pts}

#     def get_system_info() -> dict:
#         """Static device info: hostname, OS, CPU model, total RAM, architecture."""
#         return state.system_info if state else {}

#     def get_battery_status() -> dict:
#         """Battery level%, plugged_in, time_left_minutes, health score.
#         Returns error for desktops/VMs without a battery."""
#         try:
#             import psutil
#             b = psutil.sensors_battery()
#             if not b:
#                 return {"error": "No battery (desktop or VM)"}
#             result = {"percent": round(b.percent, 1), "plugged_in": b.power_plugged,
#                       "time_left_minutes": round(b.secsleft / 60) if b.secsleft and b.secsleft > 0 else None}
#             if battery_col:
#                 try:
#                     result.update(battery_col.collect())
#                 except Exception:
#                     pass
#             return result
#         except Exception as e:
#             return {"error": str(e)}

#     def get_security_status() -> dict:
#         """AV/BitLocker/firewall compliance status, overall score, detected threats."""
#         if not security_col:
#             return {"error": "Security collector not bound"}
#         try:
#             return security_col.collect()
#         except Exception as e:
#             return {"error": str(e)}

#     # ── ACTION TOOLS (only call after APPROVED) ──────────────────

#     def kill_process(pid: int, reason: str = "") -> dict:
#         """Kill a process by PID. Get pid from get_top_processes().
#         ONLY call this after user has approved the remediation plan.
#         Protected system processes are automatically blocked."""
#         if not remediation:
#             return {"success": False, "message": "Remediation engine not bound"}
#         try:
#             import psutil
#             proc = psutil.Process(int(pid))
#             if proc.name().lower() in _PROTECTED:
#                 return {"success": False,
#                         "message": f"BLOCKED: '{proc.name()}' is a protected system process"}
#         except Exception:
#             pass
#         logger.info(f"[Tool] kill_process pid={pid} reason={reason!r}")
#         r = remediation.kill_process(int(pid))
#         return {"success": r.success, "message": r.message, "details": r.details or ""}

#     def clear_temp_files() -> dict:
#         """Delete Windows temp files. Safe. Typically recovers 1-10 GB.
#         ONLY call this after user has approved the remediation plan."""
#         if not remediation:
#             return {"success": False, "message": "Remediation engine not bound"}
#         logger.info("[Tool] clear_temp_files")
#         r = remediation.clear_temp_files()
#         return {"success": r.success, "message": r.message, "details": r.details or ""}

#     def reset_network() -> dict:
#         """Flush DNS cache and reset Winsock (~5s network interruption).
#         Use when latency > 200ms. ONLY call after user approval."""
#         if not remediation:
#             return {"success": False, "message": "Remediation engine not bound"}
#         logger.info("[Tool] reset_network")
#         r = remediation.reset_network()
#         return {"success": r.success, "message": r.message, "details": r.details or ""}

#     def optimize_memory() -> dict:
#         """Empty Windows standby cache. Safe, Windows refills as needed.
#         ONLY call after user has approved the remediation plan."""
#         if not remediation:
#             return {"success": False, "message": "Remediation engine not bound"}
#         logger.info("[Tool] optimize_memory")
#         r = remediation.optimize_memory()
#         return {"success": r.success, "message": r.message, "details": r.details or ""}

#     read_tools   = [get_system_metrics, get_top_processes, get_active_violations,
#                     get_metric_trend, get_predictions, get_metric_history,
#                     get_system_info, get_battery_status, get_security_status]
#     action_tools = [kill_process, clear_temp_files, reset_network, optimize_memory]

#     return read_tools, action_tools


# # ─────────────────────────────────────────────────────────────────
# #  OLLAMA  single-shot client (fallback when AutoGen not installed)
# # ─────────────────────────────────────────────────────────────────

# _SYSTEM_PROMPT_FALLBACK = """\
# You are Workplace Assist, an expert endpoint performance diagnostics assistant.
# Be concise. Reference specific values. Use **bold** for key terms.
# Use `backticks` for process names. Number all recommendations.
# If healthy, say so in 1-2 lines. Never invent data."""

# class _OllamaClient:
#     def __init__(self, base_url="http://127.0.0.1:11434", timeout=120):
#         self.base_url = base_url.rstrip("/")
#         self.timeout  = timeout

#     def is_running(self) -> bool:
#         try:
#             with socket.create_connection(("127.0.0.1", 11434), timeout=2):
#                 return True
#         except OSError:
#             return False

#     def list_models(self) -> list:
#         try:
#             with urllib.request.urlopen(
#                 urllib.request.Request(f"{self.base_url}/api/tags"), timeout=5
#             ) as r:
#                 return [m.get("name", "") for m in json.loads(r.read()).get("models", [])]
#         except Exception:
#             return []

#     def chat(self, messages: list, model: str, options: dict) -> str:
#         payload = json.dumps({"model": model, "messages": messages,
#                               "stream": False, "options": options}).encode()
#         req = urllib.request.Request(
#             f"{self.base_url}/api/chat", data=payload,
#             headers={"Content-Type": "application/json"}, method="POST")
#         with urllib.request.urlopen(req, timeout=self.timeout) as r:
#             return json.loads(r.read()).get("message", {}).get("content", "").strip()


# # ─────────────────────────────────────────────────────────────────
# #  PENDING PROPOSAL  — approval gate state
# # ─────────────────────────────────────────────────────────────────

# class _Proposal:
#     """A remediation plan waiting for user approval."""
#     def __init__(self, session_id: str, findings: str, plan_text: str, trigger: str):
#         self.session_id  = session_id
#         self.findings    = findings
#         self.plan_text   = plan_text
#         self.trigger     = trigger          # 'analyze' | 'chat' | 'monitor'
#         self.created_at  = time.time()
#         self.approved    = False
#         self.dismissed   = False
#         self._event      = asyncio.Event()  # set when user decides

#     def to_dict(self) -> dict:
#         return {"session_id": self.session_id, "findings": self.findings,
#                 "plan_text": self.plan_text, "trigger": self.trigger,
#                 "created_at": self.created_at}


# # ─────────────────────────────────────────────────────────────────
# #  MAIN ENGINE  (public facade — api/server.py talks only to this)
# # ─────────────────────────────────────────────────────────────────

# class AIDiagnosticEngine:
#     """
#     Agentic AI engine backed by AutoGen v0.4 + local Ollama.

#     Same public interface as the original engine — api/server.py unchanged
#     except for the three new approval endpoints added in server.py.

#     Architecture:
#       analyze_context() → Diagnostician agent (read tools only, no approval needed)
#       chat()            → ChatAssistant agent (all tools, asks before acting)
#       Approval gate     → approve(session_id) / dismiss(session_id)

#     Fallback when AutoGen not installed:
#       Single-shot Ollama → rule-based text responses
#     """

#     GENERATION_DEFAULTS = {
#         "temperature": 0.3, "top_p": 0.9, "top_k": 40,
#         "num_predict": 1024, "num_ctx": 4096, "repeat_penalty": 1.1,
#     }

#     def __init__(self):
#         self._ollama        = _OllamaClient()
#         self._ollama_model: Optional[str] = None
#         self._gen_opts      = dict(self.GENERATION_DEFAULTS)
#         self._available     = None
#         self._last_check    = 0.0
#         self._provider      = "local"

#         # AutoGen model client (set by set_local_model)
#         self._model_client  = None

#         # Live tool references (set by bind_tools)
#         self._read_tools    = []
#         self._action_tools  = []

#         # WebSocket broadcast (set by bind_tools)
#         self._broadcast: Optional[Callable] = None

#         # Pending proposals waiting for user decision
#         self._proposals: dict[str, _Proposal] = {}

#         logger.info(
#             f"[AgenticAI] AutoGen available: {AUTOGEN_OK} — "
#             f"{'agentic mode' if AUTOGEN_OK else 'single-shot fallback mode'}"
#         )

#     # ──────────────────────────────────────────────────────────────
#     #  SETUP  (called from server.py create_app)
#     # ──────────────────────────────────────────────────────────────

#     def bind_tools(self, state, remediation_engine,
#                    battery_collector=None, security_collector=None,
#                    broadcast_fn: Optional[Callable] = None):
#         """
#         Wire live AgentState + RemediationEngine into the tool closures.
#         Must be called after the scheduler starts. Called from server.py.
#         """
#         self._read_tools, self._action_tools = _make_tools(
#             state, remediation_engine, battery_collector, security_collector
#         )
#         self._broadcast = broadcast_fn
#         logger.info(f"[AgenticAI] Tools bound — "
#                     f"{len(self._read_tools)} read, {len(self._action_tools)} action")

#     def set_local_model(self, model_name: str) -> dict:
#         """Set the Ollama model. Builds the AutoGen model client."""
#         self._ollama_model = model_name
#         self._available    = None
#         self._last_check   = 0.0

#         if not self._ollama.is_running():
#             return {"provider": "local", "model": model_name,
#                     "available": False, "message": "Ollama is not running"}

#         if not AUTOGEN_OK:
#             return {
#                 "provider": "local", "model": model_name,
#                 "available": True, "agentic": False,
#                 "message": (
#                     f"Ollama connected ({model_name}) — single-shot mode. "
#                     "Run: pip install autogen-agentchat autogen-ext[openai] for agentic mode."
#                 ),
#             }

#         try:
#             base = "http://127.0.0.1:11434/v1"
#             self._model_client = OpenAIChatCompletionClient(
#                 model    = model_name,
#                 base_url = base,
#                 api_key  = "ollama",
#                 model_capabilities={
#                     "vision": False,
#                     "function_calling": True,
#                     "json_output": False,
#                 },
#             )
#             logger.info(f"[AgenticAI] Model client ready: {model_name}")
#             return {
#                 "provider": "local", "model": model_name,
#                 "available": True, "agentic": True,
#                 "message": f"Agentic AI ready — {model_name} via Ollama",
#             }
#         except Exception as e:
#             self._model_client = None
#             logger.error(f"[AgenticAI] set_model error: {e}")
#             return {"provider": "local", "model": model_name,
#                     "available": False, "message": str(e)[:200]}

#     # ──────────────────────────────────────────────────────────────
#     #  APPROVAL GATE
#     # ──────────────────────────────────────────────────────────────

#     def approve_proposal(self, session_id: str) -> bool:
#         p = self._proposals.get(session_id)
#         if not p or p._event.is_set():
#             return False
#         p.approved = True
#         p._event.set()
#         logger.info(f"[AgenticAI] Proposal approved: {session_id}")
#         return True

#     def dismiss_proposal(self, session_id: str) -> bool:
#         p = self._proposals.get(session_id)
#         if not p or p._event.is_set():
#             return False
#         p.dismissed = True
#         p._event.set()
#         logger.info(f"[AgenticAI] Proposal dismissed: {session_id}")
#         return True

#     def get_pending_proposals(self) -> list:
#         now = time.time()
#         return [p.to_dict() for p in self._proposals.values()
#                 if not p._event.is_set() and (now - p.created_at) < 300]

#     # ──────────────────────────────────────────────────────────────
#     #  MAIN PUBLIC INTERFACE  (async — called directly from server.py)
#     # ──────────────────────────────────────────────────────────────

#     async def analyze_context_async(self, context: DiagnosticContext) -> str:
#         """
#         Agentic tab analysis — called by Analyze Now button on every tab.
#         Diagnostician uses live tools to investigate. Read-only, no approval needed.
#         Returns formatted markdown text for the UI.
#         """
#         if not self._model_client:
#             return self._fallback_analyze(context)

#         try:
#             diag = AssistantAgent(
#                 name           = "Diagnostician",
#                 model_client   = self._model_client,
#                 system_message = _DIAG_PROMPT,
#                 tools          = self._read_tools,
#             )
#             term  = TextMentionTermination("## Findings") | MaxMessageTermination(12)
#             team  = RoundRobinGroupChat([diag], termination_condition=term)
#             ctx   = self._format_context(context)
#             result = await team.run(
#                 task=f"System snapshot (use tools for live data):\n{ctx}\n\n"
#                      "Investigate now and produce your ## Findings report."
#             )
#             text = self._last_message(result)
#             return text if text else "System appears healthy — no issues detected."

#         except Exception as e:
#             logger.error(f"[AgenticAI] analyze error: {e}", exc_info=True)
#             return self._fallback_analyze(context)

#     async def chat_async(self, user_message: str,
#                          context: Optional[DiagnosticContext] = None,
#                          history: Optional[list] = None) -> str:
#         """
#         Agentic chat — agent fetches live data with tools before answering.
#         For remediation requests: agent proposes → user approves → agent executes.
#         """
#         if not self._model_client:
#             return self._fallback_chat(user_message, context)

#         try:
#             ctx_text = self._format_context(context) if context else \
#                        "No context. Use get_system_metrics() for current data."

#             hist_text = ""
#             if history:
#                 hist_text = "\n[Recent conversation]\n" + "\n".join(
#                     f"{t.get('role','?').upper()}: {(t.get('content') or '')[:300]}"
#                     for t in history[-6:]
#                 ) + "\n"

#             agent = AssistantAgent(
#                 name           = "CognixAssistant",
#                 model_client   = self._model_client,
#                 system_message = _CHAT_PROMPT,
#                 tools          = self._read_tools + self._action_tools,
#             )
#             term   = MaxMessageTermination(8)
#             team   = RoundRobinGroupChat([agent], termination_condition=term)
#             result = await team.run(
#                 task=f"System context:\n{ctx_text}\n{hist_text}\nUser: {user_message}"
#             )
#             response = self._last_message(result)

#             # If agent is asking for approval to execute, register a proposal
#             if response and any(kw in response.lower() for kw in
#                ("shall i proceed", "reply yes", "want me to", "approve",
#                 "should i kill", "want me to clear", "type yes", "say yes")):
#                 sid = uuid.uuid4().hex[:10]
#                 prop = _Proposal(sid, ctx_text, response, trigger="chat")
#                 self._proposals[sid] = prop
#                 await self._push({
#                     "type": "agent_proposal",
#                     "session_id": sid,
#                     "trigger": "chat",
#                     "plan_text": response,
#                 })

#             return response or "All clear — system appears healthy."

#         except Exception as e:
#             logger.error(f"[AgenticAI] chat error: {e}", exc_info=True)
#             return self._fallback_chat(user_message, context)

#     # ──────────────────────────────────────────────────────────────
#     #  SYNC WRAPPERS  (kept for backward-compat with any sync callers)
#     # ──────────────────────────────────────────────────────────────

#     def analyze_context(self, context: DiagnosticContext) -> str:
#         """Sync wrapper — only used from the alert callback (non-async context)."""
#         return self._fallback_analyze(context)

#     def chat(self, user_message: str, context=None, history=None) -> str:
#         """Sync wrapper — only used when AutoGen is unavailable."""
#         return self._fallback_chat(user_message, context)

#     # ──────────────────────────────────────────────────────────────
#     #  STATUS & CONFIG
#     # ──────────────────────────────────────────────────────────────

#     @property
#     def available(self) -> bool:
#         now = time.time()
#         if self._available is not None and (now - self._last_check) < 30:
#             return self._available
#         self._last_check = now
#         self._available  = self._ollama.is_running()
#         return self._available

#     @property
#     def model_name(self) -> str:
#         return self._ollama_model or "not configured"

#     def get_status(self) -> dict:
#         running = self._ollama.is_running()
#         models  = self._ollama.list_models() if running else []
#         return {
#             "provider":          "local",
#             "model":             self.model_name,
#             "available":         running,
#             "ollama_running":    running,
#             "ollama_models":     models,
#             "agentic_enabled":   AUTOGEN_OK,
#             "agentic_active":    self._model_client is not None,
#             "autogen_installed": AUTOGEN_OK,
#             "pending_proposals": len(self.get_pending_proposals()),
#         }

#     def get_ollama_models(self) -> list:
#         return self._ollama.list_models()

#     def set_generation_options(self, opts: dict):
#         self._gen_opts.update(opts)

#     # ──────────────────────────────────────────────────────────────
#     #  INTERNAL HELPERS
#     # ──────────────────────────────────────────────────────────────

#     def _last_message(self, result) -> str:
#         """Extract last meaningful text from AutoGen v0.4 TaskResult."""
#         try:
#             msgs = result.messages if hasattr(result, "messages") else []
#             for msg in reversed(msgs):
#                 content = getattr(msg, "content", None) or \
#                           (msg.get("content") if isinstance(msg, dict) else None)
#                 if isinstance(content, str):
#                     content = content.strip()
#                     if content and len(content) > 15:
#                         return content
#         except Exception:
#             pass
#         return ""

#     def _format_context(self, ctx) -> str:
#         """Compact snapshot for agent prompts."""
#         if not ctx:
#             return "No snapshot. Call get_system_metrics()."
#         m, h = ctx.metrics, ctx.health
#         lines = [
#             f"Health: {h.get('score','?')}/100 — {h.get('label','?')}",
#             f"CPU: {m.get('cpu_percent',0):.1f}%  "
#             f"MEM: {m.get('memory_percent',0):.1f}%  "
#             f"DISK: {m.get('disk_percent',0):.1f}%  "
#             f"NET: {m.get('network_latency_ms',0):.0f}ms",
#         ]
#         if ctx.violations:
#             for v in ctx.violations[:3]:
#                 lines.append(f"  [{v.get('severity','').upper()}] {v.get('message','')}")
#         lines.append("→ Use tools to get fresh live data.")
#         return "\n".join(lines)

#     async def _push(self, data: dict):
#         """Broadcast to all WebSocket clients."""
#         if self._broadcast:
#             try:
#                 await self._broadcast(data)
#             except Exception as e:
#                 logger.debug(f"[AgenticAI] broadcast error: {e}")

#     # ── Fallbacks when AutoGen / Ollama unavailable ────────────────

#     def _fallback_analyze(self, context) -> str:
#         """Single-shot Ollama fallback for analyze_context."""
#         if self._ollama.is_running() and self._ollama_model:
#             prompt = (
#                 "Analyze the following real-time system diagnostic data. "
#                 "Identify issues, explain root causes, give numbered steps:\n\n"
#                 f"{context.to_prompt_text()}"
#             )
#             try:
#                 msgs = [{"role": "system", "content": _SYSTEM_PROMPT_FALLBACK},
#                         {"role": "user",   "content": prompt}]
#                 return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
#             except Exception as e:
#                 logger.error(f"[AgenticAI] fallback analyze error: {e}")
#         return self._rule_based("analyze", context)

#     def _fallback_chat(self, user_message: str, context) -> str:
#         """Single-shot Ollama fallback for chat."""
#         if self._ollama.is_running() and self._ollama_model:
#             ctx_text = self._format_context(context) if context else ""
#             msgs = [{"role": "system",    "content": _SYSTEM_PROMPT_FALLBACK},
#                     {"role": "user",      "content": f"[System]\n{ctx_text}"},
#                     {"role": "assistant", "content": "Understood."},
#                     {"role": "user",      "content": user_message}]
#             try:
#                 return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
#             except Exception as e:
#                 logger.error(f"[AgenticAI] fallback chat error: {e}")
#         return self._rule_based(user_message, context)

#     def _rule_based(self, prompt: str, context) -> str:
#         """Keyword-based response when nothing else is available."""
#         p = prompt.lower()
#         hdr = ""
#         if context:
#             m, h = context.metrics, context.health
#             sc   = h.get("score", 0)
#             ic   = "✅" if sc >= 85 else "⚠️" if sc >= 55 else "🔴"
#             hdr  = (f"{ic} **Health {sc}/100 — {h.get('label','?')}** | "
#                     f"CPU `{m.get('cpu_percent',0):.1f}%` "
#                     f"MEM `{m.get('memory_percent',0):.1f}%` "
#                     f"DISK `{m.get('disk_percent',0):.1f}%`\n\n")
#             if context.violations:
#                 v = context.violations[0]
#                 return (hdr + f"⚠ **{v.get('severity','').upper()}** — {v.get('message','')}\n\n"
#                         "> Start Ollama and select a model in **AI Settings** for agentic analysis.")

#         if any(k in p for k in ("cpu", "processor")):
#             return hdr + "**CPU high** — check Processes tab, kill top consumer."
#         if any(k in p for k in ("memory", "ram")):
#             return hdr + "**Memory high** — restart browsers/IDEs or use Optimize Memory."
#         if any(k in p for k in ("disk", "storage", "space")):
#             return hdr + "**Disk** — run Clear Temp Files from the Remediation panel."
#         if any(k in p for k in ("network", "latency", "dns")):
#             return hdr + "**Network** — use Reset Network to flush DNS and Winsock."
#         if context and any(k in p for k in ("health", "status", "ok", "analyze")):
#             sc = context.health.get("score", 0)
#             return hdr + f"Health score: {sc}/100. " + context.health.get("summary", "")

#         return (hdr or "") + (
#             "⚙ **AI not configured** — Ollama not running or no model selected.\n\n"
#             "Go to **AI Settings → Local LLM**, pick a model, click Connect.\n"
#             "Then agents can investigate and fix issues autonomously."
#         )
















# ==================================================================================================================================================================================
# ==================================================================================================================================================================================
# ==================================================================================================================================================================================
# ==================================================================================================================================================================================
# ==================================================================================================================================================================================
# ==================================================================================================================================================================================

















# """
# Workplace Assist — Agentic AI Engine  v2.3.0
# =================================================
# ONE FILE. Fully agentic backend using AutoGen v0.4 (autogen-agentchat).
# Local-only: Ollama via OpenAI-compatible endpoint.

# What makes this AGENTIC (not Gen AI):
#   Gen AI  → pack a context blob into a prompt → get text back. One shot.
#   Agentic → agents DECIDE what tools to call, in what order, based on
#             what they find. The LLM controls the investigation flow.

#   Example: Agent calls get_system_metrics() → sees CPU 91% → decides to
#   call get_top_processes() → finds chrome.exe → proposes kill_process().
#   That chain of decisions based on real data = agency.

# APPROVAL GATE — remediations NEVER execute without user approval:
#   Agent builds plan → UI shows proposal → user clicks Approve/Dismiss
#   Only on Approve does the agent call any action tool.

# Install:
#   pip install autogen-agentchat autogen-ext[openai]

# Ollama:
#   ollama pull llama3.2   # or phi3, mistral, etc.
# """

# import asyncio
# import json
# import logging
# import socket
# import time
# import threading
# import urllib.request
# import uuid
# from typing import Optional, Callable

# from agent.context_builder import DiagnosticContext

# logger = logging.getLogger(__name__)

# # ── AutoGen v0.4 ──────────────────────────────────────────────────────────
# try:
#     from autogen_agentchat.agents import AssistantAgent
#     from autogen_agentchat.teams import RoundRobinGroupChat
#     from autogen_agentchat.conditions import TextMentionTermination, MaxMessageTermination
#     from autogen_ext.models.openai import OpenAIChatCompletionClient
#     AUTOGEN_OK = True
#     logger.info("[AgenticAI] autogen-agentchat loaded ✓")
# except ImportError as _e:
#     AUTOGEN_OK = False
#     logger.warning(f"[AgenticAI] autogen-agentchat not installed: {_e}")
#     logger.warning("  Run: pip install autogen-agentchat autogen-ext[openai]")

# # ─────────────────────────────────────────────────────────────────
# #  SYSTEM PROMPTS
# # ─────────────────────────────────────────────────────────────────

# _DIAG_PROMPT = """\
# You are the Cognix Diagnostician — a Windows endpoint performance expert.
# You have READ-ONLY tools. Investigate the live system and report findings.

# Protocol (always in this order):
#   1. get_system_metrics()        → baseline, always call this first
#   2. get_active_violations()     → what thresholds are breached?
#   3. CPU > 70%  → get_top_processes(10)
#   4. MEM > 65%  → get_top_processes(10) + get_metric_trend('memory')
#   5. DISK > 80% → check disk values from metrics
#   6. get_predictions()           → is this getting worse?
#   7. get_metric_history(12)      → spike or sustained problem?

# Output format (required):
# ## Findings
# **Current State:** [key metrics with real values from tools]
# **Issues Detected:** [named processes, exact %s — or "None" if healthy]
# **Root Cause:** [1-2 sentence explanation]
# **Severity:** CRITICAL | WARNING | INFO | HEALTHY
# **Urgency:** immediate / monitor / none

# Be specific. Quote actual numbers. Name actual processes.
# Do NOT suggest fixes — the Remediator handles that."""

# _REM_PROMPT = """\
# You are the Cognix Remediator. You receive Diagnostician findings and
# build a safe remediation plan. You NEVER execute tools until the user
# approves by typing APPROVED.

# Available actions:
#   kill_process(pid, reason)   — kill a process (get PID from get_top_processes)
#   clear_temp_files()          — delete temp files, safe, recovers 1-10 GB
#   reset_network()             — flush DNS + reset Winsock (~5s interruption)
#   optimize_memory()           — empty Windows standby cache, always safe

# PHASE 1 — after receiving findings, output ONLY this plan format:
# ---REMEDIATION PLAN---
# Issue: [what was found]
# Actions:
#   1. [action_name(args)] — [reason] — Risk: LOW/MEDIUM
#   2. ...
# Waiting for your approval. Reply APPROVED to execute, or DISMISSED to cancel.
# ---END PLAN---

# PHASE 2 — only after seeing APPROVED in the conversation:
#   Call each tool in your plan. Report the result of each.
#   Then output: REMEDIATION_COMPLETE

# Safety rules — NEVER violate:
#   ✗ Do NOT call action tools before seeing APPROVED
#   ✗ Do NOT kill: lsass.exe, csrss.exe, winlogon.exe, smss.exe, services.exe
#   ✗ Do NOT reset_network if latency < 100ms
#   ✓ clear_temp_files and optimize_memory are always safe choices"""

# _CHAT_PROMPT = """You are Cognix — a friendly, expert device assistant running on this Windows machine.
# You have live tools to check the real system state before answering.

# CRITICAL RULES — ALWAYS FOLLOW:
#   1. NEVER return raw JSON, dictionaries, or code to the user. Ever.
#      Always convert tool results into plain conversational English.
#   2. ALWAYS call tools before answering questions about the system.
#      Do not guess or use cached context — get live data first.
#   3. Be concise. 2-4 sentences or a small bullet list — not walls of text.
#   4. Use plain language. The user is not a developer.

# RESPONSE STYLE — GOOD EXAMPLES:
#   User: "Is my system ok?"
#   → Call get_system_metrics(), then reply:
#     "Your system looks healthy — score 87/100. CPU at 12%, memory 48%, disk 31%. Nothing to worry about."

#   User: "What's using the most CPU?"
#   → Call get_top_processes(8), then reply:
#     "**chrome.exe** is the top consumer at 18% CPU, followed by `node.exe` at 12%. Everything else is under 5%."

#   User: "Check my battery"
#   → Call get_battery_status(), then reply:
#     "Battery is at 74%, currently charging. Health score 82/100 — good condition."

#   User: "Is my disk space ok?"
#   → Call get_system_metrics(), then reply:
#     "Disk is at 61% used (245 GB of 400 GB free). You have some room but it is worth monitoring."

# FOR FIX REQUESTS: investigate → explain what you found in plain English →
#   propose what you will do → ask the user: "Want me to go ahead? Reply **yes** to proceed."
#   Only call action tools (kill_process, clear_temp_files etc.) after the user says yes.

# TOOL ORDER for general status questions:
#   1. get_system_metrics()     — always first
#   2. get_active_violations()  — any active alerts?
#   3. get_top_processes(8)     — if CPU or memory is high"""



# # ─────────────────────────────────────────────────────────────────
# #  PROTECTED PROCESSES — never kill these
# # ─────────────────────────────────────────────────────────────────
# _PROTECTED = {
#     "lsass.exe", "csrss.exe", "winlogon.exe", "smss.exe",
#     "services.exe", "wininit.exe", "system", "registry",
# }


# # ─────────────────────────────────────────────────────────────────
# #  TOOL FACTORY  — closures over live state
# # ─────────────────────────────────────────────────────────────────

# def _make_tools(state, remediation, battery_col=None, security_col=None):
#     """
#     Returns (read_tools, action_tools) — plain Python closures over
#     live AgentState and RemediationEngine.
#     AutoGen v0.4 accepts plain functions directly as tools.
#     """

#     # ── READ TOOLS ───────────────────────────────────────────────

#     def get_system_metrics() -> dict:
#         """Get live CPU%, memory%, disk%, network latency ms, GPU%, and health score/label."""
#         if not state or not state.latest_metrics:
#             return {"error": "Metrics not yet collected, retry in a few seconds"}
#         m, h = state.latest_metrics, state.latest_health
#         return {
#             "cpu_percent":        round(m.cpu_percent, 1),
#             "cpu_cores":          m.cpu_core_count,
#             "memory_percent":     round(m.memory_percent, 1),
#             "memory_used_gb":     round(m.memory_used_gb, 1),
#             "memory_total_gb":    round(m.memory_total_gb, 1),
#             "disk_percent":       round(m.disk_percent, 1),
#             "disk_used_gb":       round(m.disk_used_gb, 1),
#             "disk_total_gb":      round(m.disk_total_gb, 1),
#             "disk_read_mbps":     round(m.disk_read_mbps, 2),
#             "disk_write_mbps":    round(m.disk_write_mbps, 2),
#             "network_latency_ms": round(m.network_latency_ms),
#             "network_sent_mbps":  round(m.network_sent_mbps, 2),
#             "network_recv_mbps":  round(m.network_recv_mbps, 2),
#             "gpu_percent":        round(m.gpu_percent, 1),
#             "gpu_name":           m.gpu_name,
#             "health_score":       h.score if h else 0,
#             "health_label":       h.label if h else "Unknown",
#             "as_of":              time.strftime("%H:%M:%S", time.localtime(m.timestamp)),
#         }

#     def get_top_processes(limit: int = 10) -> list:
#         """Get top N processes by CPU%. limit: 1-20. Each entry has pid, name,
#         cpu_percent, memory_mb, status. Use pid values for kill_process()."""
#         if not state:
#             return []
#         return [
#             {"pid": p.pid, "name": p.name,
#              "cpu_percent": round(p.cpu_percent, 1),
#              "memory_mb": round(p.memory_mb), "status": p.status}
#             for p in state.latest_processes[:min(int(limit), 20)]
#         ]

#     def get_active_violations() -> list:
#         """Get current threshold violations. Empty list means system is healthy.
#         Each has: metric, severity (warning|critical), current_value, threshold,
#         message, sustained_seconds."""
#         if not state:
#             return []
#         return [
#             {"metric": v.metric, "severity": v.severity.value,
#              "current_value": round(v.current_value, 1),
#              "threshold": v.threshold, "message": v.message,
#              "sustained_seconds": round(v.sustained_seconds)}
#             for v in state.active_violations
#         ]

#     def get_metric_trend(metric: str) -> dict:
#         """Trend for a metric: 'cpu'|'memory'|'disk'|'network_latency'.
#         Returns direction (rising/stable/falling), slope, change_rate.
#         Use to tell if a high reading is a spike or a growing problem."""
#         valid = ("cpu", "memory", "disk", "network_latency")
#         if metric not in valid:
#             return {"error": f"metric must be one of: {', '.join(valid)}"}
#         if not state or not state.latest_context:
#             return {"metric": metric, "direction": "unknown"}
#         t = state.latest_context.trends.get(metric)
#         if not t:
#             return {"metric": metric, "direction": "stable", "note": "Not enough data yet"}
#         return {"metric": metric, "direction": t.get("direction", "stable"),
#                 "slope": round(t.get("slope", 0), 3),
#                 "change_rate_pct": round(t.get("change_rate", 0), 2)}

#     def get_predictions() -> list:
#         """Predictive forecasts for CPU/memory/disk.
#         Returns time_to_critical_hours and predicted values at 1h/24h.
#         Empty list = no concerning trends."""
#         if not state or not state.latest_context:
#             return []
#         return state.latest_context.predictions or []

#     def get_metric_history(points: int = 12) -> dict:
#         """Last N snapshots (~5s each, max 60 = ~5 min).
#         Useful for spotting spikes vs sustained problems."""
#         if not state:
#             return {"error": "State unavailable"}
#         pts = state.metric_history[-min(int(points), 60):]
#         return {"count": len(pts), "interval_seconds": 5, "history": pts}

#     def get_system_info() -> dict:
#         """Static device info: hostname, OS, CPU model, total RAM, architecture."""
#         return state.system_info if state else {}

#     def get_battery_status() -> dict:
#         """Battery level%, plugged_in, time_left_minutes, health score.
#         Returns error for desktops/VMs without a battery."""
#         try:
#             import psutil
#             b = psutil.sensors_battery()
#             if not b:
#                 return {"error": "No battery (desktop or VM)"}
#             result = {"percent": round(b.percent, 1), "plugged_in": b.power_plugged,
#                       "time_left_minutes": round(b.secsleft / 60) if b.secsleft and b.secsleft > 0 else None}
#             if battery_col:
#                 try:
#                     result.update(battery_col.collect())
#                 except Exception:
#                     pass
#             return result
#         except Exception as e:
#             return {"error": str(e)}

#     def get_security_status() -> dict:
#         """AV/BitLocker/firewall compliance status, overall score, detected threats."""
#         if not security_col:
#             return {"error": "Security collector not bound"}
#         try:
#             return security_col.collect()
#         except Exception as e:
#             return {"error": str(e)}

#     # ── ACTION TOOLS (only call after APPROVED) ──────────────────

#     def kill_process(pid: int, reason: str = "") -> dict:
#         """Kill a process by PID. Get pid from get_top_processes().
#         ONLY call this after user has approved the remediation plan.
#         Protected system processes are automatically blocked."""
#         if not remediation:
#             return {"success": False, "message": "Remediation engine not bound"}
#         try:
#             import psutil
#             proc = psutil.Process(int(pid))
#             if proc.name().lower() in _PROTECTED:
#                 return {"success": False,
#                         "message": f"BLOCKED: '{proc.name()}' is a protected system process"}
#         except Exception:
#             pass
#         logger.info(f"[Tool] kill_process pid={pid} reason={reason!r}")
#         r = remediation.kill_process(int(pid))
#         return {"success": r.success, "message": r.message, "details": r.details or ""}

#     def clear_temp_files() -> dict:
#         """Delete Windows temp files. Safe. Typically recovers 1-10 GB.
#         ONLY call this after user has approved the remediation plan."""
#         if not remediation:
#             return {"success": False, "message": "Remediation engine not bound"}
#         logger.info("[Tool] clear_temp_files")
#         r = remediation.clear_temp_files()
#         return {"success": r.success, "message": r.message, "details": r.details or ""}

#     def reset_network() -> dict:
#         """Flush DNS cache and reset Winsock (~5s network interruption).
#         Use when latency > 200ms. ONLY call after user approval."""
#         if not remediation:
#             return {"success": False, "message": "Remediation engine not bound"}
#         logger.info("[Tool] reset_network")
#         r = remediation.reset_network()
#         return {"success": r.success, "message": r.message, "details": r.details or ""}

#     def optimize_memory() -> dict:
#         """Empty Windows standby cache. Safe, Windows refills as needed.
#         ONLY call after user has approved the remediation plan."""
#         if not remediation:
#             return {"success": False, "message": "Remediation engine not bound"}
#         logger.info("[Tool] optimize_memory")
#         r = remediation.optimize_memory()
#         return {"success": r.success, "message": r.message, "details": r.details or ""}

#     read_tools   = [get_system_metrics, get_top_processes, get_active_violations,
#                     get_metric_trend, get_predictions, get_metric_history,
#                     get_system_info, get_battery_status, get_security_status]
#     action_tools = [kill_process, clear_temp_files, reset_network, optimize_memory]

#     return read_tools, action_tools


# # ─────────────────────────────────────────────────────────────────
# #  OLLAMA  single-shot client (fallback when AutoGen not installed)
# # ─────────────────────────────────────────────────────────────────

# _SYSTEM_PROMPT_FALLBACK = """\
# You are Workplace Assist, an expert endpoint performance diagnostics assistant.
# Be concise. Reference specific values. Use **bold** for key terms.
# Use `backticks` for process names. Number all recommendations.
# If healthy, say so in 1-2 lines. Never invent data."""

# class _OllamaClient:
#     def __init__(self, base_url="http://127.0.0.1:11434", timeout=120):
#         self.base_url = base_url.rstrip("/")
#         self.timeout  = timeout

#     def is_running(self) -> bool:
#         try:
#             with socket.create_connection(("127.0.0.1", 11434), timeout=2):
#                 return True
#         except OSError:
#             return False

#     def list_models(self) -> list:
#         try:
#             with urllib.request.urlopen(
#                 urllib.request.Request(f"{self.base_url}/api/tags"), timeout=5
#             ) as r:
#                 return [m.get("name", "") for m in json.loads(r.read()).get("models", [])]
#         except Exception:
#             return []

#     def chat(self, messages: list, model: str, options: dict) -> str:
#         payload = json.dumps({"model": model, "messages": messages,
#                               "stream": False, "options": options}).encode()
#         req = urllib.request.Request(
#             f"{self.base_url}/api/chat", data=payload,
#             headers={"Content-Type": "application/json"}, method="POST")
#         with urllib.request.urlopen(req, timeout=self.timeout) as r:
#             return json.loads(r.read()).get("message", {}).get("content", "").strip()


# # ─────────────────────────────────────────────────────────────────
# #  PENDING PROPOSAL  — approval gate state
# # ─────────────────────────────────────────────────────────────────

# class _Proposal:
#     """A remediation plan waiting for user approval."""
#     def __init__(self, session_id: str, findings: str, plan_text: str, trigger: str):
#         self.session_id  = session_id
#         self.findings    = findings
#         self.plan_text   = plan_text
#         self.trigger     = trigger          # 'analyze' | 'chat' | 'monitor'
#         self.created_at  = time.time()
#         self.approved    = False
#         self.dismissed   = False
#         self._event      = asyncio.Event()  # set when user decides

#     def to_dict(self) -> dict:
#         return {"session_id": self.session_id, "findings": self.findings,
#                 "plan_text": self.plan_text, "trigger": self.trigger,
#                 "created_at": self.created_at}


# # ─────────────────────────────────────────────────────────────────
# #  MAIN ENGINE  (public facade — api/server.py talks only to this)
# # ─────────────────────────────────────────────────────────────────

# class AIDiagnosticEngine:
#     """
#     Agentic AI engine backed by AutoGen v0.4 + local Ollama.

#     Same public interface as the original engine — api/server.py unchanged
#     except for the three new approval endpoints added in server.py.

#     Architecture:
#       analyze_context() → Diagnostician agent (read tools only, no approval needed)
#       chat()            → ChatAssistant agent (all tools, asks before acting)
#       Approval gate     → approve(session_id) / dismiss(session_id)

#     Fallback when AutoGen not installed:
#       Single-shot Ollama → rule-based text responses
#     """

#     GENERATION_DEFAULTS = {
#         "temperature": 0.3, "top_p": 0.9, "top_k": 40,
#         "num_predict": 1024, "num_ctx": 4096, "repeat_penalty": 1.1,
#     }

#     def __init__(self):
#         self._ollama        = _OllamaClient()
#         self._ollama_model: Optional[str] = None
#         self._gen_opts      = dict(self.GENERATION_DEFAULTS)
#         self._available     = None
#         self._last_check    = 0.0
#         self._provider      = "local"

#         # AutoGen model client (set by set_local_model)
#         self._model_client  = None

#         # Live tool references (set by bind_tools)
#         self._read_tools    = []
#         self._action_tools  = []

#         # WebSocket broadcast (set by bind_tools)
#         self._broadcast: Optional[Callable] = None

#         # Pending proposals waiting for user decision
#         self._proposals: dict[str, _Proposal] = {}

#         logger.info(
#             f"[AgenticAI] AutoGen available: {AUTOGEN_OK} — "
#             f"{'agentic mode' if AUTOGEN_OK else 'single-shot fallback mode'}"
#         )

#     # ──────────────────────────────────────────────────────────────
#     #  SETUP  (called from server.py create_app)
#     # ──────────────────────────────────────────────────────────────

#     def bind_tools(self, state, remediation_engine,
#                    battery_collector=None, security_collector=None,
#                    broadcast_fn: Optional[Callable] = None):
#         """
#         Wire live AgentState + RemediationEngine into the tool closures.
#         Must be called after the scheduler starts. Called from server.py.
#         """
#         self._read_tools, self._action_tools = _make_tools(
#             state, remediation_engine, battery_collector, security_collector
#         )
#         self._broadcast = broadcast_fn
#         logger.info(f"[AgenticAI] Tools bound — "
#                     f"{len(self._read_tools)} read, {len(self._action_tools)} action")

#     def set_local_model(self, model_name: str) -> dict:
#         """Set the Ollama model. Builds the AutoGen model client."""
#         self._ollama_model = model_name
#         self._available    = None
#         self._last_check   = 0.0

#         if not self._ollama.is_running():
#             return {"provider": "local", "model": model_name,
#                     "available": False, "message": "Ollama is not running"}

#         if not AUTOGEN_OK:
#             return {
#                 "provider": "local", "model": model_name,
#                 "available": True, "agentic": False,
#                 "message": (
#                     f"Ollama connected ({model_name}) — single-shot mode. "
#                     "Run: pip install autogen-agentchat autogen-ext[openai] for agentic mode."
#                 ),
#             }

#         try:
#             base = "http://127.0.0.1:11434/v1"
#             self._model_client = OpenAIChatCompletionClient(
#                 model    = model_name,
#                 base_url = base,
#                 api_key  = "ollama",
#                 model_capabilities={
#                     "vision": False,
#                     "function_calling": True,
#                     "json_output": False,
#                 },
#             )
#             logger.info(f"[AgenticAI] Model client ready: {model_name}")
#             return {
#                 "provider": "local", "model": model_name,
#                 "available": True, "agentic": True,
#                 "message": f"Agentic AI ready — {model_name} via Ollama",
#             }
#         except Exception as e:
#             self._model_client = None
#             logger.error(f"[AgenticAI] set_model error: {e}")
#             return {"provider": "local", "model": model_name,
#                     "available": False, "message": str(e)[:200]}

#     # ──────────────────────────────────────────────────────────────
#     #  APPROVAL GATE
#     # ──────────────────────────────────────────────────────────────

#     def approve_proposal(self, session_id: str) -> bool:
#         p = self._proposals.get(session_id)
#         if not p or p._event.is_set():
#             return False
#         p.approved = True
#         p._event.set()
#         logger.info(f"[AgenticAI] Proposal approved: {session_id}")
#         return True

#     def dismiss_proposal(self, session_id: str) -> bool:
#         p = self._proposals.get(session_id)
#         if not p or p._event.is_set():
#             return False
#         p.dismissed = True
#         p._event.set()
#         logger.info(f"[AgenticAI] Proposal dismissed: {session_id}")
#         return True

#     def get_pending_proposals(self) -> list:
#         now = time.time()
#         return [p.to_dict() for p in self._proposals.values()
#                 if not p._event.is_set() and (now - p.created_at) < 300]

#     # ──────────────────────────────────────────────────────────────
#     #  MAIN PUBLIC INTERFACE  (async — called directly from server.py)
#     # ──────────────────────────────────────────────────────────────

#     async def analyze_context_async(self, context: DiagnosticContext) -> str:
#         """
#         Agentic tab analysis — called by Analyze Now button on every tab.
#         Diagnostician uses live tools to investigate. Read-only, no approval needed.
#         Returns formatted markdown text for the UI.
#         """
#         if not self._model_client:
#             return self._fallback_analyze(context)

#         try:
#             diag = AssistantAgent(
#                 name           = "Diagnostician",
#                 model_client   = self._model_client,
#                 system_message = _DIAG_PROMPT,
#                 tools          = self._read_tools,
#             )
#             term  = TextMentionTermination("## Findings") | MaxMessageTermination(12)
#             team  = RoundRobinGroupChat([diag], termination_condition=term)
#             ctx   = self._format_context(context)
#             result = await team.run(
#                 task=f"System snapshot (use tools for live data):\n{ctx}\n\n"
#                      "Investigate now and produce your ## Findings report."
#             )
#             text = self._last_message(result)
#             return text if text else "System appears healthy — no issues detected."

#         except Exception as e:
#             logger.error(f"[AgenticAI] analyze error: {e}", exc_info=True)
#             return self._fallback_analyze(context)

#     async def chat_async(self, user_message: str,
#                          context: Optional[DiagnosticContext] = None,
#                          history: Optional[list] = None) -> str:
#         """
#         Agentic chat — agent fetches live data with tools before answering.
#         For remediation requests: agent proposes → user approves → agent executes.
#         """
#         if not self._model_client:
#             return self._fallback_chat(user_message, context)

#         try:
#             ctx_text = self._format_context(context) if context else \
#                        "No context. Use get_system_metrics() for current data."

#             hist_text = ""
#             if history:
#                 hist_text = "\n[Recent conversation]\n" + "\n".join(
#                     f"{t.get('role','?').upper()}: {(t.get('content') or '')[:300]}"
#                     for t in history[-6:]
#                 ) + "\n"

#             agent = AssistantAgent(
#                 name           = "CognixAssistant",
#                 model_client   = self._model_client,
#                 system_message = _CHAT_PROMPT,
#                 tools          = self._read_tools + self._action_tools,
#             )
#             term   = MaxMessageTermination(8)
#             team   = RoundRobinGroupChat([agent], termination_condition=term)
#             result = await team.run(
#                 task=f"System context:\n{ctx_text}\n{hist_text}\nUser: {user_message}"
#             )
#             response = self._last_message(result)

#             # If agent is asking for approval to execute, register a proposal
#             if response and any(kw in response.lower() for kw in
#                ("shall i proceed", "reply yes", "want me to", "approve",
#                 "should i kill", "want me to clear", "type yes", "say yes")):
#                 sid = uuid.uuid4().hex[:10]
#                 prop = _Proposal(sid, ctx_text, response, trigger="chat")
#                 self._proposals[sid] = prop
#                 await self._push({
#                     "type": "agent_proposal",
#                     "session_id": sid,
#                     "trigger": "chat",
#                     "plan_text": response,
#                 })

#             return response or "All clear — system appears healthy."

#         except Exception as e:
#             logger.error(f"[AgenticAI] chat error: {e}", exc_info=True)
#             return self._fallback_chat(user_message, context)

#     # ──────────────────────────────────────────────────────────────
#     #  SYNC WRAPPERS  (kept for backward-compat with any sync callers)
#     # ──────────────────────────────────────────────────────────────

#     def analyze_context(self, context: DiagnosticContext) -> str:
#         """Sync wrapper — only used from the alert callback (non-async context)."""
#         return self._fallback_analyze(context)

#     def chat(self, user_message: str, context=None, history=None) -> str:
#         """Sync wrapper — only used when AutoGen is unavailable."""
#         return self._fallback_chat(user_message, context)

#     # ──────────────────────────────────────────────────────────────
#     #  STATUS & CONFIG
#     # ──────────────────────────────────────────────────────────────

#     @property
#     def available(self) -> bool:
#         now = time.time()
#         if self._available is not None and (now - self._last_check) < 30:
#             return self._available
#         self._last_check = now
#         self._available  = self._ollama.is_running()
#         return self._available

#     @property
#     def model_name(self) -> str:
#         return self._ollama_model or "not configured"

#     def get_status(self) -> dict:
#         running = self._ollama.is_running()
#         models  = self._ollama.list_models() if running else []
#         return {
#             "provider":          "local",
#             "model":             self.model_name,
#             "available":         running,
#             "ollama_running":    running,
#             "ollama_models":     models,
#             "agentic_enabled":   AUTOGEN_OK,
#             "agentic_active":    self._model_client is not None,
#             "autogen_installed": AUTOGEN_OK,
#             "pending_proposals": len(self.get_pending_proposals()),
#         }

#     def get_ollama_models(self) -> list:
#         return self._ollama.list_models()

#     def set_generation_options(self, opts: dict):
#         self._gen_opts.update(opts)

#     # ──────────────────────────────────────────────────────────────
#     #  INTERNAL HELPERS
#     # ──────────────────────────────────────────────────────────────

#     def _last_message(self, result) -> str:
#         """Extract last meaningful text from AutoGen v0.4 TaskResult."""
#         try:
#             msgs = result.messages if hasattr(result, "messages") else []
#             for msg in reversed(msgs):
#                 content = getattr(msg, "content", None) or \
#                           (msg.get("content") if isinstance(msg, dict) else None)
#                 if isinstance(content, str):
#                     content = content.strip()
#                     if content and len(content) > 15:
#                         return content
#         except Exception:
#             pass
#         return ""

#     def _format_context(self, ctx) -> str:
#         """Compact snapshot for agent prompts."""
#         if not ctx:
#             return "No snapshot. Call get_system_metrics()."
#         m, h = ctx.metrics, ctx.health
#         lines = [
#             f"Health: {h.get('score','?')}/100 — {h.get('label','?')}",
#             f"CPU: {m.get('cpu_percent',0):.1f}%  "
#             f"MEM: {m.get('memory_percent',0):.1f}%  "
#             f"DISK: {m.get('disk_percent',0):.1f}%  "
#             f"NET: {m.get('network_latency_ms',0):.0f}ms",
#         ]
#         if ctx.violations:
#             for v in ctx.violations[:3]:
#                 lines.append(f"  [{v.get('severity','').upper()}] {v.get('message','')}")
#         lines.append("→ Use tools to get fresh live data.")
#         return "\n".join(lines)

#     async def _push(self, data: dict):
#         """Broadcast to all WebSocket clients."""
#         if self._broadcast:
#             try:
#                 await self._broadcast(data)
#             except Exception as e:
#                 logger.debug(f"[AgenticAI] broadcast error: {e}")

#     # ── Fallbacks when AutoGen / Ollama unavailable ────────────────

#     def _fallback_analyze(self, context) -> str:
#         """Single-shot Ollama fallback for analyze_context."""
#         if self._ollama.is_running() and self._ollama_model:
#             prompt = (
#                 "Analyze the following real-time system diagnostic data. "
#                 "Identify issues, explain root causes, give numbered steps:\n\n"
#                 f"{context.to_prompt_text()}"
#             )
#             try:
#                 msgs = [{"role": "system", "content": _SYSTEM_PROMPT_FALLBACK},
#                         {"role": "user",   "content": prompt}]
#                 return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
#             except Exception as e:
#                 logger.error(f"[AgenticAI] fallback analyze error: {e}")
#         return self._rule_based("analyze", context)

#     def _fallback_chat(self, user_message: str, context) -> str:
#         """Single-shot Ollama fallback for chat."""
#         if self._ollama.is_running() and self._ollama_model:
#             ctx_text = self._format_context(context) if context else ""
#             msgs = [{"role": "system",    "content": _SYSTEM_PROMPT_FALLBACK},
#                     {"role": "user",      "content": f"[System]\n{ctx_text}"},
#                     {"role": "assistant", "content": "Understood."},
#                     {"role": "user",      "content": user_message}]
#             try:
#                 return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
#             except Exception as e:
#                 logger.error(f"[AgenticAI] fallback chat error: {e}")
#         return self._rule_based(user_message, context)

#     def _rule_based(self, prompt: str, context) -> str:
#         """Keyword-based response when nothing else is available."""
#         p = prompt.lower()
#         hdr = ""
#         if context:
#             m, h = context.metrics, context.health
#             sc   = h.get("score", 0)
#             ic   = "✅" if sc >= 85 else "⚠️" if sc >= 55 else "🔴"
#             hdr  = (f"{ic} **Health {sc}/100 — {h.get('label','?')}** | "
#                     f"CPU `{m.get('cpu_percent',0):.1f}%` "
#                     f"MEM `{m.get('memory_percent',0):.1f}%` "
#                     f"DISK `{m.get('disk_percent',0):.1f}%`\n\n")
#             if context.violations:
#                 v = context.violations[0]
#                 return (hdr + f"⚠ **{v.get('severity','').upper()}** — {v.get('message','')}\n\n"
#                         "> Start Ollama and select a model in **AI Settings** for agentic analysis.")

#         if any(k in p for k in ("cpu", "processor")):
#             return hdr + "**CPU high** — check Processes tab, kill top consumer."
#         if any(k in p for k in ("memory", "ram")):
#             return hdr + "**Memory high** — restart browsers/IDEs or use Optimize Memory."
#         if any(k in p for k in ("disk", "storage", "space")):
#             return hdr + "**Disk** — run Clear Temp Files from the Remediation panel."
#         if any(k in p for k in ("network", "latency", "dns")):
#             return hdr + "**Network** — use Reset Network to flush DNS and Winsock."
#         if context and any(k in p for k in ("health", "status", "ok", "analyze")):
#             sc = context.health.get("score", 0)
#             return hdr + f"Health score: {sc}/100. " + context.health.get("summary", "")

#         return (hdr or "") + (
#             "⚙ **AI not configured** — Ollama not running or no model selected.\n\n"
#             "Go to **AI Settings → Local LLM**, pick a model, click Connect.\n"
#             "Then agents can investigate and fix issues autonomously."
#         )


















# ==============================================================================================================================================
# ==============================================================================================================================================
# ==============================================================================================================================================
# ==============================================================================================================================================
# ==============================================================================================================================================
# ==============================================================================================================================================






"""
Workplace Assist — Agentic AI Engine  v2.5.0
=================================================
FIXES over v2.4.0:
  1. ROOT CAUSE FIX — Pre-flight topic detection + mandatory tool call.
     Before the agent runs, we detect the question topic (battery, security,
     processes, disk, network) and call the relevant tool directly. The real
     data is injected into the task so the agent cannot fabricate.

  2. Snapshot labels clarified — "SYSTEM PERFORMANCE SNAPSHOT (CPU/RAM/Disk)"
     makes it clear this is NOT battery health, NOT security, NOT process list.

  3. Prompt rewritten — removed "GIVE THE ANSWER DIRECTLY using snapshot numbers"
     which caused the LLM to use system health score as battery health score.
     New rule: for ANY topic-specific question, call the tool. Always.

  4. Termination fixed — agent MUST call at least one tool before terminating.
     Achieved by injecting live data upfront (so LLM can't terminate early)
     and setting MaxMessageTermination(16) for enough room.

  5. _extract_reply improved — explicitly handles AutoGen v0.4 message types.
"""

from __future__ import annotations

import asyncio
import json
import logging
import socket
import threading
import time
import urllib.request
import uuid
from typing import Callable, Optional

from agent.context_builder import DiagnosticContext

logger = logging.getLogger(__name__)

# ── AutoGen v0.4 ──────────────────────────────────────────────────────────
try:
    from autogen_agentchat.agents import AssistantAgent
    from autogen_agentchat.teams import RoundRobinGroupChat
    from autogen_agentchat.conditions import TextMentionTermination, MaxMessageTermination
    from autogen_ext.models.openai import OpenAIChatCompletionClient
    AUTOGEN_OK = True
    logger.info("[AgenticAI] autogen-agentchat loaded ✓")
except ImportError as _e:
    AUTOGEN_OK = False
    logger.warning(f"[AgenticAI] not installed: {_e}")

_DONE = "COGNIX_DONE"


# ─────────────────────────────────────────────────────────────────
#  DEVICE SNAPSHOT  — background refresh, CPU/RAM/Disk only
# ─────────────────────────────────────────────────────────────────

class _DeviceSnapshot:
    """
    Caches CPU/RAM/Disk/GPU/Network metrics refreshed every 30s.
    IMPORTANT: does NOT contain battery, security, or per-process data.
    Those require explicit tool calls — they are intentionally excluded
    from the snapshot to prevent the LLM from fabricating topic-specific answers.
    """
    REFRESH_S = 30

    def __init__(self):
        self._lock  = threading.Lock()
        self._data: dict = {}
        self._ts:   float = 0.0
        self._state = None

    def bind(self, state):
        self._state = state
        self._refresh()
        t = threading.Thread(target=self._loop, daemon=True, name="snapshot-refresh")
        t.start()

    def _loop(self):
        while True:
            time.sleep(self.REFRESH_S)
            self._refresh()

    def _refresh(self):
        if not self._state:
            return
        try:
            m = self._state.latest_metrics
            h = self._state.latest_health
            v = self._state.active_violations
            if m is None:
                return
            with self._lock:
                self._data = {
                    "cpu_percent":        round(m.cpu_percent, 1),
                    "memory_percent":     round(m.memory_percent, 1),
                    "memory_used_gb":     round(m.memory_used_gb, 1),
                    "memory_total_gb":    round(m.memory_total_gb, 1),
                    "disk_percent":       round(m.disk_percent, 1),
                    "disk_used_gb":       round(m.disk_used_gb, 1),
                    "disk_total_gb":      round(m.disk_total_gb, 1),
                    "gpu_percent":        round(m.gpu_percent, 1),
                    "network_latency_ms": round(m.network_latency_ms),
                    "health_score":       h.score  if h else 0,
                    "health_label":       h.label  if h else "Unknown",
                    "health_summary":     h.summary if h else "",
                    "as_of":              time.strftime("%H:%M:%S", time.localtime(m.timestamp)),
                    "violations": [
                        {"metric": vv.metric, "severity": vv.severity.value,
                         "message": vv.message}
                        for vv in (v or [])[:3]
                    ],
                }
                self._ts = time.time()
        except Exception as exc:
            logger.debug(f"[Snapshot] refresh error: {exc}")

    def text(self) -> str:
        """
        Compact system performance text injected into every agent task.
        NOTE: This covers CPU/RAM/Disk/Network/GPU only.
        Battery, security, and per-process data are NOT included here —
        the agent must call get_battery_status(), get_security_status(), or
        get_top_processes() for that information.
        """
        with self._lock:
            d = self._data
        if not d:
            return "System snapshot not yet ready — call get_system_metrics()."

        vio_text = ""
        if d.get("violations"):
            vio_text = "\n  Active alerts: " + " | ".join(
                f"[{v['severity'].upper()}] {v['message']}"
                for v in d["violations"]
            )

        return (
            f"[SYSTEM PERFORMANCE SNAPSHOT — {d.get('as_of','?')}]\n"
            f"  Overall health: {d.get('health_score','?')}/100 — {d.get('health_label','?')}\n"
            f"  CPU: {d.get('cpu_percent','?')}%  "
            f"RAM: {d.get('memory_percent','?')}% "
            f"({d.get('memory_used_gb','?')}/{d.get('memory_total_gb','?')} GB)  "
            f"Disk: {d.get('disk_percent','?')}% "
            f"({d.get('disk_used_gb','?')}/{d.get('disk_total_gb','?')} GB)\n"
            f"  Network latency: {d.get('network_latency_ms','?')}ms  "
            f"GPU: {d.get('gpu_percent','?')}%"
            f"{vio_text}\n"
            f"  NOTE: Battery, security, and per-process details require tool calls."
        )


_snapshot = _DeviceSnapshot()


# ─────────────────────────────────────────────────────────────────
#  TOPIC DETECTION  — mandatory pre-flight data loading
# ─────────────────────────────────────────────────────────────────

_TOPIC_MAP = {
    "battery":  ["battery", "charge", "power", "plugged", "charging", "battery health"],
    "security": ["security", "antivirus", "firewall", "bitlocker", "virus", "malware",
                 "threat", "compliance", "defender", "protected"],
    "process":  ["process", "task", "running", "using most", "cpu usage", "top process",
                 "which app", "what app", "consuming", "hogging"],
    "network":  ["network", "internet", "latency", "dns", "slow internet", "connection",
                 "bandwidth", "ping"],
    "disk":     ["disk", "storage", "space", "drive", "full", "free space"],
    "memory":   ["memory", "ram", "mem usage"],
}

def _detect_topics(message: str) -> list[str]:
    """Return list of topics the user is asking about (e.g. ['battery', 'security'])."""
    p = message.lower()
    return [topic for topic, keywords in _TOPIC_MAP.items() if any(k in p for k in keywords)]


def _prefetch_topic_data(topics: list[str], read_tools: list) -> str:
    """
    Directly call the relevant read tools BEFORE the agent runs.
    Returns a text block with real live data to inject into the task.
    This guarantees the agent has real data and cannot fabricate.
    """
    if not topics or not read_tools:
        return ""

    tool_map = {fn.__name__: fn for fn in read_tools}
    lines    = []

    for topic in topics:
        try:
            if topic == "battery":
                fn = tool_map.get("get_battery_status")
                if fn:
                    data = fn()
                    lines.append(f"[LIVE BATTERY DATA]\n{json.dumps(data, indent=2)}")

            elif topic == "security":
                fn = tool_map.get("get_security_status")
                if fn:
                    data = fn()
                    lines.append(f"[LIVE SECURITY DATA]\n{json.dumps(data, indent=2)}")

            elif topic == "process":
                fn = tool_map.get("get_top_processes")
                if fn:
                    data = fn(10)
                    lines.append(f"[LIVE PROCESS DATA — top 10 by CPU]\n{json.dumps(data, indent=2)}")

            elif topic == "network":
                fn = tool_map.get("get_system_metrics")
                if fn:
                    m = fn()
                    lines.append(
                        f"[LIVE NETWORK DATA]\n"
                        f"  Latency: {m.get('network_latency_ms','?')} ms\n"
                        f"  Upload: {m.get('network_sent_mbps','?')} Mbps\n"
                        f"  Download: {m.get('network_recv_mbps','?')} Mbps"
                    )

            elif topic in ("disk", "memory"):
                fn = tool_map.get("get_system_metrics")
                if fn:
                    m = fn()
                    if topic == "disk":
                        lines.append(
                            f"[LIVE DISK DATA]\n"
                            f"  Used: {m.get('disk_percent','?')}%  "
                            f"({m.get('disk_used_gb','?')}/{m.get('disk_total_gb','?')} GB)\n"
                            f"  Read: {m.get('disk_read_mbps','?')} MB/s  "
                            f"Write: {m.get('disk_write_mbps','?')} MB/s"
                        )
                    else:
                        lines.append(
                            f"[LIVE MEMORY DATA]\n"
                            f"  Used: {m.get('memory_percent','?')}%  "
                            f"({m.get('memory_used_gb','?')}/{m.get('memory_total_gb','?')} GB)"
                        )
        except Exception as e:
            logger.debug(f"[prefetch] {topic} error: {e}")

    return "\n\n".join(lines)


# ─────────────────────────────────────────────────────────────────
#  SYSTEM PROMPTS
# ─────────────────────────────────────────────────────────────────

_ASSISTANT_PROMPT = (
    "You are Cognix — a friendly, accurate device assistant for a Windows endpoint monitoring app.\n"
    "Every task message contains a [SYSTEM PERFORMANCE SNAPSHOT] with CPU/RAM/Disk/Network/GPU data.\n"
    "When the task contains [LIVE BATTERY DATA], [LIVE PROCESS DATA], etc., use THAT data to answer.\n\n"

    "STRICT RULES — follow every one:\n"
    "  1. ANSWER IN PLAIN ENGLISH. Never output raw JSON, dicts, or code blocks.\n"
    "     Convert any data into natural sentences. Example:\n"
    "     BAD:  {'percent': 85, 'plugged_in': True}  \n"
    "     GOOD: Your battery is at 85% and currently charging.\n\n"
    "  2. USE THE INJECTED DATA FIRST. If the task already contains\n"
    "     [LIVE BATTERY DATA], [LIVE PROCESS DATA], etc., read it and answer directly.\n"
    "     Only call a tool if that specific data is missing from the task.\n\n"
    "  3. NEVER FABRICATE. If the snapshot says health_score 93/100,\n"
    "     that is the SYSTEM health score — NOT the battery health score.\n"
    "     Battery health is only available from [LIVE BATTERY DATA] or get_battery_status().\n\n"
    "  4. BE CONCISE — 2-5 sentences. No walls of text.\n\n"
    "  5. FOR FIX REQUESTS: explain what you found, propose the fix, then ask:\n"
    "     'Want me to go ahead? Reply yes to proceed.'\n"
    "     Do NOT call action tools until user confirms.\n\n"
    "  6. End every response with: " + _DONE + "\n\n"

    "RESPONSE EXAMPLES:\n"
    "  Snapshot + [LIVE BATTERY DATA: percent=85, plugged_in=true]\n"
    "  User: check my battery\n"
    "  → Your battery is at **85%** and currently charging. No issues detected. " + _DONE + "\n\n"

    "  Snapshot + [LIVE PROCESS DATA: [{name: chrome.exe, cpu: 18.2, ...}]]\n"
    "  User: what's using the most CPU?\n"
    "  → **chrome.exe** is the top CPU consumer at 18.2%, followed by node.exe at 12%. " + _DONE + "\n\n"

    "  Snapshot shows disk 89%\n"
    "  User: my disk is full\n"
    "  → Your disk is at **89%** (445 of 500 GB used). I can clear temp files to free 2-5 GB.\n"
    "  Want me to go ahead? Reply yes to proceed. " + _DONE
)

_REMEDIATOR_PROMPT = (
    "You are the Cognix Remediator. Execute the approved remediation plan.\n"
    "Call each action tool. Report results in plain English.\n"
    "SAFETY: NEVER kill lsass.exe, csrss.exe, winlogon.exe, smss.exe, services.exe.\n"
    "End with: " + _DONE
)

_SYSTEM_PROMPT_FALLBACK = (
    "You are Workplace Assist, an expert endpoint performance assistant. "
    "Be concise. Use real numbers. Use **bold** for key values. "
    "Convert all data to plain English — never return raw JSON or dicts."
)


# ─────────────────────────────────────────────────────────────────
#  PROTECTED PROCESSES
# ─────────────────────────────────────────────────────────────────
_PROTECTED = {
    "lsass.exe", "csrss.exe", "winlogon.exe", "smss.exe",
    "services.exe", "wininit.exe", "system", "registry",
}


# ─────────────────────────────────────────────────────────────────
#  TOOL FACTORY
# ─────────────────────────────────────────────────────────────────

def _make_tools(state, remediation, battery_col=None, security_col=None):
    """Returns (read_tools, action_tools) — plain callables for AutoGen v0.4."""

    def get_system_metrics() -> dict:
        """Get live CPU%, memory%, disk%, network latency, GPU%, and system health score."""
        if not state or not state.latest_metrics:
            return {"error": "Metrics not yet collected — retry in a few seconds"}
        m, h = state.latest_metrics, state.latest_health
        return {
            "cpu_percent":        round(m.cpu_percent, 1),
            "cpu_cores":          m.cpu_core_count,
            "memory_percent":     round(m.memory_percent, 1),
            "memory_used_gb":     round(m.memory_used_gb, 1),
            "memory_total_gb":    round(m.memory_total_gb, 1),
            "disk_percent":       round(m.disk_percent, 1),
            "disk_used_gb":       round(m.disk_used_gb, 1),
            "disk_total_gb":      round(m.disk_total_gb, 1),
            "disk_read_mbps":     round(m.disk_read_mbps, 2),
            "disk_write_mbps":    round(m.disk_write_mbps, 2),
            "network_latency_ms": round(m.network_latency_ms),
            "network_sent_mbps":  round(m.network_sent_mbps, 2),
            "network_recv_mbps":  round(m.network_recv_mbps, 2),
            "gpu_percent":        round(m.gpu_percent, 1),
            "gpu_name":           m.gpu_name,
            "health_score":       h.score   if h else 0,
            "health_label":       h.label   if h else "Unknown",
            "health_summary":     h.summary if h else "",
            "as_of":              time.strftime("%H:%M:%S", time.localtime(m.timestamp)),
        }

    def get_top_processes(limit: int = 10) -> list:
        """Top N processes by CPU%. Each entry: pid, name, cpu_percent, memory_mb, status.
        Use pid for kill_process()."""
        if not state:
            return []
        return [
            {"pid": p.pid, "name": p.name,
             "cpu_percent": round(p.cpu_percent, 1),
             "memory_mb": round(p.memory_mb), "status": p.status}
            for p in state.latest_processes[:min(int(limit), 20)]
        ]

    def get_active_violations() -> list:
        """Active threshold violations. Empty list = healthy.
        Each has: metric, severity (warning|critical), current_value, threshold, message."""
        if not state:
            return []
        return [
            {"metric": v.metric, "severity": v.severity.value,
             "current_value": round(v.current_value, 1),
             "threshold": v.threshold, "message": v.message,
             "sustained_seconds": round(v.sustained_seconds)}
            for v in state.active_violations
        ]

    def get_metric_trend(metric: str) -> dict:
        """Trend for 'cpu'|'memory'|'disk'|'network_latency'.
        Returns direction (rising/stable/falling), slope, change_rate_pct."""
        valid = ("cpu", "memory", "disk", "network_latency")
        if metric not in valid:
            return {"error": f"metric must be one of: {', '.join(valid)}"}
        if not state or not state.latest_context:
            return {"metric": metric, "direction": "unknown"}
        t = state.latest_context.trends.get(metric)
        if not t:
            return {"metric": metric, "direction": "stable", "note": "Not enough data yet"}
        return {"metric": metric, "direction": t.get("direction", "stable"),
                "slope": round(t.get("slope", 0), 3),
                "change_rate_pct": round(t.get("change_rate", 0), 2)}

    def get_predictions() -> list:
        """Predictive forecasts for CPU/memory/disk (time_to_critical_hours, predicted_1h/24h).
        Empty list = no concerning trends."""
        if not state or not state.latest_context:
            return []
        return state.latest_context.predictions or []

    def get_metric_history(points: int = 12) -> dict:
        """Last N metric snapshots (~5s each, max 60 = ~5 min)."""
        if not state:
            return {"error": "State unavailable"}
        pts = state.metric_history[-min(int(points), 60):]
        return {"count": len(pts), "interval_seconds": 5, "history": pts}

    def get_system_info() -> dict:
        """Static device info: hostname, OS, CPU model, total RAM, architecture."""
        return state.system_info if state else {}

    def get_battery_status() -> dict:
        """Battery charge level (%), plugged_in status, time_left_minutes, health score.
        Returns {'error': 'No battery'} for desktops/VMs without a battery.
        NOTE: This is BATTERY health — completely separate from system health score."""
        try:
            import psutil
            b = psutil.sensors_battery()
            if not b:
                return {"error": "No battery detected (desktop or VM)"}
            result = {
                "percent":           round(b.percent, 1),
                "plugged_in":        b.power_plugged,
                "time_left_minutes": round(b.secsleft / 60) if b.secsleft and b.secsleft > 0 else None,
            }
            if battery_col:
                try:
                    result.update(battery_col.collect())
                except Exception:
                    pass
            return result
        except Exception as e:
            return {"error": str(e)}

    def get_security_status() -> dict:
        """AV/BitLocker/firewall compliance status, overall compliance score, detected threats."""
        if not security_col:
            return {"error": "Security collector not bound"}
        try:
            return security_col.collect()
        except Exception as e:
            return {"error": str(e)}

    # ── ACTION TOOLS (only after user approval) ──────────────────

    def kill_process(pid: int, reason: str = "") -> dict:
        """Kill a process by PID (get from get_top_processes). ONLY after user says yes."""
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        try:
            import psutil as _ps
            proc = _ps.Process(int(pid))
            if proc.name().lower() in _PROTECTED:
                return {"success": False,
                        "message": f"BLOCKED: '{proc.name()}' is a protected system process"}
        except Exception:
            pass
        logger.info(f"[Tool] kill_process pid={pid} reason={reason!r}")
        r = remediation.kill_process(int(pid))
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    def clear_temp_files() -> dict:
        """Delete Windows temp files (safe, recovers 1-10 GB). ONLY after user says yes."""
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        logger.info("[Tool] clear_temp_files")
        r = remediation.clear_temp_files()
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    def reset_network() -> dict:
        """Flush DNS + reset Winsock (~5s interruption). ONLY after user says yes."""
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        logger.info("[Tool] reset_network")
        r = remediation.reset_network()
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    def optimize_memory() -> dict:
        """Empty Windows standby cache (safe). ONLY after user says yes."""
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        logger.info("[Tool] optimize_memory")
        r = remediation.optimize_memory()
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    read_tools   = [get_system_metrics, get_top_processes, get_active_violations,
                    get_metric_trend, get_predictions, get_metric_history,
                    get_system_info, get_battery_status, get_security_status]
    action_tools = [kill_process, clear_temp_files, reset_network, optimize_memory]
    return read_tools, action_tools


# ─────────────────────────────────────────────────────────────────
#  OLLAMA  direct HTTP client
# ─────────────────────────────────────────────────────────────────

class _OllamaClient:
    def __init__(self, base_url: str = "http://127.0.0.1:11434", timeout: int = 120):
        self.base_url = base_url.rstrip("/")
        self.timeout  = timeout

    def is_running(self) -> bool:
        try:
            with socket.create_connection(("127.0.0.1", 11434), timeout=2):
                return True
        except OSError:
            return False

    def list_models(self) -> list:
        try:
            with urllib.request.urlopen(
                urllib.request.Request(f"{self.base_url}/api/tags"), timeout=5
            ) as r:
                return [m.get("name", "") for m in json.loads(r.read()).get("models", [])]
        except Exception:
            return []

    def chat(self, messages: list, model: str, options: dict) -> str:
        payload = json.dumps({"model": model, "messages": messages,
                              "stream": False, "options": options}).encode()
        req = urllib.request.Request(
            f"{self.base_url}/api/chat", data=payload,
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            return json.loads(r.read()).get("message", {}).get("content", "").strip()


# ─────────────────────────────────────────────────────────────────
#  PENDING PROPOSAL  — approval gate
# ─────────────────────────────────────────────────────────────────

class _Proposal:
    def __init__(self, session_id: str, findings: str, plan_text: str, trigger: str):
        self.session_id = session_id
        self.findings   = findings
        self.plan_text  = plan_text
        self.trigger    = trigger
        self.created_at = time.time()
        self.approved   = False
        self.dismissed  = False
        self._event     = asyncio.Event()

    def to_dict(self) -> dict:
        return {"session_id": self.session_id, "findings": self.findings,
                "plan_text": self.plan_text, "trigger": self.trigger,
                "created_at": self.created_at}


# ─────────────────────────────────────────────────────────────────
#  MAIN ENGINE
# ─────────────────────────────────────────────────────────────────

class AIDiagnosticEngine:
    """
    Two-agent agentic engine.
    CognixAssistant: answers questions with pre-fetched real tool data.
    Remediator:      executes approved plans.
    """

    GENERATION_DEFAULTS = {
        "temperature": 0.3, "top_p": 0.9, "top_k": 40,
        "num_predict": 1024, "num_ctx": 4096, "repeat_penalty": 1.1,
    }

    def __init__(self):
        self._ollama        = _OllamaClient()
        self._ollama_model: Optional[str] = None
        self._gen_opts      = dict(self.GENERATION_DEFAULTS)
        self._available     = None
        self._last_check    = 0.0
        self._provider      = "local"
        self._model_client  = None
        self._read_tools:   list = []
        self._action_tools: list = []
        self._broadcast: Optional[Callable] = None
        self._proposals: dict[str, _Proposal] = {}
        logger.info(f"[AgenticAI] AutoGen: {AUTOGEN_OK}")

    # ── Setup ──────────────────────────────────────────────────────

    def bind_tools(self, state, remediation_engine,
                   battery_collector=None, security_collector=None,
                   broadcast_fn: Optional[Callable] = None):
        self._read_tools, self._action_tools = _make_tools(
            state, remediation_engine, battery_collector, security_collector
        )
        self._broadcast = broadcast_fn
        _snapshot.bind(state)
        logger.info(f"[AgenticAI] Tools bound — "
                    f"{len(self._read_tools)} read, {len(self._action_tools)} action")

    def set_local_model(self, model_name: str) -> dict:
        self._ollama_model = model_name
        self._available    = None
        self._last_check   = 0.0

        if not self._ollama.is_running():
            return {"provider": "local", "model": model_name,
                    "available": False, "message": "Ollama is not running"}
        if not AUTOGEN_OK:
            return {"provider": "local", "model": model_name,
                    "available": True, "agentic": False,
                    "message": (f"Ollama connected ({model_name}) — single-shot mode. "
                                "pip install autogen-agentchat autogen-ext[openai] for agentic.")}
        try:
            self._model_client = OpenAIChatCompletionClient(
                model    = model_name,
                base_url = "http://127.0.0.1:11434/v1",
                api_key  = "ollama",
                model_capabilities={"vision": False, "function_calling": True, "json_output": False},
            )
            logger.info(f"[AgenticAI] Model ready: {model_name}")
            return {"provider": "local", "model": model_name,
                    "available": True, "agentic": True,
                    "message": f"Agentic AI ready — {model_name} via Ollama"}
        except Exception as e:
            self._model_client = None
            return {"provider": "local", "model": model_name,
                    "available": False, "message": str(e)[:200]}

    def set_api_key(self, provider: str, api_key: str, model: str = "") -> dict:
        if not AUTOGEN_OK:
            return {"available": False, "provider": provider,
                    "message": "autogen-agentchat not installed"}
        _CONFIGS = {
            "claude": {"base_url": "https://api.anthropic.com/v1",
                       "default_model": "claude-haiku-4-5-20251001"},
            "openai": {"base_url": "https://api.openai.com/v1",
                       "default_model": "gpt-4o-mini"},
            "nvidia": {"base_url": "https://integrate.api.nvidia.com/v1",
                       "default_model": "meta/llama3-70b-instruct"},
        }
        cfg = _CONFIGS.get(provider.lower())
        if not cfg:
            return {"available": False, "provider": provider,
                    "message": f"Unknown provider: {provider}"}
        chosen = model or cfg["default_model"]
        self._provider     = provider.lower()
        self._ollama_model = chosen
        try:
            self._model_client = OpenAIChatCompletionClient(
                model=chosen, base_url=cfg["base_url"], api_key=api_key,
                model_capabilities={"vision": False, "function_calling": True, "json_output": False},
            )
            return {"provider": provider, "model": chosen, "available": True, "agentic": True,
                    "message": f"Connected to {provider.title()} — {chosen}"}
        except Exception as e:
            self._model_client = None
            return {"provider": provider, "model": chosen, "available": False,
                    "message": str(e)[:300]}

    # ── Approval gate ──────────────────────────────────────────────

    def approve_proposal(self, session_id: str) -> bool:
        p = self._proposals.get(session_id)
        if not p or p._event.is_set():
            return False
        p.approved = True
        p._event.set()
        return True

    def dismiss_proposal(self, session_id: str) -> bool:
        p = self._proposals.get(session_id)
        if not p or p._event.is_set():
            return False
        p.dismissed = True
        p._event.set()
        return True

    def get_pending_proposals(self) -> list:
        now = time.time()
        return [p.to_dict() for p in self._proposals.values()
                if not p._event.is_set() and (now - p.created_at) < 300]

    # ── Main async interface ────────────────────────────────────────

    async def chat_async(self, user_message: str,
                         context: Optional[DiagnosticContext] = None,
                         history: Optional[list] = None) -> str:
        """
        THE KEY FIX IS HERE:
        1. Detect what topic the user is asking about.
        2. Pre-fetch the live data for that topic by calling tools BEFORE the agent.
        3. Inject the real data into the task so the agent cannot fabricate.
        """
        if not self._model_client:
            return self._fallback_chat(user_message, context)

        # ── Step 1: Detect topic ──────────────────────────────────
        topics = _detect_topics(user_message)

        # ── Step 2: Pre-fetch live data for detected topics ───────
        # This is the anti-fabrication guarantee: real data is in the task
        # before the agent ever runs, so it cannot make things up.
        prefetched = _prefetch_topic_data(topics, self._read_tools)

        # ── Step 3: Build history context ─────────────────────────
        hist_text = ""
        if history:
            hist_text = "\n[Recent conversation]\n" + "\n".join(
                f"{t.get('role','?').upper()}: {(t.get('content') or '')[:200]}"
                for t in history[-4:]
            ) + "\n"

        # ── Step 4: Assemble task with snapshot + live data ────────
        task_parts = [_snapshot.text()]
        if prefetched:
            task_parts.append(prefetched)
        if hist_text:
            task_parts.append(hist_text)
        task_parts.append(f"User: {user_message}")
        task = "\n\n".join(task_parts)

        try:
            agent = AssistantAgent(
                name           = "CognixAssistant",
                model_client   = self._model_client,
                system_message = _ASSISTANT_PROMPT,
                tools          = self._read_tools,
            )
            # MaxMessageTermination(16) gives room for: snapshot read +
            # optional extra tool call + final response. Not too low.
            term   = TextMentionTermination(_DONE) | MaxMessageTermination(16)
            team   = RoundRobinGroupChat([agent], termination_condition=term)
            result = await team.run(task=task)
            response = self._extract_reply(result)

            if not response:
                # Try fallback with the same pre-fetched data
                return self._fallback_with_data(user_message, prefetched, context)

            # Register fix proposals for approval gate
            fix_kw = ("want me to go ahead", "reply yes", "say yes", "type yes",
                      "shall i proceed", "want me to clear", "want me to kill",
                      "want me to reset", "want me to optimize")
            if any(kw in response.lower() for kw in fix_kw):
                sid  = uuid.uuid4().hex[:10]
                prop = _Proposal(sid, _snapshot.text(), response, trigger="chat")
                self._proposals[sid] = prop
                await self._push({"type": "agent_proposal", "session_id": sid,
                                  "trigger": "chat", "plan_text": response})

            return response.replace(_DONE, "").strip()

        except Exception as e:
            logger.error(f"[AgenticAI] chat_async error: {e}", exc_info=True)
            return self._fallback_with_data(user_message, prefetched, context)

    async def analyze_context_async(self, context: DiagnosticContext) -> str:
        if not self._model_client:
            return self._fallback_analyze(context)

        snapshot_text = _snapshot.text()
        ctx_extra     = self._format_context(context)
        task = (
            f"{snapshot_text}\n\n"
            f"Additional monitoring data:\n{ctx_extra}\n\n"
            "Investigate this system. Report in plain English:\n"
            "- **Overall status** (score + meaning)\n"
            "- **Issues found** (real numbers, process names)\n"
            "- **Root cause** (1-2 sentences)\n"
            "- **Recommended actions** (numbered)\n"
            f"End with: {_DONE}"
        )
        try:
            agent = AssistantAgent(
                name="CognixAnalyst", model_client=self._model_client,
                system_message=_ASSISTANT_PROMPT, tools=self._read_tools,
            )
            term   = TextMentionTermination(_DONE) | MaxMessageTermination(16)
            team   = RoundRobinGroupChat([agent], termination_condition=term)
            result = await team.run(task=task)
            text   = self._extract_reply(result)
            return text.replace(_DONE, "").strip() if text else "System appears healthy."
        except Exception as e:
            logger.error(f"[AgenticAI] analyze error: {e}", exc_info=True)
            return self._fallback_analyze(context)

    async def execute_approved_plan_async(self, proposal: _Proposal,
                                          session_id: str) -> str:
        if not self._model_client:
            return "AI engine not configured."
        task = (
            f"The user approved this plan:\n\n{proposal.plan_text}\n\n"
            "Execute every action. Report each result clearly. "
            f"End with: {_DONE}"
        )
        try:
            agent = AssistantAgent(
                name="Remediator", model_client=self._model_client,
                system_message=_REMEDIATOR_PROMPT,
                tools=self._read_tools + self._action_tools,
            )
            term   = TextMentionTermination(_DONE) | MaxMessageTermination(16)
            team   = RoundRobinGroupChat([agent], termination_condition=term)
            result = await team.run(task=task)
            text   = self._extract_reply(result)
            return text.replace(_DONE, "").strip() if text else "Execution complete."
        except Exception as e:
            logger.error(f"[AgenticAI] execute_approved_plan error: {e}", exc_info=True)
            return f"Execution error: {e}"

    # ── Sync wrappers ──────────────────────────────────────────────

    def analyze_context(self, context: DiagnosticContext) -> str:
        return self._fallback_analyze(context)

    def chat(self, user_message: str, context=None, history=None) -> str:
        return self._fallback_chat(user_message, context)

    # ── Status ─────────────────────────────────────────────────────

    @property
    def available(self) -> bool:
        now = time.time()
        if self._available is not None and (now - self._last_check) < 30:
            return self._available
        self._last_check = now
        self._available  = (self._ollama.is_running() if self._provider == "local"
                            else self._model_client is not None)
        return self._available

    @property
    def model_name(self) -> str:
        return self._ollama_model or "not configured"

    def get_status(self) -> dict:
        is_local = self._provider == "local"
        running  = self._ollama.is_running() if is_local else (self._model_client is not None)
        models   = self._ollama.list_models() if (is_local and running) else []
        return {
            "provider":          self._provider,
            "model":             self.model_name,
            "available":         running,
            "ollama_running":    self._ollama.is_running() if is_local else None,
            "ollama_models":     models,
            "agentic_enabled":   AUTOGEN_OK,
            "agentic_active":    self._model_client is not None,
            "autogen_installed": AUTOGEN_OK,
            "pending_proposals": len(self.get_pending_proposals()),
            "snapshot_age_s":    round(time.time() - _snapshot._ts) if _snapshot._ts > 0 else None,
        }

    def get_ollama_models(self) -> list:
        return self._ollama.list_models()

    def set_generation_options(self, opts: dict):
        self._gen_opts.update(opts)

    # ── Internal helpers ───────────────────────────────────────────

    def _extract_reply(self, result) -> str:
        """
        Extract last meaningful text from AutoGen v0.4 TaskResult.
        Skips ToolCallMessage and ToolCallResultMessage.
        Returns the final assistant text response.
        """
        try:
            msgs = result.messages if hasattr(result, "messages") else []
            for msg in reversed(msgs):
                msg_type = type(msg).__name__
                # Skip tool call and tool result messages
                if "ToolCall" in msg_type or "ToolResult" in msg_type:
                    continue

                content = (getattr(msg, "content", None) or
                           (msg.get("content") if isinstance(msg, dict) else None))

                # Skip list-type content (tool call payloads)
                if isinstance(content, list):
                    continue

                if isinstance(content, str):
                    content = content.strip()
                    # Skip raw JSON-looking content
                    if content.startswith("[{") or content.startswith('{"'):
                        continue
                    if len(content) > 20:
                        return content
        except Exception as exc:
            logger.debug(f"[AgenticAI] _extract_reply error: {exc}")
        return ""

    def _format_context(self, ctx) -> str:
        if not ctx:
            return ""
        m, h = ctx.metrics, ctx.health
        lines = [f"Health: {h.get('score','?')}/100 — {h.get('label','?')}"]
        if ctx.violations:
            for v in ctx.violations[:3]:
                lines.append(f"  ALERT [{v.get('severity','').upper()}] {v.get('message','')}")
        return "\n".join(lines)

    async def _push(self, data: dict):
        if self._broadcast:
            try:
                await self._broadcast(data)
            except Exception as e:
                logger.debug(f"[AgenticAI] broadcast error: {e}")

    # ── Fallbacks ──────────────────────────────────────────────────

    def _fallback_with_data(self, user_message: str,
                             prefetched: str, context) -> str:
        """
        Single-shot Ollama with pre-fetched live data injected.
        Used when AutoGen fails — still returns real data, not fabricated.
        """
        snapshot_text = _snapshot.text()
        combined = snapshot_text
        if prefetched:
            combined += "\n\n" + prefetched

        if self._ollama.is_running() and self._ollama_model:
            msgs = [
                {"role": "system",    "content": _SYSTEM_PROMPT_FALLBACK},
                {"role": "user",      "content": (
                    f"Device state:\n{combined}\n\n"
                    f"User question: {user_message}\n\n"
                    "Answer in plain English. 2-4 sentences. "
                    "Use the numbers from the data above. Never return raw JSON."
                )},
            ]
            try:
                return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] _fallback_with_data error: {e}")

        return self._rule_based(user_message, context)

    def _fallback_analyze(self, context) -> str:
        snapshot_text = _snapshot.text()
        if self._ollama.is_running() and self._ollama_model:
            prompt = (
                "Analyze this system state. Be specific with numbers. Give numbered steps.\n\n"
                f"{snapshot_text}\n\n"
                f"Additional: {context.to_prompt_text() if context else 'N/A'}"
            )
            try:
                msgs = [{"role": "system", "content": _SYSTEM_PROMPT_FALLBACK},
                        {"role": "user",   "content": prompt}]
                return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] fallback analyze: {e}")
        return self._rule_based("analyze", context)

    def _fallback_chat(self, user_message: str, context) -> str:
        topics    = _detect_topics(user_message)
        prefetched = _prefetch_topic_data(topics, self._read_tools)
        return self._fallback_with_data(user_message, prefetched, context)

    def _fallback_tab(self, system_prompt: str, tab_context: str) -> str:
        if self._ollama.is_running() and self._ollama_model:
            prompt = (
                f"{system_prompt}\n\n"
                'Respond ONLY in valid JSON (no markdown fences):\n'
                '{"root_cause":"...","warning_level":"critical|warning|info|healthy",'
                '"warning_score":0,"impacted_components":[],'
                '"recommended_actions":[],"preventive_suggestions":[],"summary":"..."}\n\n'
                f"{tab_context}"
            )
            try:
                msgs = [{"role": "system", "content": _SYSTEM_PROMPT_FALLBACK},
                        {"role": "user",   "content": prompt}]
                return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] _fallback_tab: {e}")
        return ""

    def _rule_based(self, prompt: str, context) -> str:
        """Last-resort keyword responses when no LLM is available."""
        p = prompt.lower()
        d = _snapshot._data
        tip = "\n\n> Configure a model in **AI Settings → Local LLM** for full analysis."

        hdr = ""
        if d:
            sc  = d.get("health_score", 0)
            ic  = "✅" if sc >= 85 else "⚠️" if sc >= 55 else "🔴"
            hdr = (f"{ic} **System Health: {sc}/100 — {d.get('health_label','?')}**  "
                   f"CPU `{d.get('cpu_percent','?')}%`  "
                   f"RAM `{d.get('memory_percent','?')}%`  "
                   f"Disk `{d.get('disk_percent','?')}%`\n\n")
            if d.get("violations"):
                v = d["violations"][0]
                return hdr + f"⚠ **{v.get('severity','').upper()}** — {v.get('message','')}" + tip

        # Specific topics FIRST — before the generic health catch-all
        if any(k in p for k in ("battery", "charge", "power", "plugged")):
            return hdr + "🔋 Battery info requires a live tool call — configure an AI model to check this." + tip

        if any(k in p for k in ("security", "antivirus", "firewall", "virus")):
            return hdr + "🛡 Security check requires a live tool call — configure an AI model." + tip

        if any(k in p for k in ("process", "task", "top process", "cpu usage")):
            if d and d.get("top_processes"):  # snapshot has top_processes
                p0 = d["top_processes"][0]
                return hdr + f"Top process: **{p0['name']}** at {p0['cpu']}% CPU, {p0['mem_mb']} MB RAM." + tip
            return hdr + "Check the **Processes** tab for a live process list." + tip

        cpu  = d.get("cpu_percent", 0)  if d else 0
        mem  = d.get("memory_percent",0) if d else 0
        disk = d.get("disk_percent", 0) if d else 0

        if any(k in p for k in ("cpu", "processor", "slow", "lag")):
            if cpu > 70: return hdr + f"CPU is high at **{cpu}%**. Check the Processes tab." + tip
            return hdr + f"CPU is fine at **{cpu}%**." + tip

        if any(k in p for k in ("memory", "ram")):
            if mem > 75: return hdr + f"Memory is high at **{mem}%**. Close unused apps." + tip
            return hdr + f"Memory is fine at **{mem}%**." + tip

        if any(k in p for k in ("disk", "storage", "space")):
            if disk > 85: return hdr + f"Disk is nearly full at **{disk}%**. Clear temp files." + tip
            return hdr + f"Disk is at **{disk}%** — you have room." + tip

        if any(k in p for k in ("network", "internet", "latency")):
            lat = d.get("network_latency_ms", 0) if d else 0
            if lat > 200: return hdr + f"Network latency is high at **{lat}ms**. Try Reset Network." + tip
            return hdr + f"Network latency is fine at **{lat}ms**." + tip

        # Generic health — last
        if any(k in p for k in ("health", "status", "ok", "fine", "analyze", "check", "how is")):
            if d:
                return hdr + (d.get("health_summary") or "System appears healthy — no issues detected.") + tip

        return (hdr or "") + (
            "⚙ **AI not configured** — go to **AI Settings → Local LLM**, "
            "pick a model (e.g. `llama3.2`), and click Connect."
        )