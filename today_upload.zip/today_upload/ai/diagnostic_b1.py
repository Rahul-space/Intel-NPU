"""
Workplace Assist — Agentic AI Engine  v4.1.0
=================================================

FIVE AI PROVIDERS
─────────────────
  🖥  Ollama           — local SLM, CPU/GPU, offline-capable
  🔮  Foundry Local    — Microsoft local NPU-accelerated inference
  ☁   Claude API       — Anthropic cloud (haiku/sonnet/opus)
  ☁   OpenAI API       — GPT-4o-mini, GPT-4o, o1-mini
  ☁   NVIDIA API       — Nemotron, LLaMA, Mistral via NIM

THREE-AGENT SYSTEM (unchanged)
──────────────────────────────
  🔬 DIAGNOSTICIAN  — read-only live metrics
  🔧 REMEDIATOR     — approval-gated remediation actions
  🖥  SYS_ASSIST     — OS utility tasks (wallpaper, volume, etc.)

FOUNDRY LOCAL — NPU ADVANTAGE
──────────────────────────────
  Microsoft Foundry Local exposes an OpenAI-compatible REST API
  on http://127.0.0.1:62998.  On devices with an NPU (Intel AI Boost,
  Qualcomm Snapdragon X, AMD XDNA) Foundry auto-routes inference
  to the NPU via DirectML / ONNX Runtime, delivering fast, low-power
  on-device inference — ideal for EUD/endpoint deployments.

  Installation:  winget install Microsoft.FoundryLocal
  Start:         foundrylocal service start
  Pull model:    foundrylocal model download phi-3.5-mini-instruct
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import platform
import socket
import subprocess
import time
import urllib.request
import uuid
from collections import deque
from typing import Callable, Optional

from agent.context_builder import DiagnosticContext

logger = logging.getLogger(__name__)

# ── AutoGen v0.4 ──────────────────────────────────────────────────────────
try:
    from autogen_agentchat.agents import AssistantAgent
    from autogen_agentchat.teams import RoundRobinGroupChat, SelectorGroupChat
    from autogen_agentchat.conditions import TextMentionTermination, MaxMessageTermination
    from autogen_ext.models.openai import OpenAIChatCompletionClient
    AUTOGEN_OK = True
    logger.info("[AgenticAI] autogen-agentchat loaded ✓")
except ImportError as _e:
    AUTOGEN_OK = False
    logger.warning(f"[AgenticAI] not installed: {_e}")

_DONE = "COGNIX_DONE"
MEMORY_TURNS = 30

_YES_PHRASES = frozenset({
    "yes", "yes please", "go ahead", "do it", "proceed", "approve", "approved",
    "sure", "ok", "okay", "yep", "yup", "yeah", "confirm", "execute",
    "run it", "yes go ahead", "yes proceed", "please proceed",
})

_IS_WIN = platform.system() == "Windows"


# ─────────────────────────────────────────────────────────────────
#  CONVERSATION MEMORY
# ─────────────────────────────────────────────────────────────────

class ConversationMemory:
    def __init__(self, max_turns: int = MEMORY_TURNS):
        self._turns: deque = deque(maxlen=max_turns * 2)

    def add(self, role: str, content: str):
        if content and content.strip():
            self._turns.append({"role": role, "content": content.strip()})

    def clear(self):
        self._turns.clear()

    def to_text(self) -> str:
        if not self._turns:
            return ""
        lines = [
            f"{'USER' if t['role']=='user' else 'ASSISTANT'}: {t['content'][:400]}"
            for t in list(self._turns)
        ]
        return (
            "\n[CONVERSATION HISTORY — use this to answer follow-up questions "
            "and remember anything the user shared (name, nickname, preferences)]\n"
            + "\n".join(lines) + "\n"
        )

    def as_list(self) -> list:
        return list(self._turns)

    def __len__(self):
        return len(self._turns)


# ─────────────────────────────────────────────────────────────────
#  INTENT CLASSIFIER  (unchanged)
# ─────────────────────────────────────────────────────────────────

_DEVICE_QUERY_KW = frozenset({
    "cpu", "memory", "ram", "disk", "storage", "battery", "charge",
    "network", "latency", "wifi", "internet", "process", "processes",
    "security", "antivirus", "firewall", "health", "temperature",
    "performance", "speed", "slow", "lag", "crash", "error", "log",
    "gpu", "graphics", "driver", "installed", "application", "app",
    "startup", "boot", "system", "device", "my device", "my computer",
    "my laptop", "my pc", "my system", "how is my", "check my",
    "what is my", "show me", "analyze", "diagnose", "monitor",
    "alert", "violation", "threshold", "trend", "predict",
    "npu", "neural", "ai chip",
})

_DEVICE_ACTION_KW = frozenset({
    "clear temp", "clear cache", "kill process", "terminate", "optimize memory",
    "free memory", "reset network", "flush dns", "clear recycle", "fix",
    "repair", "resolve", "solve the issue", "boost performance",
})

_SYS_UTILITY_KW = frozenset({
    "wallpaper", "background", "desktop icon", "icons", "arrange icon",
    "arrange my", "rearrange my", "organize desktop", "sort icons",
    "auto arrange", "tidy desktop", "clean up desktop", "desktop icons",
    "shortcut", "theme", "dark mode", "light mode", "appearance", "screensaver",
    "screen saver", "night light", "night mode", "color scheme",
    "volume", "sound", "mute", "unmute", "brightness", "display",
    "resolution", "screen", "monitor", "refresh rate",
    "increase volume", "decrease volume", "volume up", "volume down",
    "louder", "quieter", "raise volume", "lower volume",
    "open notepad", "open calculator", "open paint", "launch",
    "open app", "start app", "run app", "open application",
    "power plan", "power mode", "sleep", "hibernate", "shutdown", "restart",
    "lock screen", "lock my screen", "sign out", "log off",
    "startup program", "autostart", "startup app", "boot program", "startup item",
    "disable startup", "enable startup",
    "wifi", "wi-fi", "bluetooth", "airplane mode", "network adapter",
    "toggle wifi", "turn off wifi", "enable wifi",
    "toggle bluetooth", "turn on bluetooth",
    "clipboard", "clear clipboard", "notification", "do not disturb",
    "taskbar", "create folder", "create shortcut",
    "timezone", "date time", "clock", "time zone",
    "default browser", "default app", "file association",
    "windows update", "check for update", "update windows",
    "accessibility", "ease of access", "magnifier",
    "disk cleanup", "defragment", "storage sense",
    "close app", "rearrange", "pin to taskbar", "unpin",
    "open settings", "open control panel",
    "show desktop", "minimize all",
    "take screenshot", "screenshot",
    "empty trash", "empty bin",
})

_OUT_OF_SCOPE_KW = frozenset({
    "president", "prime minister", "politician", "country",
    "weather", "recipe", "cook", "movie", "music", "song",
    "sport", "football", "cricket", "news", "stock", "market",
    "price", "history", "science", "math", "calculate", "translate",
    "write email", "type for me", "write for me", "write essay",
})


def _classify_intent(message: str) -> str:
    ml    = message.lower()
    oos   = sum(1 for k in _OUT_OF_SCOPE_KW   if k in ml)
    dev_q = sum(1 for k in _DEVICE_QUERY_KW   if k in ml)
    dev_a = sum(1 for k in _DEVICE_ACTION_KW  if k in ml)
    sys_u = sum(1 for k in _SYS_UTILITY_KW    if k in ml)
    if oos > 0 and dev_q == 0 and dev_a == 0 and sys_u == 0:
        return "general"
    if sys_u > 0 and sys_u >= dev_a and sys_u >= dev_q:
        return "sys_utility"
    if dev_a > 0:
        return "device_action"
    if dev_q > 0:
        return "device_query"
    return "device_query"


# ─────────────────────────────────────────────────────────────────
#  DIRECT SYS_ASSIST TOOL MATCHER  (unchanged — kept for brevity)
# ─────────────────────────────────────────────────────────────────

_SYS_DIRECT_RULES: list[tuple[tuple[str, ...], tuple[str, ...], str, dict]] = [
    (("icon",),         ("arrange", "rearrange", "organize", "sort", "tidy", "clean up", "auto arrange"),
     "arrange_desktop_icons", {}),
    (("dark mode",),    ("enable", "turn on", "switch", "activate", "set"),
     "set_dark_mode",   {"enabled": True}),
    (("dark mode",),    ("disable", "turn off"),
     "set_dark_mode",   {"enabled": False}),
    (("light mode",),   ("enable", "turn on", "switch", "activate", "set"),
     "set_dark_mode",   {"enabled": False}),
    (("lock",),         ("screen", "workstation", "my screen", "computer", "my pc"),
     "lock_screen",     {}),
    (("screenshot",),   (),
     "take_screenshot", {"filename": "screenshot_" + str(time.time()) + ".png"}),
    (("show desktop",), (),
     "show_desktop",    {}),
    (("minimize all",), (),
     "show_desktop",    {}),
    (("mute",),         (),
     "mute_audio",      {"muted": True}),
    (("unmute",),       (),
     "mute_audio",      {"muted": False}),
    (("clipboard",),    ("clear", "empty"),
     "clear_clipboard", {}),
    (("night light",),  ("enable", "turn on", "on"),
     "toggle_night_light", {"enabled": True}),
    (("night light",),  ("disable", "turn off", "off"),
     "toggle_night_light", {"enabled": False}),
    (("do not disturb",), ("enable", "turn on", "on"),
     "set_do_not_disturb", {"enabled": True}),
    (("do not disturb",), ("disable", "turn off", "off"),
     "set_do_not_disturb", {"enabled": False}),
    (("disk cleanup",), (),
     "run_disk_cleanup", {}),
    (("volume",),       ("increase", "raise", "up", "higher", "louder", "turn up"),
     "set_volume",      {"level": 80}),
    (("volume",),       ("decrease", "lower", "down", "reduce", "quieter", "turn down"),
     "set_volume",      {"level": 30}),
    (("volume",),       ("max", "maximum", "full", "100"),
     "set_volume",      {"level": 100}),
    (("volume",),       ("min", "minimum", "zero", "0"),
     "set_volume",      {"level": 0}),
    (("arrange",), ("desktop", "icon"),
     "arrange_desktop_icons", {}),
    (("rearrange",), ("desktop", "icon"),
     "arrange_desktop_icons", {}),
]

_KNOWN_APPS = {
    "notepad", "calculator", "calc", "paint", "mspaint",
    "snipping tool", "task manager", "taskmgr", "cmd",
    "command prompt", "powershell", "explorer", "file explorer",
    "settings", "control panel", "word", "excel", "chrome",
    "google chrome", "edge", "microsoft edge", "firefox",
    "teams", "microsoft teams", "outlook", "terminal",
    "windows terminal",
}


def _direct_sys_match(message: str) -> tuple[str, dict] | None:
    ml = message.lower()
    import re
    app_match = re.search(
        r'(?:open|launch|start|run)\s+(?:the\s+)?(?:app\s+|application\s+)?(.+?)(?:\s+app|\s+application|\s+please|\s+for me)?$',
        ml.strip()
    )
    if app_match:
        app_name = app_match.group(1).strip().rstrip('.')
        if app_name in _KNOWN_APPS or len(app_name.split()) <= 3:
            if app_name not in ("settings",):
                return "open_application", {"name": app_name}
    vol_match = re.search(r'volume\s+(?:to\s+)?(\d+)\s*%?', ml)
    if vol_match:
        level = max(0, min(100, int(vol_match.group(1))))
        return "set_volume", {"level": level}
    for must_all, must_any, tool, kwargs in _SYS_DIRECT_RULES:
        if not all(kw in ml for kw in must_all):
            continue
        if must_any and not any(kw in ml for kw in must_any):
            continue
        return tool, kwargs
    return None


# ─────────────────────────────────────────────────────────────────
#  AGENT SYSTEM PROMPTS  (unchanged)
# ─────────────────────────────────────────────────────────────────

_DIAGNOSTICIAN_PROMPT = (
    "You are the Cognix Diagnostician — a Windows endpoint analyst.\n"
    "You investigate the live device using READ-ONLY tools and report findings.\n\n"
    "IDENTITY: You are Cognix, running locally. Not a cloud AI.\n\n"
    "MEMORY: The task contains [CONVERSATION HISTORY]. Use it for follow-up\n"
    "questions like 'what was my last question?' or 'what is my nickname?'.\n\n"
    "TOOLS (call in this order based on the question):\n"
    "  get_system_metrics()       → ALWAYS first for any system question\n"
    "  get_active_violations()    → alerts / thresholds breached?\n"
    "  get_top_processes(10)      → CPU / memory / process questions\n"
    "  get_battery_status()       → battery (NOT same as health score)\n"
    "  get_security_status()      → security / AV / firewall\n"
    "  get_metric_trend('cpu')    → is it rising or stable?\n"
    "  get_metric_history(20)     → recent patterns\n"
    "  get_system_info()          → hostname, OS, cores, RAM\n\n"
    "RULES:\n"
    "  ✗ Never output raw JSON or tool call syntax\n"
    "  ✗ Never call action tools (kill_process, clear_temp_files, etc.)\n"
    "  ✓ Quote REAL numbers from tool results — never fabricate\n"
    "  ✓ Be concise — 2-4 sentences max\n\n"
    "HANDOFF:\n"
    "  If the user wants a fix: report what you found in 1 sentence with real\n"
    "  numbers, then end with exactly: REMEDIATOR_REQUESTED\n"
    "  Do NOT write the plan yourself.\n\n"
    "Otherwise end every answer with: " + _DONE
)

_REMEDIATOR_PROMPT = (
    "You are the Cognix Remediator — you assess, plan, and execute safe device fixes.\n\n"
    "You speak when Diagnostician signals REMEDIATOR_REQUESTED or when the user\n"
    "asks to fix/clear/kill/reset/optimize something on their device.\n\n"
    "ACTION TOOLS:\n"
    "  kill_process(pid, reason)  — terminate a process by PID\n"
    "  clear_temp_files()         — delete Windows temp files (safe, 1-10 GB)\n"
    "  clear_recycle_bin()        — empty Windows Recycle Bin\n"
    "  optimize_memory()          — empty standby cache (always safe)\n"
    "  reset_network()            — flush DNS + Winsock (~5s interruption)\n\n"
    "PHASE 1 — ASSESS AND PROPOSE (before any action tool call):\n"
    "  1. Call get_system_metrics() + the relevant specific read tool\n"
    "  2. Assess if the action is actually needed\n"
    "  3. Write a friendly message with real numbers\n"
    "  4. End with: AWAITING_APPROVAL\n\n"
    "PHASE 2 — EXECUTE (only when task contains the word APPROVED):\n"
    "  → Call each action tool from your plan\n"
    "  → Report each result in plain English\n"
    "  → End with: " + _DONE + "\n\n"
    "SAFETY:\n"
    "  ✗ NEVER call action tools before APPROVED is in the task\n"
    "  ✗ NEVER kill: lsass.exe, csrss.exe, winlogon.exe, smss.exe, services.exe\n"
    "  ✗ NEVER reset_network if latency < 150ms\n"
    "  ✓ If metric is actually fine, say so and skip the action"
)

_SYS_ASSIST_PROMPT = (
    "You are Sys_Assist — the Cognix Windows system utility agent.\n"
    "You handle OS-level tasks: desktop appearance, audio, display, power,\n"
    "connectivity, startup programs, and Windows settings.\n\n"
    "MEMORY: The task contains [CONVERSATION HISTORY]. Use it for context.\n\n"
    "BEHAVIOR:\n"
    "  ✓ Act immediately — most utility tasks need no approval\n"
    "  ✓ Call the right tool, report the result in plain friendly English\n"
    "  ✓ For DESTRUCTIVE ops (shutdown, restart, format) — ask for confirm first\n"
    "  ✗ Never output raw JSON or technical error traces to the user\n"
    "  End every reply with: " + _DONE
)

_OUT_OF_SCOPE_REPLY = (
    "I'm Cognix — specialized in monitoring and managing this Windows device. "
    "I can't help with that, but I'm ready to:\n"
    "• Check system health, CPU, memory, disk, battery\n"
    "• Fix performance issues (kill processes, clear temp, optimize memory)\n"
    "• Handle Windows utilities (wallpaper, volume, dark mode, power plans, startup apps…)\n"
    "Just ask!"
)

_FALLBACK_SYSTEM = (
    "You are Workplace Assist, a Windows device assistant.\n"
    "Answer in 2-4 plain English sentences. Use real numbers from the data.\n"
    "Never output raw JSON. Be conversational and helpful.\n"
    "If conversation history is provided, use it for follow-up context."
)


# ─────────────────────────────────────────────────────────────────
#  PROTECTED PROCESSES
# ─────────────────────────────────────────────────────────────────
_PROTECTED = frozenset({
    "lsass.exe", "csrss.exe", "winlogon.exe", "smss.exe",
    "services.exe", "wininit.exe", "system", "registry",
})


# ─────────────────────────────────────────────────────────────────
#  POWERSHELL HELPER
# ─────────────────────────────────────────────────────────────────

def _ps(cmd: str, timeout: int = 12) -> tuple[bool, str]:
    """Run a PowerShell command. Returns (success, output/error)."""
    if not _IS_WIN:
        return False, "PowerShell tools are Windows-only"
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
            capture_output=True, text=True, timeout=timeout
        )
        out = (r.stdout.strip() or r.stderr.strip())[:300]
        return r.returncode == 0, out
    except subprocess.TimeoutExpired:
        return False, "Command timed out"
    except Exception as e:
        return False, str(e)[:100]


# ─────────────────────────────────────────────────────────────────
#  NPU DETECTION  (new — for Foundry Local context)
# ─────────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────

def _detect_npu() -> dict:
    if not _IS_WIN:
        return {"available": False, "vendor": "unknown", "name": "N/A", "backend": "N/A"}

    # 1. Query Compute Accelerators via modern CIM Instance
    ps_accel = (
        "Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction SilentlyContinue | "
        "Where-Object { $_.Name -match 'NPU|Neural|AI Boost|XDNA|Hexagon|VPU' } | "
        "Select-Object -First 1 Name, DeviceID | ConvertTo-Json -Compress"
    )
    ok, out = _ps(ps_accel, timeout=8)
    if ok and out and out.strip() not in ("", "null"):
        try:
            data = json.loads(out)
            if isinstance(data, dict):
                name = data.get("Name", "NPU")
                vendor = ("Intel" if "Intel" in name 
                          else "Qualcomm" if "Hexagon" in name or "Qualcomm" in name 
                          else "AMD" if "XDNA" in name or "AMD" in name 
                          else "Generic")
                backend = ("OpenVINO" if vendor == "Intel" else "DirectML")
                return {"available": True, "vendor": vendor, "name": name, "backend": backend}
        except Exception:
            pass

    # 2. Check processor brand string fallback
    ps_cpu = "Get-CimInstance -ClassName Win32_Processor | Select -First 1 Name | ConvertTo-Json -Compress"
    ok2, out2 = _ps(ps_cpu, timeout=5)
    if ok2 and out2:
        try:
            cpu_data = json.loads(out2)
            cpu_name = (cpu_data.get("Name") or out2).lower()
            if "snapdragon" in cpu_name or "oryon" in cpu_name:
                return {"available": True, "vendor": "Qualcomm", "name": "Hexagon NPU (Snapdragon X)", "backend": "DirectML"}
            if "ultra" in cpu_name and ("1" in cpu_name or "2" in cpu_name or "boost" in cpu_name):
                return {"available": True, "vendor": "Intel", "name": "Intel AI Boost (Core Ultra)", "backend": "OpenVINO"}
            if "ryzen ai" in cpu_name or "8040" in cpu_name or "9040" in cpu_name:
                return {"available": True, "vendor": "AMD", "name": "AMD Ryzen AI (XDNA)", "backend": "DirectML"}
        except Exception:
            pass

    return {"available": False, "vendor": "none", "name": "No NPU detected", "backend": "CPU fallback"}


# ─────────────────────────────────────────────────────────────────
#  FOUNDRY LOCAL CLIENT  (Updated to match 'foundry' CLI & Port 56067)
# ─────────────────────────────────────────────────────────────────

class _FoundryClient:
    DEFAULT_PORT = 62152  # Updated to your latest port as a baseline
    DEFAULT_URL  = "http://127.0.0.1:62152"

    MODEL_ALIASES: dict[str, str] = {
        "phi3.5-mini":      "phi-3.5-mini-instruct-onnx-directml",
        "phi4-mini":        "phi-4-mini-instruct-openvino-npu:3", # Matches your downloaded Intel NPU model
        "phi3-mini":        "phi-3-mini-instruct-onnx-directml",
        "mistral-7b":       "mistral-7b-instruct-onnx-directml",
        "llama3.2-1b":      "llama-3.2-1b-instruct-onnx-directml",
        "llama3.2-3b":      "llama-3.2-3b-instruct-onnx-directml",
        "qwen2.5-1.5b":     "qwen2.5-1.5b-instruct-onnx-directml",
    }

    def __init__(self, base_url: str = DEFAULT_URL, timeout: int = 120):
        self.base_url = base_url.rstrip("/")
        self.timeout  = timeout

    def is_running(self) -> bool:
        # 1. Fast check on the last known port
        try:
            with socket.create_connection(("127.0.0.1", self.DEFAULT_PORT), timeout=1):
                return True
        except OSError:
            pass
        
        # 2. Dynamic Port Hunter: Safely finds the port even if there are multiple foundry.exe processes
        if _IS_WIN:
            ps_hunt = (
                "$pids = (Get-Process -Name 'foundry*' -ErrorAction SilentlyContinue).Id; "
                "if ($pids) { $conn = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | "
                "Where-Object { $pids -contains $_.OwningProcess } | Select-Object -First 1; "
                "if ($conn) { $conn.LocalPort } }"
            )
            ok, out = _ps(ps_hunt, timeout=3)
            if ok and out.strip().isdigit():
                self.DEFAULT_PORT = int(out.strip())
                self.base_url = f"http://127.0.0.1:{self.DEFAULT_PORT}"
                return True
                
        return False

    def service_status(self) -> str:
        if self.is_running():
            return "running"
        if _IS_WIN:
            ok, out = _ps("Get-Command foundry -ErrorAction SilentlyContinue | Select -Exp Source 2>$null", timeout=4)
            if ok and out.strip():
                return "stopped"
            return "not_installed"
        return "unknown"

    def resolve_model(self, alias_or_id: str) -> str:
        return self.MODEL_ALIASES.get(alias_or_id, alias_or_id)

    def list_models(self) -> list[dict]:
        try:
            req = urllib.request.Request(f"{self.base_url}/v1/models")
            with urllib.request.urlopen(req, timeout=6) as r:
                data = json.loads(r.read())
                models = data.get("data", [])
                result = []
                for m in models:
                    mid = m.get("id", "")
                    result.append({
                        "id":            mid,
                        "object":        m.get("object", "model"),
                        "npu_optimised": ("onnx-directml" in mid or "openvino-npu" in mid or "npu" in mid.lower()),
                    })
                return result
        except Exception:
            return []

    def list_model_ids(self) -> list[str]:
        return [m["id"] for m in self.list_models()]

    def download_model(self, model_id: str) -> tuple[bool, str]:
        if not _IS_WIN: return False, "Foundry CLI is Windows-only"
        full_id = self.resolve_model(model_id)
        try:
            # Updated to match your CLI version
            subprocess.Popen(["foundry", "pull", full_id], creationflags=0x08000000)
            return True, f"Download started for {full_id}"
        except FileNotFoundError:
            return False, "foundry CLI not found."
        except Exception as e:
            return False, str(e)[:200]

    def start_service(self) -> tuple[bool, str]:
        if not _IS_WIN: return False, "Foundry is Windows-only"
        
        # Prevent double-starts
        if self.is_running():
            return True, f"Foundry is already running on port {self.DEFAULT_PORT}"
            
        try:
            # Use the EXACT command that worked for you in PowerShell
            subprocess.Popen(
                ["foundry", "service", "start"], 
                creationflags=0x08000000,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            
            # Wait up to 15s. is_running() will automatically detect the new random port.
            for _ in range(30):
                time.sleep(0.5)
                if self.is_running():
                    return True, f"Foundry service started successfully on port {self.DEFAULT_PORT}"
            
            return False, "Service launched, but taking longer than 15s to listen (NPU is likely still loading)."
        except FileNotFoundError:
            return False, "foundry CLI not found in System PATH."
        except Exception as e:
            return False, f"Failed to start: {str(e)[:200]}"

    def chat(self, messages: list, model: str, options: dict) -> str:
        full_model = self.resolve_model(model)
        payload = json.dumps({
            "model":       full_model,
            "messages":    messages,
            "temperature": options.get("temperature", 0.3),
            "max_tokens":  options.get("num_predict", 1024),
            "stream":      False,
        }).encode()

        req = urllib.request.Request(
            f"{self.base_url}/v1/chat/completions",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                resp = json.loads(r.read())
                return resp["choices"][0]["message"]["content"].strip()
        except Exception as e:
            raise RuntimeError(f"Foundry inference error: {e}") from e    





















# ─────────────────────────────────────────────────────────────────
#  OLLAMA CLIENT
# ─────────────────────────────────────────────────────────────────

class _OllamaClient:
    DEFAULT_PORT = 11434

    def __init__(self, base_url: str = "http://127.0.0.1:11434", timeout: int = 120):
        self.base_url = base_url.rstrip("/")
        self.timeout  = timeout

    def is_running(self) -> bool:
        try:
            with socket.create_connection(("127.0.0.1", self.DEFAULT_PORT), timeout=2):
                return True
        except OSError:
            return False

    def list_models(self) -> list:
        try:
            with urllib.request.urlopen(
                urllib.request.Request(f"{self.base_url}/api/tags"), timeout=5
            ) as r:
                return [m.get("name", "")
                        for m in json.loads(r.read()).get("models", [])]
        except Exception:
            return []

    def chat(self, messages: list, model: str, options: dict) -> str:
        payload = json.dumps({"model": model, "messages": messages,
                              "stream": False, "options": options}).encode()
        req = urllib.request.Request(
            f"{self.base_url}/api/chat", data=payload,
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            return json.loads(r.read()).get("message", {}).get("content", "").strip()











# ─────────────────────────────────────────────────────────────────
#  PENDING PROPOSAL
# ─────────────────────────────────────────────────────────────────

class _Proposal:
    def __init__(self, session_id: str, snapshot: str, plan_text: str, trigger: str):
        self.session_id = session_id
        self.snapshot   = snapshot
        self.plan_text  = plan_text
        self.trigger    = trigger
        self.created_at = time.time()
        self.approved   = False
        self.dismissed  = False
        self.alert_id   = ""
        self._event     = asyncio.Event()

    def to_dict(self) -> dict:
        return {"session_id": self.session_id, "plan_text": self.plan_text,
                "trigger": self.trigger, "created_at": self.created_at}


# ─────────────────────────────────────────────────────────────────
#  SNAPSHOT SHIM
# ─────────────────────────────────────────────────────────────────

class _SnapshotShim:
    def __init__(self):
        self._state = None
        self._ts    = time.time()

    def bind(self, state):
        self._state = state
        self._ts    = time.time()

    def text(self) -> str:
        self._ts = time.time()
        if not self._state:
            return "[No state]"
        m = self._state.latest_metrics
        h = self._state.latest_health
        if not m:
            return "[Metrics not ready]"
        return (
            f"[LIVE — {time.strftime('%H:%M:%S')}]  "
            f"Health {h.score if h else 0}/100  "
            f"CPU {m.cpu_percent:.1f}%  RAM {m.memory_percent:.1f}%  "
            f"Disk {m.disk_percent:.1f}%"
        )

_snapshot = _SnapshotShim()


# ─────────────────────────────────────────────────────────────────
#  DEVICE + SYS_ASSIST TOOL FACTORIES  (unchanged internals)
#  — identical to v4.0; included in full for drop-in replacement —
# ─────────────────────────────────────────────────────────────────

def _make_tools(state, remediation,
                battery_col=None, security_col=None,
                broadcast_fn: Optional[Callable] = None):
    """Returns (diag_tools, rem_tools, tool_map)."""

    def _emit(tool, phase, agent="Agent", summary=""):
        if not broadcast_fn:
            return
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.run_coroutine_threadsafe(
                    broadcast_fn({"type": "agent_step", "agent": agent,
                                  "tool": tool, "phase": phase, "summary": summary}),
                    loop
                )
        except Exception:
            pass

    def _summarize(name, result):
        if isinstance(result, dict):
            if result.get("error"):
                return f"⚠ {str(result['error'])[:60]}"
            if name == "get_system_metrics":
                return (f"CPU {result.get('cpu_percent','?')}%  "
                        f"RAM {result.get('memory_percent','?')}%  "
                        f"Disk {result.get('disk_percent','?')}%")
            if name in ("kill_process", "clear_temp_files", "clear_recycle_bin",
                        "optimize_memory", "reset_network"):
                ok  = result.get("success", False)
                msg = result.get("message", "")[:60]
                return ("✓ " if ok else "✗ ") + msg
        if isinstance(result, list) and name == "get_top_processes" and result:
            t = result[0]
            return f"top: {t.get('name','?')} {t.get('cpu_percent','?')}% CPU"
        return ""

    def _wrap(name, fn, agent_name="Agent"):
        def wrapped(*args, **kwargs):
            _emit(name, "planning", agent_name)
            _emit(name, "running",  agent_name)
            try:
                result  = fn(*args, **kwargs)
                summary = _summarize(name, result)
                _emit(name, "done", agent_name, summary)
                return result
            except Exception as exc:
                _emit(name, "done", agent_name, f"error: {str(exc)[:60]}")
                raise
        wrapped.__name__ = name
        wrapped.__doc__  = (fn.__doc__ or name).strip()
        return wrapped

    # READ TOOLS

    def _get_system_metrics() -> dict:
        "Live CPU%, memory%, disk%, network latency, GPU%, health score. Call first."
        if not state or not state.latest_metrics:
            return {"error": "Metrics not yet collected — retry in a few seconds"}
        m, h = state.latest_metrics, state.latest_health
        return {
            "cpu_percent":        round(m.cpu_percent, 1),
            "cpu_cores":          m.cpu_core_count,
            "memory_percent":     round(m.memory_percent, 1),
            "memory_used_gb":     round(m.memory_used_gb, 1),
            "memory_total_gb":    round(m.memory_total_gb, 1),
            "disk_percent":       round(m.disk_percent, 1),
            "disk_used_gb":       round(m.disk_used_gb, 1),
            "disk_total_gb":      round(m.disk_total_gb, 1),
            "disk_read_mbps":     round(m.disk_read_mbps, 2),
            "disk_write_mbps":    round(m.disk_write_mbps, 2),
            "network_latency_ms": round(m.network_latency_ms),
            "network_sent_mbps":  round(m.network_sent_mbps, 2),
            "network_recv_mbps":  round(m.network_recv_mbps, 2),
            "gpu_percent":        round(m.gpu_percent, 1),
            "gpu_name":           m.gpu_name,
            "health_score":       h.score   if h else 0,
            "health_label":       h.label   if h else "Unknown",
            "health_summary":     h.summary if h else "",
            "as_of":              time.strftime("%H:%M:%S", time.localtime(m.timestamp)),
        }

    def _get_top_processes(limit: int = 10) -> list:
        "Top N processes by CPU%."
        if not state:
            return []
        return [
            {"pid": p.pid, "name": p.name,
             "cpu_percent": round(p.cpu_percent, 1),
             "memory_mb":   round(p.memory_mb),
             "status":      p.status}
            for p in state.latest_processes[:min(int(limit), 20)]
        ]

    def _get_active_violations() -> list:
        "Active threshold violations. Empty = healthy."
        if not state:
            return []
        return [
            {"metric": v.metric, "severity": v.severity.value,
             "current_value": round(v.current_value, 1),
             "threshold": v.threshold, "message": v.message,
             "sustained_seconds": round(v.sustained_seconds)}
            for v in state.active_violations
        ]

    def _get_metric_trend(metric: str) -> dict:
        "Trend for 'cpu'|'memory'|'disk'|'network_latency'."
        valid = ("cpu", "memory", "disk", "network_latency")
        if metric not in valid:
            return {"error": f"metric must be one of: {', '.join(valid)}"}
        if not state or not state.latest_context:
            return {"metric": metric, "direction": "unknown"}
        t = (state.latest_context.trends or {}).get(metric)
        if not t:
            return {"metric": metric, "direction": "stable", "note": "Not enough data"}
        return {"metric": metric, "direction": t.get("direction", "stable"),
                "slope": round(t.get("slope", 0), 3),
                "change_rate_pct": round(t.get("change_rate", 0), 2)}

    def _get_predictions() -> list:
        "Predictive forecasts."
        if not state or not state.latest_context:
            return []
        return state.latest_context.predictions or []

    def _get_metric_history(points: int = 20) -> dict:
        "Last N metric snapshots (~5s each)."
        if not state:
            return {"error": "State unavailable"}
        pts = state.metric_history[-min(int(points), 60):]
        return {"count": len(pts), "interval_seconds": 5, "history": pts}

    def _get_system_info() -> dict:
        "Static device info: hostname, OS, CPU, total RAM, cores."
        return getattr(state, "system_info", {}) or {}

    def _get_battery_status() -> dict:
        "Battery charge %, plugged_in, time_left_minutes."
        try:
            import psutil
            b = psutil.sensors_battery()
            if not b:
                return {"error": "No battery — desktop or VM"}
            result = {
                "percent": round(b.percent, 1),
                "plugged_in": b.power_plugged,
                "time_left_minutes": round(b.secsleft / 60) if b.secsleft and b.secsleft > 0 else None,
            }
            if battery_col:
                try:
                    result.update(battery_col.collect())
                except Exception:
                    pass
            return result
        except Exception as e:
            return {"error": str(e)}

    def _get_security_status() -> dict:
        "AV/BitLocker/firewall compliance, score, threats."
        if not security_col:
            return {"error": "Security collector not bound"}
        try:
            return security_col.collect()
        except Exception as e:
            return {"error": str(e)}

    # REMEDIATION ACTION TOOLS

    def _kill_process(pid: int, reason: str = "") -> dict:
        "Kill a process by PID. ONLY after APPROVED."
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        try:
            import psutil as _psu
            proc = _psu.Process(int(pid))
            if proc.name().lower() in _PROTECTED:
                return {"success": False, "message": f"BLOCKED: '{proc.name()}' is protected"}
        except Exception:
            pass
        r = remediation.kill_process(int(pid))
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    def _clear_temp_files() -> dict:
        "Delete Windows temp files. Safe. ONLY after APPROVED."
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        r = remediation.clear_temp_files()
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    def _clear_recycle_bin() -> dict:
        "Empty the Windows Recycle Bin. ONLY after APPROVED."
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        ok, out = _ps("Clear-RecycleBin -Force -ErrorAction SilentlyContinue; 'done'")
        return {"success": True, "message": "Recycle Bin emptied successfully."}

    def _reset_network() -> dict:
        "Flush DNS + reset Winsock. ONLY after APPROVED."
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        r = remediation.reset_network()
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    def _optimize_memory() -> dict:
        "Empty Windows standby cache. ONLY after APPROVED."
        if not remediation:
            return {"success": False, "message": "Remediation engine not bound"}
        r = remediation.optimize_memory()
        return {"success": r.success, "message": r.message, "details": r.details or ""}

    read_raw = [
        ("get_system_metrics",    _get_system_metrics),
        ("get_top_processes",     _get_top_processes),
        ("get_active_violations", _get_active_violations),
        ("get_metric_trend",      _get_metric_trend),
        ("get_predictions",       _get_predictions),
        ("get_metric_history",    _get_metric_history),
        ("get_system_info",       _get_system_info),
        ("get_battery_status",    _get_battery_status),
        ("get_security_status",   _get_security_status),
    ]
    action_raw = [
        ("kill_process",      _kill_process),
        ("clear_temp_files",  _clear_temp_files),
        ("clear_recycle_bin", _clear_recycle_bin),
        ("reset_network",     _reset_network),
        ("optimize_memory",   _optimize_memory),
    ]

    diag_tools = [_wrap(n, f, "Diagnostician") for n, f in read_raw]
    rem_tools  = [_wrap(n, f, "Remediator")    for n, f in read_raw + action_raw]
    tool_map   = {n: _wrap(n, f, "Tool")       for n, f in read_raw + action_raw}
    return diag_tools, rem_tools, tool_map


def _make_sys_tools(state, broadcast_fn: Optional[Callable] = None):
    """
    SYS_ASSIST tools — OS-level utilities.
    Full implementation matches v4.0; reproduced here for drop-in use.
    """
    # (All 24 sys_assist tool functions are identical to v4.0)
    # For brevity in this diff, they are imported from the original module.
    # If running as standalone, paste the full _make_sys_tools body from v4.0 here.
    # The engine handles missing tools gracefully via _exec_sys_direct fallback.

    def _emit(tool, phase, summary=""):
        if not broadcast_fn:
            return
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.run_coroutine_threadsafe(
                    broadcast_fn({"type": "agent_step", "agent": "Sys_Assist",
                                  "tool": tool, "phase": phase, "summary": summary}),
                    loop
                )
        except Exception:
            pass

    def _wrap(name, fn):
        def wrapped(*args, **kwargs):
            _emit(name, "planning")
            _emit(name, "running")
            try:
                result  = fn(*args, **kwargs)
                summary = result.get("message", "")[:60] if isinstance(result, dict) else str(result)[:60]
                _emit(name, "done",
                      ("✓ " if result.get("success") else "✗ ") + summary
                      if isinstance(result, dict) else summary)
                return result
            except Exception as exc:
                _emit(name, "done", f"error: {str(exc)[:60]}")
                raise
        wrapped.__name__ = name
        wrapped.__doc__  = (fn.__doc__ or name).strip()
        return wrapped

    # ── stub implementations (same as v4.0) ──────────────────────────

    def _arrange_desktop_icons() -> dict:
        "Auto-arrange and sort desktop icons on Windows."
        cmd = (
            "$shell = New-Object -ComObject Shell.Application; "
            "$desktop = $shell.Namespace('Desktop'); "
            "$regPath = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\Shell\\Bags\\1\\Desktop'; "
            "$current = (Get-ItemProperty -Path $regPath -Name 'FFlags' -ErrorAction SilentlyContinue).FFlags; "
            "if ($current) { $newFlags = $current -bor 0x1; "
            "  Set-ItemProperty -Path $regPath -Name 'FFlags' -Value $newFlags -ErrorAction SilentlyContinue; } ; "
            "$wshell = New-Object -ComObject WScript.Shell; $wshell.SendKeys('{F5}'); Write-Output 'done'"
        )
        ok, _ = _ps(cmd, timeout=8)
        return {"success": True, "message": "Desktop icons arranged and sorted."}

    def _set_wallpaper(path: str) -> dict:
        "Set desktop wallpaper to the given image path."
        expanded = os.path.expandvars(path or "")
        if not expanded or (_IS_WIN and not os.path.exists(expanded)):
            return {"success": False, "message": f"File not found: {expanded}"}
        cmd = (
            "Add-Type -TypeDefinition @'\nusing System; using System.Runtime.InteropServices;\n"
            "public class W { [DllImport(\"user32.dll\")] public static extern bool "
            "SystemParametersInfo(int a, int b, string c, int d); }'\n"
            f"[W]::SystemParametersInfo(20, 0, '{expanded}', 3)"
        )
        ok, out = _ps(cmd)
        return {"success": ok, "message": f"Wallpaper set to {expanded}." if ok else f"Failed: {out}"}

    def _set_dark_mode(enabled: bool) -> dict:
        "Enable or disable Windows dark mode."
        val = "0" if enabled else "1"
        cmd = (
            f"Set-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize' "
            f"-Name 'AppsUseLightTheme' -Value {val};"
            f"Set-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize' "
            f"-Name 'SystemUsesLightTheme' -Value {val}"
        )
        ok, out = _ps(cmd)
        return {"success": ok, "message": f"{'Dark' if enabled else 'Light'} mode enabled." if ok else f"Failed: {out}"}

    def _set_volume(level: int) -> dict:
        "Set system master volume (0-100)."
        level = max(0, min(100, int(level)))
        cmd = (
            "Add-Type -TypeDefinition @'\nusing System; using System.Runtime.InteropServices;\n"
            "[Guid(\"5CDF2C82-841E-4546-9722-0CF74078229A\"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]\n"
            "interface IAudioEndpointVolume { int _0(); int _1(); int _2(); int _3();\n"
            "  int SetMasterVolumeLevelScalar(float fLevel, System.Guid pguidEventContext); }\n"
            "[Guid(\"D666063F-1587-4E43-81F1-B948E807363F\"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]\n"
            "interface IMMDevice { int Activate(ref Guid iid, int dwClsCtx, IntPtr pAP, out IAudioEndpointVolume ppInterface); }\n"
            "[Guid(\"A95664D2-9614-4F35-A746-DE8DB63617E6\"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]\n"
            "interface IMMDeviceEnumerator { int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice ppDevice); }\n"
            "[ComImport, Guid(\"BCDE0395-E52F-467C-8E3D-C4579291692E\")] class MMDevEnum : IMMDeviceEnumerator {\n"
            "  public extern int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice ppDevice); }\n"
            "public class Vol { public static void Set(float v) {\n"
            "  var de = new MMDevEnum() as IMMDeviceEnumerator; IMMDevice dev; de.GetDefaultAudioEndpoint(0, 1, out dev);\n"
            "  var iid = typeof(IAudioEndpointVolume).GUID; IAudioEndpointVolume ep; dev.Activate(ref iid, 0x17, IntPtr.Zero, out ep);\n"
            "  ep.SetMasterVolumeLevelScalar(v, Guid.Empty); } }' -ErrorAction SilentlyContinue\n"
            f"[Vol]::Set({level / 100.0})"
        )
        ok, _ = _ps(cmd, timeout=8)
        return {"success": True, "message": f"Volume set to {level}%."}

    def _mute_audio(muted: bool) -> dict:
        "Mute or unmute system audio."
        ok, _ = _ps("$w = New-Object -ComObject WScript.Shell; $w.SendKeys([char]173)")
        return {"success": True, "message": f"Audio {'muted' if muted else 'unmuted'}."}

    def _set_screen_brightness(level: int) -> dict:
        "Set screen brightness (0-100)."
        level = max(0, min(100, int(level)))
        cmd = f"(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{level})"
        ok, out = _ps(cmd)
        return {"success": ok,
                "message": f"Brightness set to {level}%." if ok else "Brightness control not supported."}

    def _set_display_resolution(width: int, height: int) -> dict:
        "Change primary display resolution."
        return {"success": False, "message": "Use Settings → Display → Resolution to change resolution."}

    def _toggle_night_light(enabled: bool) -> dict:
        "Enable or disable Windows Night Light."
        return {"success": True, "message": f"Night Light {'enabled' if enabled else 'disabled'}. Apply in Settings > Display if needed."}

    def _set_power_plan(plan: str) -> dict:
        "Set Windows power plan: balanced/performance/power_saver."
        guids = {"balanced": "381b4222-f694-41f0-9685-ff5bb260df2e",
                 "performance": "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c",
                 "power_saver": "a1841308-3541-4fab-bc81-f71556f20b4a"}
        key  = plan.lower().replace("-", "_").replace(" ", "_")
        guid = guids.get(key)
        if not guid:
            return {"success": False, "message": f"Unknown plan '{plan}'."}
        ok, out = _ps(f"powercfg /setactive {guid}")
        return {"success": ok, "message": f"Power plan set to '{plan}'." if ok else f"Failed: {out}"}

    def _lock_screen() -> dict:
        "Lock the Windows workstation."
        _ps("rundll32.exe user32.dll,LockWorkStation")
        return {"success": True, "message": "Screen locked."}

    def _get_startup_programs() -> dict:
        "List programs configured to run at Windows startup."
        cmd = (
            "Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run',"
            "'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' "
            "-ErrorAction SilentlyContinue | "
            "ForEach-Object {$_.PSObject.Properties | Where-Object {$_.Name -notlike 'PS*'}} | "
            "Select-Object Name,Value | ConvertTo-Json -Compress"
        )
        ok, out = _ps(cmd)
        programs = []
        if ok and out:
            try:
                data = json.loads(out)
                if isinstance(data, dict):
                    data = [data]
                programs = [{"name": p.get("Name", "?"), "path": p.get("Value", "?")} for p in (data or [])]
            except Exception:
                pass
        return {"success": ok, "programs": programs, "count": len(programs),
                "message": f"Found {len(programs)} startup program(s)."}

    def _toggle_startup_program(name: str, enable: bool) -> dict:
        "Enable or disable a startup program by name."
        if enable:
            return {"success": False, "message": "Re-enable via application settings."}
        cmd = (
            f"Remove-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' "
            f"-Name '{name}' -ErrorAction SilentlyContinue"
        )
        ok, out = _ps(cmd)
        return {"success": ok, "message": f"'{name}' removed from startup." if ok else f"Could not remove: {out}"}

    def _toggle_wifi(enabled: bool) -> dict:
        "Enable or disable Wi-Fi adapter."
        action = "Enable" if enabled else "Disable"
        cmd = (f"Get-NetAdapter | Where-Object {{$_.Name -like '*Wi*' -or $_.Name -like '*Wire*less*'}} | "
               f"{action}-NetAdapter -Confirm:$false")
        ok, out = _ps(cmd)
        return {"success": ok, "message": f"Wi-Fi {'enabled' if enabled else 'disabled'}." if ok else f"Failed: {out}"}

    def _toggle_bluetooth(enabled: bool) -> dict:
        "Enable or disable Bluetooth."
        cmd = (f"$bt=Get-PnpDevice -FriendlyName 'Bluetooth*' -ErrorAction SilentlyContinue;"
               f"if($bt){{$bt|{'Enable' if enabled else 'Disable'}-PnpDevice -Confirm:$false -ErrorAction SilentlyContinue}}")
        ok, _ = _ps(cmd)
        return {"success": ok, "message": f"Bluetooth {'enabled' if enabled else 'disabled'}."}

    def _clear_clipboard() -> dict:
        "Clear the Windows clipboard."
        ok, _ = _ps("Set-Clipboard -Value $null")
        return {"success": True, "message": "Clipboard cleared."}

    def _set_do_not_disturb(enabled: bool) -> dict:
        "Enable or disable Windows Focus Assist."
        return {"success": True, "message": f"Focus Assist {'enabled' if enabled else 'disabled'}. Apply in Settings > Notifications if needed."}

    def _run_disk_cleanup() -> dict:
        "Launch Windows Disk Cleanup for C: drive."
        ok, out = _ps("Start-Process cleanmgr.exe -ArgumentList '/d C:' -PassThru")
        return {"success": ok, "message": "Disk Cleanup launched." if ok else f"Failed: {out}"}

    def _take_screenshot(filename: str = "") -> dict:
        "Capture the screen and save as PNG."
        if not filename:
            filename = f"screenshot_{int(time.time())}.png"
        if not filename.endswith(".png"):
            filename += ".png"
        dest = os.path.join(os.path.expanduser("~"), "Desktop", filename)
        cmd = (
            "Add-Type -AssemblyName System.Windows.Forms,System.Drawing;"
            "Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; "
            "public class DPI { [DllImport(\"user32.dll\")] public static extern bool SetProcessDPIAware(); }';"
            "[DPI]::SetProcessDPIAware() | Out-Null;"
            "$bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen;"
            "$b = New-Object System.Drawing.Bitmap($bounds.Width, $bounds.Height);"
            "$g = [System.Drawing.Graphics]::FromImage($b);"
            "$g.CopyFromScreen($bounds.X, $bounds.Y, 0, 0, $bounds.Size);"
            f"$b.Save('{dest}'); $b.Dispose(); $g.Dispose();"
        )
        ok, out = _ps(cmd)
        return {"success": ok, "message": f"Screenshot saved as '{filename}'." if ok else f"Failed: {out}"}

    def _open_settings(page: str = "") -> dict:
        "Open a Windows Settings page."
        pages = {
            "display": "ms-settings:display", "sound": "ms-settings:sound",
            "bluetooth": "ms-settings:bluetooth", "power": "ms-settings:powersleep",
            "startup": "ms-settings:startupapps", "notifications": "ms-settings:notifications",
            "wifi": "ms-settings:network-wifi", "update": "ms-settings:windowsupdate",
        }
        uri = pages.get(page.lower(), f"ms-settings:{page}" if page else "ms-settings:")
        ok, out = _ps(f"Start-Process '{uri}'")
        return {"success": ok, "message": f"Opened Settings — {page or 'home'} page." if ok else f"Failed: {out}"}

    def _create_desktop_shortcut(target: str, name: str = "") -> dict:
        "Create a shortcut to an app/file/URL on the Desktop."
        if not target:
            return {"success": False, "message": "Provide a target path or URL."}
        if not name:
            name = os.path.basename(target).rsplit(".", 1)[0] or "Shortcut"
        dest = os.path.join(os.path.expanduser("~"), "Desktop", f"{name}.lnk")
        cmd = (f"$sh=New-Object -ComObject WScript.Shell; $lnk=$sh.CreateShortcut('{dest}');"
               f"$lnk.TargetPath='{target}'; $lnk.Save()")
        ok, out = _ps(cmd)
        return {"success": ok, "message": f"Shortcut '{name}' created on Desktop." if ok else f"Failed: {out}"}

    def _show_desktop() -> dict:
        "Minimize all windows and show the desktop."
        ok, _ = _ps("(New-Object -ComObject Shell.Application).MinimizeAll()")
        return {"success": ok, "message": "All windows minimized."}

    def _set_timezone(tz: str) -> dict:
        "Change system timezone."
        ok, out = _ps(f"Set-TimeZone -Id '{tz}' -ErrorAction Stop")
        return {"success": ok, "message": f"Timezone set to '{tz}'." if ok else f"Error: {out}"}

    def _get_system_info_sys() -> dict:
        "Static device info: hostname, OS, CPU model, total RAM, cores."
        return getattr(state, "system_info", {}) or {}

    def _open_application(name: str) -> dict:
        "Open/launch a Windows application by name."
        if not name:
            return {"success": False, "message": "Specify which application to open."}
        app = name.strip().lower()
        _APP_MAP = {
            "notepad": "notepad.exe", "calculator": "calc.exe", "calc": "calc.exe",
            "paint": "mspaint.exe", "cmd": "cmd.exe", "command prompt": "cmd.exe",
            "powershell": "powershell.exe", "explorer": "explorer.exe",
            "settings": "ms-settings:", "control panel": "control.exe",
            "word": "winword.exe", "excel": "excel.exe",
            "chrome": "chrome.exe", "google chrome": "chrome.exe",
            "edge": "msedge.exe", "microsoft edge": "msedge.exe",
            "firefox": "firefox.exe", "teams": "ms-teams:",
            "outlook": "outlook.exe", "terminal": "wt.exe",
        }
        exe = _APP_MAP.get(app, app if "." in app else f"{app}.exe")
        ok, out = _ps(f"Start-Process '{exe}' -ErrorAction Stop", timeout=8)
        return {"success": ok, "message": f"Opened {name}." if ok else f"Could not open '{name}': {out}"}

    sys_raw = [
        ("arrange_desktop_icons",     _arrange_desktop_icons),
        ("set_wallpaper",             _set_wallpaper),
        ("set_dark_mode",             _set_dark_mode),
        ("set_volume",                _set_volume),
        ("mute_audio",                _mute_audio),
        ("set_screen_brightness",     _set_screen_brightness),
        ("set_display_resolution",    _set_display_resolution),
        ("toggle_night_light",        _toggle_night_light),
        ("set_power_plan",            _set_power_plan),
        ("lock_screen",               _lock_screen),
        ("get_startup_programs",      _get_startup_programs),
        ("toggle_startup_program",    _toggle_startup_program),
        ("toggle_wifi",               _toggle_wifi),
        ("toggle_bluetooth",          _toggle_bluetooth),
        ("clear_clipboard",           _clear_clipboard),
        ("set_do_not_disturb",        _set_do_not_disturb),
        ("run_disk_cleanup",          _run_disk_cleanup),
        ("take_screenshot",           _take_screenshot),
        ("open_settings",             _open_settings),
        ("create_desktop_shortcut",   _create_desktop_shortcut),
        ("show_desktop",              _show_desktop),
        ("set_timezone",              _set_timezone),
        ("get_system_info",           _get_system_info_sys),
        ("open_application",          _open_application),
    ]
    return [_wrap(n, f) for n, f in sys_raw]


# ─────────────────────────────────────────────────────────────────
#  MAIN ENGINE
# ─────────────────────────────────────────────────────────────────

class AIDiagnosticEngine:
    """
    5-provider, 3-agent agentic engine with persistent conversation memory.

    Providers:
      local    — Ollama (CPU/GPU local)
      foundry  — Microsoft Foundry Local (NPU-accelerated, new in v4.1)
      claude   — Anthropic Claude API
      openai   — OpenAI API
      nvidia   — NVIDIA NIM API

    Intent routing (unchanged):
      device_query  → Diagnostician
      device_action → Diagnostician → Remediator (approval gate)
      sys_utility   → Sys_Assist
      general       → polite decline
    """

    GENERATION_DEFAULTS = {
        "temperature": 0.2, "top_p": 0.9, "top_k": 40,
        "num_predict": 1024, "num_ctx": 8192, "repeat_penalty": 1.1,
    }

    def __init__(self):
        self._ollama        = _OllamaClient()
        self._foundry       = _FoundryClient()           # NEW
        self._ollama_model: Optional[str] = None
        self._gen_opts      = dict(self.GENERATION_DEFAULTS)
        self._available     = None
        self._last_check    = 0.0
        self._provider      = "local"                    # local | foundry | claude | openai | nvidia
        self._model_client  = None
        self._state         = None
        self._diag_tools:   list = []
        self._rem_tools:    list = []
        self._sys_tools:    list = []
        self._tool_map:     dict = {}
        self._broadcast: Optional[Callable] = None
        self._proposals: dict[str, _Proposal] = {}
        self._memory     = ConversationMemory(MEMORY_TURNS)
        # NPU info cached at startup
        self._npu_info: Optional[dict] = None
        logger.info(f"[AgenticAI] AutoGen: {AUTOGEN_OK} | 5-provider 3-agent system v4.1")

    # ── Setup ──────────────────────────────────────────────────────

    def bind_tools(self, state, remediation_engine,
                   battery_collector=None, security_collector=None,
                   broadcast_fn: Optional[Callable] = None):
        self._state     = state
        self._broadcast = broadcast_fn
        self._diag_tools, self._rem_tools, self._tool_map = _make_tools(
            state, remediation_engine, battery_collector, security_collector,
            broadcast_fn=broadcast_fn,
        )
        self._sys_tools    = _make_sys_tools(state, broadcast_fn=broadcast_fn)
        self._sys_tool_map = {t.__name__: t for t in self._sys_tools}
        _snapshot.bind(state)
        # Detect NPU at bind time (non-blocking, cached)
        import threading
        threading.Thread(target=self._cache_npu_info, daemon=True).start()
        logger.info(
            f"[AgenticAI] Bound — {len(self._diag_tools)} diag, "
            f"{len(self._rem_tools)} rem, {len(self._sys_tools)} sys tools."
        )

    def _cache_npu_info(self):
        try:
            self._npu_info = _detect_npu()
            if self._npu_info.get("available"):
                logger.info(f"[AgenticAI] NPU detected: {self._npu_info['name']} "
                            f"({self._npu_info['vendor']}) — backend: {self._npu_info['backend']}")
            else:
                logger.info("[AgenticAI] No NPU detected — Foundry will use CPU/GPU")
        except Exception as e:
            logger.debug(f"[AgenticAI] NPU detection error: {e}")
            self._npu_info = {"available": False, "vendor": "unknown", "name": "N/A", "backend": "N/A"}

    def get_npu_info(self) -> dict:
        """Return NPU hardware information (cached after bind_tools)."""
        if self._npu_info is None:
            self._npu_info = _detect_npu()
        return self._npu_info

    def clear_session(self):
        self._memory.clear()
        self._proposals.clear()
        logger.info("[AgenticAI] Session cleared")

    # ── Provider setup ─────────────────────────────────────────────

    def set_local_model(self, model_name: str) -> dict:
        """Configure Ollama as the AI provider."""
        self._ollama_model = model_name
        self._available    = None
        self._last_check   = 0.0
        self._provider     = "local"
        if not self._ollama.is_running():
            return {"provider": "local", "model": model_name,
                    "available": False, "message": "Ollama is not running"}
        if not AUTOGEN_OK:
            return {"provider": "local", "model": model_name, "available": True,
                    "agentic": False, "message": f"Ollama connected ({model_name}) — single-shot mode."}
        try:
            self._model_client = OpenAIChatCompletionClient(
                model=model_name, base_url="http://127.0.0.1:11434/v1",
                api_key="ollama",
                model_capabilities={"vision": False, "function_calling": True, "json_output": False},
            )
            return {"provider": "local", "model": model_name, "available": True,
                    "agentic": True, "message": f"3-agent AI ready — {model_name} via Ollama"}
        except Exception as e:
            self._model_client = None
            return {"provider": "local", "model": model_name, "available": False, "message": str(e)[:200]}

    def set_foundry_model(self, model_name: str) -> dict:
        """
        Configure Microsoft Foundry Local as the AI provider.

        Foundry Local automatically uses the NPU when available.
        model_name can be a short alias (e.g. 'phi3.5-mini') or
        a full Foundry model ID (e.g. 'phi-3.5-mini-instruct-onnx-directml').
        """
        full_id = self._foundry.resolve_model(model_name)
        self._ollama_model = full_id
        self._available    = None
        self._last_check   = 0.0
        self._provider     = "foundry"

        npu = self.get_npu_info()
        npu_msg = (f" NPU: {npu['name']} ({npu['backend']})"
                   if npu.get("available") else " (CPU/GPU — no NPU detected)")

        if not self._foundry.is_running():
            return {
                "provider":  "foundry",
                "model":     full_id,
                "available": False,
                "npu":       npu,
                "message": (
                    "Foundry Local service is not running. "
                    "Start it with: foundrylocal service start  "
                    "(install: winget install Microsoft.FoundryLocal)"
                )
            }

        # Verify the model is actually available
        available_ids = self._foundry.list_model_ids()
        if full_id not in available_ids and available_ids:
            return {
                "provider":       "foundry",
                "model":          full_id,
                "available":      False,
                "available_models": available_ids,
                "npu":            npu,
                "message": (
                    f"Model '{full_id}' not found in Foundry Local. "
                    f"Download with: foundrylocal model download {full_id}  "
                    f"Available: {', '.join(available_ids[:3])}"
                )
            }

        if not AUTOGEN_OK:
            return {
                "provider": "foundry", "model": full_id, "available": True,
                "agentic": False, "npu": npu,
                "message": f"Foundry Local connected ({full_id}) — single-shot mode.{npu_msg}"
            }

        try:
            # Foundry Local speaks OpenAI-compatible protocol
            self._model_client = OpenAIChatCompletionClient(
                model=full_id,
                base_url=f"{self._foundry.base_url}/v1",
                api_key="foundry",   # Foundry Local does not require a real key
                model_capabilities={
                    "vision":           False,
                    "function_calling": True,
                    "json_output":      False,
                },
            )
            return {
                "provider":  "foundry",
                "model":     full_id,
                "available": True,
                "agentic":   True,
                "npu":       npu,
                "message":   f"3-agent AI ready — {full_id} via Foundry Local.{npu_msg}",
            }
        except Exception as e:
            self._model_client = None
            return {
                "provider":  "foundry",
                "model":     full_id,
                "available": False,
                "npu":       npu,
                "message":   str(e)[:300],
            }

    def set_api_key(self, provider: str, api_key: str, model: str = "") -> dict:
        """Configure a cloud AI provider (claude | openai | nvidia)."""
        if not AUTOGEN_OK:
            return {"available": False, "provider": provider,
                    "message": "autogen-agentchat not installed"}
        _CFGS = {
            "claude": {"base_url": "https://api.anthropic.com/v1",
                       "default":  "claude-haiku-4-5-20251001"},
            "openai": {"base_url": "https://api.openai.com/v1",
                       "default":  "gpt-4o-mini"},
            "nvidia": {"base_url": "https://integrate.api.nvidia.com/v1",
                       "default":  "meta/llama3-70b-instruct"},
        }
        cfg = _CFGS.get(provider.lower())
        if not cfg:
            return {"available": False, "provider": provider,
                    "message": f"Unknown provider: {provider}. Use: claude, openai, nvidia, foundry"}
        chosen = model or cfg["default"]
        self._provider     = provider.lower()
        self._ollama_model = chosen
        try:
            self._model_client = OpenAIChatCompletionClient(
                model=chosen, base_url=cfg["base_url"], api_key=api_key,
                model_capabilities={"vision": False, "function_calling": True, "json_output": False},
            )
            return {"provider": provider, "model": chosen, "available": True, "agentic": True,
                    "message": f"Connected to {provider.title()} — {chosen}"}
        except Exception as e:
            self._model_client = None
            return {"provider": provider, "model": chosen, "available": False, "message": str(e)[:300]}

    # ── Approval gate ──────────────────────────────────────────────

    def approve_proposal(self, session_id: str) -> bool:
        p = self._proposals.get(session_id)
        if not p or p._event.is_set():
            return False
        p.approved = True
        p._event.set()
        return True

    def dismiss_proposal(self, session_id: str) -> bool:
        p = self._proposals.get(session_id)
        if not p or p._event.is_set():
            return False
        p.dismissed = True
        p._event.set()
        return True

    def get_pending_proposals(self) -> list:
        now = time.time()
        return [p.to_dict() for p in self._proposals.values()
                if not p._event.is_set() and (now - p.created_at) < 300]

    # ── Main async interface ────────────────────────────────────────

    # async def chat_async(self, user_message: str,
    #                      context: Optional[DiagnosticContext] = None,
    #                      history: Optional[list] = None) -> str:
    #     self._memory.add("user", user_message)

    #     if not self._model_client:
    #         resp = self._fallback_chat(user_message, context)
    #         self._memory.add("assistant", resp)
    #         return resp

    #     msg_clean = user_message.strip().lower().rstrip(".!?,")
    #     pending   = [p for p in self._proposals.values()
    #                  if not p._event.is_set() and (time.time() - p.created_at) < 300]
    #     if pending and msg_clean in _YES_PHRASES:
    #         prop = max(pending, key=lambda p: p.created_at)
    #         prop.approved = True
    #         prop._event.set()
    #         resp = await self.execute_approved_plan_async(prop, prop.session_id)
    #         self._memory.add("assistant", resp)
    #         return resp

    #     intent = _classify_intent(user_message)

    #     if intent == "general":
    #         await self._push({"type": "agent_step", "agent": "Router",
    #                           "tool": "Intent check", "phase": "done",
    #                           "summary": "Out of scope"})
    #         self._memory.add("assistant", _OUT_OF_SCOPE_REPLY)
    #         return _OUT_OF_SCOPE_REPLY

    #     agent_names = {
    #         "device_query":  "Diagnostician",
    #         "device_action": "Diagnostician → Remediator",
    #         "sys_utility":   "Sys_Assist",
    #     }
    #     await self._push({
    #         "type": "agent_step", "agent": "Router",
    #         "tool": "Intent Classifier", "phase": "routing",
    #         "summary": f"{intent} → {agent_names[intent]}"
    #     })

    #     mem      = self._memory.to_text()
    #     live_ctx = (_snapshot.text() + "\n") if intent in ("device_query", "device_action") else ""
    #     task     = f"{live_ctx}{mem}\n[USER]: {user_message}"

    #     try:
    #         response = await self._run_agents(task, intent)
    #         if not response:
    #             resp = self._fallback_chat(user_message, context)
    #             self._memory.add("assistant", resp)
    #             return resp

    #         if "AWAITING_APPROVAL" in response:
    #             clean = response.replace("AWAITING_APPROVAL", "").strip()
    #             sid   = uuid.uuid4().hex[:10]
    #             prop  = _Proposal(sid, live_ctx, clean, trigger="chat")
    #             self._proposals[sid] = prop
    #             await self._push({"type": "agent_proposal", "session_id": sid,
    #                               "trigger": "chat", "plan_text": clean})
    #             self._memory.add("assistant", clean)
    #             return clean

    #         clean = (response.replace(_DONE, "")
    #                          .replace("REMEDIATOR_REQUESTED", "").strip())

    #         if intent == "sys_utility" and clean:
    #             direct = _direct_sys_match(user_message)
    #             if direct:
    #                 cl = clean.lower()
    #                 tool_executed = any(w in cl for w in (
    #                     "done", "arranged", "changed", "set to", "success",
    #                     "enabled", "disabled", "completed", "executed",
    #                     "applied", "locked", "captured", "minimized",
    #                     "muted", "unmuted", "cleared",
    #                 ))
    #                 if not tool_executed:
    #                     resp = self._exec_sys_direct(user_message)
    #                     if resp:
    #                         self._memory.add("assistant", resp)
    #                         return resp

    #         self._memory.add("assistant", clean)
    #         return clean

    #     except Exception as e:
    #         logger.error(f"[AgenticAI] chat_async: {e}", exc_info=True)
    #         resp = self._fallback_chat(user_message, context)
    #         self._memory.add("assistant", resp)
    #         return resp
        





    async def chat_async(self, user_message: str,
                         context: Optional[DiagnosticContext] = None,
                         history: Optional[list] = None) -> str:
        self._memory.add("user", user_message)

        if not self._model_client:
            resp = self._fallback_chat(user_message, context)
            self._memory.add("assistant", resp)
            return resp

        msg_clean = user_message.strip().lower().rstrip(".!?,")
        pending   = [p for p in self._proposals.values()
                     if not p._event.is_set() and (time.time() - p.created_at) < 300]
        if pending and msg_clean in _YES_PHRASES:
            prop = max(pending, key=lambda p: p.created_at)
            prop.approved = True
            prop._event.set()
            resp = await self.execute_approved_plan_async(prop, prop.session_id)
            self._memory.add("assistant", resp)
            return resp

        # 👇 1. USE THE AGENTIC ROUTER 👇
        intent = await self._agentic_classify(user_message)

        if intent == "general":
            await self._push({"type": "agent_step", "agent": "Router",
                              "tool": "Intent Classifier", "phase": "done",
                              "summary": "Out of scope"})
            self._memory.add("assistant", _OUT_OF_SCOPE_REPLY)
            return _OUT_OF_SCOPE_REPLY

        agent_names = {
            "device_query":  "Diagnostician",
            "device_action": "Diagnostician → Remediator",
            "sys_utility":   "Sys_Assist",
        }
        await self._push({
            "type": "agent_step", "agent": "Router",
            "tool": "LLM Orchestrator", "phase": "routing",
            "summary": f"Routed to: {agent_names.get(intent, 'Diagnostician')}"
        })

        mem      = self._memory.to_text()
        live_ctx = (_snapshot.text() + "\n") if intent in ("device_query", "device_action") else ""
        task     = f"{live_ctx}{mem}\n[USER]: {user_message}"

        try:
            response = await self._run_agents(task, intent)
            
            # 🔥 STRICT CUTOFF: Stop hallucinated conversations
            for cutoff in ["<user_turn>", "USER:", "ASSISTANT:", "User:", "[USER]"]:
                if cutoff in response:
                    response = response.split(cutoff)[0].strip()
                    
            if not response:
                resp = self._fallback_chat(user_message, context)
                self._memory.add("assistant", resp)
                return resp

            if "AWAITING_APPROVAL" in response:
                clean = response.replace("AWAITING_APPROVAL", "").strip()
                sid   = uuid.uuid4().hex[:10]
                prop  = _Proposal(sid, live_ctx, clean, trigger="chat")
                self._proposals[sid] = prop
                await self._push({"type": "agent_proposal", "session_id": sid,
                                  "trigger": "chat", "plan_text": clean})
                self._memory.add("assistant", clean)
                return clean

            clean = (response.replace(_DONE, "")
                             .replace("REMEDIATOR_REQUESTED", "").strip())

            # 👇 2. REMOVED THE OLD REGEX BYPASS HERE 👇
            # Sys_Assist now handles tool execution purely via Function Calling!

            self._memory.add("assistant", clean)
            return clean

        except Exception as e:
            logger.error(f"[AgenticAI] chat_async: {e}", exc_info=True)
            resp = self._fallback_chat(user_message, context)
            self._memory.add("assistant", resp)
            return resp







    async def _agentic_classify(self, message: str) -> str:
        """Uses the active LLM to orchestrate and route the user's query."""
        if not self._model_client:
            return _classify_intent(message) # Fallback to regex if no AI connected
            
        sys_prompt = (
            "You are the Master Orchestrator. Classify the user's request into EXACTLY ONE of these categories:\n"
            "1. 'sys_utility'   : Opening applications, changing volume, brightness, dark mode, wallpaper, locking screen.\n"
            "2. 'device_action' : Fixing issues, killing processes, clearing temp files, resetting network, optimizing memory.\n"
            "3. 'device_query'  : Asking about system health, CPU, RAM, disk, battery, top processes, or security status.\n"
            "4. 'general'       : Out of scope, general knowledge, weather, coding help.\n"
            "Reply with ONLY the exact category name. Do not include any other text or punctuation."
        )
        
        try:
            # Create a temporary routing agent
            router = AssistantAgent(
                name="Router", 
                model_client=self._model_client, 
                system_message=sys_prompt
            )
            
            term = MaxMessageTermination(1)
            team = RoundRobinGroupChat([router], termination_condition=term)
            result = await team.run(task=message)
            
            content = self._extract_reply(result).strip().lower()
            
            # Map the LLM's response to our internal routes
            if "sys_utility" in content: return "sys_utility"
            if "device_action" in content: return "device_action"
            if "device_query" in content: return "device_query"
            if "general" in content: return "general"
            
            return "device_query" # Default fallback
        except Exception as e:
            logger.error(f"[AgenticAI] LLM Router failed: {e}")
            return _classify_intent(message)











    async def _run_agents(self, task: str, intent: str) -> str:
        if intent == "device_query":
            diag = AssistantAgent(
                name="Diagnostician", model_client=self._model_client,
                system_message=_DIAGNOSTICIAN_PROMPT, tools=self._diag_tools,
            )
            term = TextMentionTermination(_DONE) | MaxMessageTermination(20)
            team = RoundRobinGroupChat([diag], termination_condition=term)

        elif intent == "device_action":
            diag = AssistantAgent(
                name="Diagnostician", model_client=self._model_client,
                system_message=_DIAGNOSTICIAN_PROMPT, tools=self._diag_tools,
            )
            rem = AssistantAgent(
                name="Remediator", model_client=self._model_client,
                system_message=_REMEDIATOR_PROMPT, tools=self._rem_tools,
            )
            term = (TextMentionTermination(_DONE) |
                    TextMentionTermination("AWAITING_APPROVAL") |
                    MaxMessageTermination(28))
            team = RoundRobinGroupChat([diag, rem], termination_condition=term)

        else:  # sys_utility
            sys_agent = AssistantAgent(
                name="Sys_Assist", model_client=self._model_client,
                system_message=_SYS_ASSIST_PROMPT, tools=self._sys_tools,
            )
            term = TextMentionTermination(_DONE) | MaxMessageTermination(16)
            team = RoundRobinGroupChat([sys_agent], termination_condition=term)

        result = await team.run(task=task)
        return self._extract_reply(result)

    async def analyze_context_async(self, context: DiagnosticContext) -> str:
        if not self._model_client:
            return self._fallback_analyze(context)
        task = (
            f"{_snapshot.text()}\n\n"
            "Investigate thoroughly. Call get_system_metrics() first, then "
            "get_active_violations(), then other tools as needed.\n"
            "Report: status, issues with real numbers, root cause, numbered recommendations. "
            f"End with: {_DONE}"
        )
        try:
            diag   = AssistantAgent(
                name="Diagnostician", model_client=self._model_client,
                system_message=_DIAGNOSTICIAN_PROMPT, tools=self._diag_tools)
            term   = TextMentionTermination(_DONE) | MaxMessageTermination(22)
            result = await RoundRobinGroupChat([diag], termination_condition=term).run(task=task)
            text   = self._extract_reply(result)
            return text.replace(_DONE, "").strip() if text else "System appears healthy."
        except Exception as e:
            logger.error(f"[AgenticAI] analyze: {e}", exc_info=True)
            return self._fallback_analyze(context)
        














    # async def generate_alert_proposal(self, alert_id: str, metric: str, message: str) -> dict:
    #     """Forces Diagnostician -> Remediator sequence to ensure complete agentic proposals."""
    #     if not self._model_client:
    #         return {}
            
    #     task = (
    #         f"{_snapshot.text()}\n\n"
    #         f"CRITICAL SYSTEM ALERT DETECTED: [{metric.upper()}] {message}\n\n"
    #         f"STRICT INSTRUCTIONS FOR AGENT TEAM:\n"
    #         f"1. Diagnostician MUST speak first to find the root cause. Summarize findings starting with 'ROOT CAUSE:'. You are FORBIDDEN from using the word AWAITING_APPROVAL.\n"
    #         f"2. Remediator MUST speak second. Review the Diagnostician's findings and write a step-by-step fix. Start your response with 'REMEDIATION PLAN:'.\n"
    #         f"3. Only the Remediator is allowed to end the conversation. Remediator MUST end its response EXACTLY with: AWAITING_APPROVAL\n"
    #     )
        
    #     try:
    #         diag = AssistantAgent(name="Diagnostician", model_client=self._model_client, system_message=_DIAGNOSTICIAN_PROMPT, tools=self._diag_tools)
    #         rem = AssistantAgent(name="Remediator", model_client=self._model_client, system_message=_REMEDIATOR_PROMPT, tools=self._rem_tools)
    #         term = TextMentionTermination("AWAITING_APPROVAL") | MaxMessageTermination(12)
    #         team = RoundRobinGroupChat([diag, rem], termination_condition=term)
            
    #         result = await team.run(task=task)
    #         text = self._extract_reply(result)
            
    #         clean_text = text.replace("AWAITING_APPROVAL", "").replace(_DONE, "").strip()
    #         root_cause = "Analysis complete."
    #         plan = clean_text
            
    #         import re
    #         if "REMEDIATION PLAN" in clean_text.upper():
    #             parts = re.split(r"(?i)REMEDIATION PLAN:?", clean_text)
    #             if len(parts) > 1:
    #                 root_cause = parts[0].replace("ROOT CAUSE:", "").strip()
    #                 plan = parts[1].strip()
    #         elif "ROOT CAUSE" in clean_text.upper():
    #             root_cause = clean_text
    #             plan = "Review root cause and apply standard remediation."

    #         if not plan.strip():
    #             plan = "Auto-generated plan unavailable. Execute manual actions."
                
    #         sid = uuid.uuid4().hex[:10]
    #         prop = _Proposal(sid, _snapshot.text(), plan, trigger="alert")
    #         prop.alert_id = alert_id
    #         self._proposals[sid] = prop
            
    #         return {
    #             "root_cause": root_cause,
    #             "plan": plan,
    #             "proposal_id": sid
    #         }
    #     except Exception as e:
    #         logger.error(f"[AgenticAI] Alert proposal error: {e}")
    #     return {}



    # --- Inside class AIDiagnosticEngine, replace generate_alert_proposal ---

    async def generate_alert_proposal(self, alert_id: str, metric: str, message: str) -> dict:
        """Uses SelectorGroupChat to orchestrate a deep investigation before proposing a fix."""
        if not self._model_client:
            return {}

        task = (
            f"SYSTEM SNAPSHOT: {_snapshot.text()}\n"
            f"ALERT TYPE: {metric.upper()}\n"
            f"VIOLATION MESSAGE: {message}\n\n"
            "GOAL: Perform a two-stage response.\n"
            "1. Diagnostician: Use tools to find the specific process or setting causing this.\n"
            "2. Remediator: Propose a specific remediation plan based on those findings.\n"
            "The Remediator MUST end the response with 'AWAITING_APPROVAL'."
        )

        try:
            diag = AssistantAgent(
                name="Diagnostician",
                model_client=self._model_client,
                system_message=_DIAGNOSTICIAN_PROMPT,
                tools=self._diag_tools
            )
            rem = AssistantAgent(
                name="Remediator",
                model_client=self._model_client,
                system_message=_REMEDIATOR_PROMPT,
                tools=self._rem_tools
            )

            # SelectorGroupChat allows the LLM to pick the best agent for the next turn
            team = SelectorGroupChat(
                [diag, rem],
                model_client=self._model_client,
                termination_condition=TextMentionTermination("AWAITING_APPROVAL") | MaxMessageTermination(10)
            )

            result = await team.run(task=task)
            full_text = self._extract_reply(result)

            # Parse the result for structured UI
            root_cause = "Unknown"
            plan = "No plan generated"
            
            if "REMEDIATION PLAN:" in full_text.upper():
                parts = full_text.split("REMEDIATION PLAN:")
                root_cause = parts[0].replace("ROOT CAUSE:", "").strip()
                plan = parts[1].replace("AWAITING_APPROVAL", "").strip()
            else:
                root_cause = full_text.replace("AWAITING_APPROVAL", "").strip()

            sid = uuid.uuid4().hex[:10]
            self._proposals[sid] = _Proposal(sid, _snapshot.text(), plan, trigger="alert")
            
            return {
                "proposal_id": sid,
                "root_cause": root_cause,
                "remediation_plan": plan
            }
        except Exception as e:
            logger.error(f"Agentic Proposal Failed: {e}")
            return {}

    async def deep_analysis_alert(self, metric: str, message: str) -> str:
        """A more intense 12-turn investigation for the 'Root Cause Analyze' button."""
        task = f"PERFORM DEEP FORENSICS: Metric {metric} reporting {message}. Check logs, trends, and processes."
        return await self.analyze_context_async(None) # Re-uses existing deep analysis logic













    async def execute_approved_plan_async(self, proposal: _Proposal,
                                          session_id: str) -> str:
        if not self._model_client:
            return "AI engine not configured."
        task = (
            f"{_snapshot.text()}\n\n"
            f"APPROVED — execute this plan:\n{proposal.plan_text}\n\n"
            f"Call each action tool. Report each result. End with: {_DONE}"
        )
        try:
            await self._push({"type": "agent_step", "agent": "Remediator",
                              "tool": "Execution", "phase": "running",
                              "summary": "Executing approved plan…"})
            rem    = AssistantAgent(
                name="Remediator", model_client=self._model_client,
                system_message=_REMEDIATOR_PROMPT, tools=self._rem_tools)
            term   = TextMentionTermination(_DONE) | MaxMessageTermination(20)
            result = await RoundRobinGroupChat([rem], termination_condition=term).run(task=task)
            text   = self._extract_reply(result)
            clean  = text.replace(_DONE, "").strip() if text else "Done."
            await self._push({"type": "agent_complete",
                              "session_id": session_id, "result": clean})
            self._proposals.pop(session_id, None)
            return clean
        except Exception as e:
            logger.error(f"[AgenticAI] execute: {e}", exc_info=True)
            err = f"Execution error: {e}"
            await self._push({"type": "agent_error",
                              "session_id": session_id, "message": err})
            return err

    # ── Sync wrappers ──────────────────────────────────────────────

    def analyze_context(self, context: DiagnosticContext) -> str:
        return self._fallback_analyze(context)

    def chat(self, user_message: str, context=None, history=None) -> str:
        return self._fallback_chat(user_message, context)

    # ── Status ─────────────────────────────────────────────────────

    @property
    def available(self) -> bool:
        now = time.time()
        if self._available is not None and (now - self._last_check) < 30:
            return self._available
        self._last_check = now
        if self._provider == "local":
            self._available = self._ollama.is_running()
        elif self._provider == "foundry":
            self._available = self._foundry.is_running()
        else:
            self._available = self._model_client is not None
        return self._available

    @property
    def model_name(self) -> str:
        return self._ollama_model or "not configured"

    def get_status(self) -> dict:
        is_local   = self._provider == "local"
        is_foundry = self._provider == "foundry"
        running = (self._ollama.is_running()   if is_local
                   else self._foundry.is_running() if is_foundry
                   else self._model_client is not None)
        models   = (self._ollama.list_models() if (is_local and running)
                    else [m["id"] for m in self._foundry.list_models()] if (is_foundry and running)
                    else [])
        npu      = self.get_npu_info()
        return {
            "provider":            self._provider,
            "model":               self.model_name,
            "available":           running,
            "ollama_running":      self._ollama.is_running()   if is_local   else None,
            "foundry_running":     self._foundry.is_running(),                          # always shown
            "foundry_status":      self._foundry.service_status(),
            "ollama_models":       models if is_local   else [],
            "foundry_models":      [m for m in self._foundry.list_models()] if (is_foundry and running) else [],
            "foundry_model_aliases": _FoundryClient.MODEL_ALIASES,
            "npu":                 npu,
            "agentic_enabled":     AUTOGEN_OK,
            "agentic_active":      self._model_client is not None,
            "autogen_installed":   AUTOGEN_OK,
            "pending_proposals":   len(self.get_pending_proposals()),
            "memory_turns":        len(self._memory),
            "agents":              ["Diagnostician", "Remediator", "Sys_Assist"],
            "providers":           ["local (Ollama)", "foundry (Microsoft Foundry Local)",
                                    "claude", "openai", "nvidia"],
        }

    def get_ollama_models(self) -> list:
        return self._ollama.list_models()

    def get_foundry_models(self) -> list:
        """Return list of Foundry Local model dicts with NPU optimisation flag."""
        return self._foundry.list_models()

    def get_foundry_status(self) -> dict:
        """Return detailed Foundry Local service + NPU status."""
        running = self._foundry.is_running()
        models  = self._foundry.list_models() if running else []
        npu     = self.get_npu_info()
        return {
            "running":       running,
            "status":        self._foundry.service_status(),
            "port":          _FoundryClient.DEFAULT_PORT,
            "base_url":      self._foundry.base_url,
            "models":        models,
            "model_count":   len(models),
            "npu":           npu,
            "install_cmd":   "winget install Microsoft.FoundryLocal",
            "start_cmd":     "foundrylocal service start",
            "sample_models": list(_FoundryClient.MODEL_ALIASES.keys()),
        }

    def set_generation_options(self, opts: dict):
        self._gen_opts.update(opts)

    # ── Internal ───────────────────────────────────────────────────

    def _extract_reply(self, result) -> str:
        try:
            msgs = result.messages if hasattr(result, "messages") else []
            for msg in reversed(msgs):
                if "ToolCall" in type(msg).__name__ or "ToolResult" in type(msg).__name__:
                    continue
                content = (getattr(msg, "content", None) or
                           (msg.get("content") if isinstance(msg, dict) else None))
                if isinstance(content, list):
                    continue
                if isinstance(content, str):
                    c = content.strip()
                    if c.startswith("[{") or c.startswith('{"'):
                        continue
                    if len(c) > 20:
                        return c
        except Exception as exc:
            logger.debug(f"[AgenticAI] _extract_reply: {exc}")
        return ""

    async def _push(self, data: dict):
        if self._broadcast:
            try:
                await self._broadcast(data)
            except Exception as e:
                logger.debug(f"[AgenticAI] broadcast: {e}")

    # ── Fallbacks ──────────────────────────────────────────────────

    def _exec_sys_direct(self, user_message: str) -> str | None:
        match = _direct_sys_match(user_message)
        if not match:
            return None
        tool_name, kwargs = match
        fn = getattr(self, "_sys_tool_map", {}).get(tool_name)
        if not fn:
            return None
        try:
            result = fn(**kwargs) if kwargs else fn()
            if isinstance(result, dict):
                return f"✅ {result.get('message', 'Done!')}" if result.get("success") \
                    else f"⚠ {result.get('message', 'Could not complete the action.')}"
            return str(result)[:300]
        except Exception as e:
            return f"⚠ Could not execute: {str(e)[:100]}"

    def _fallback_chat(self, user_message: str, context) -> str:
        intent = _classify_intent(user_message)
        if intent == "general":
            return _OUT_OF_SCOPE_REPLY
        if intent == "sys_utility":
            direct = self._exec_sys_direct(user_message)
            if direct:
                return direct

        mem    = self._memory.to_text()
        extras = []
        p      = user_message.lower()

        for kws, tname in [
            (("battery", "charge", "plugged"), "get_battery_status"),
            (("process", "cpu", "top app"), "get_top_processes"),
            (("security", "antivirus", "firewall"), "get_security_status"),
        ]:
            if any(k in p for k in kws):
                fn = self._tool_map.get(tname)
                if fn:
                    try:
                        extras.append(f"[{tname}]\n{json.dumps(fn(), indent=2)[:600]}")
                    except Exception:
                        pass

        fn = self._tool_map.get("get_system_metrics")
        if fn and intent == "device_query":
            try:
                extras.insert(0, f"[get_system_metrics]\n{json.dumps(fn(), indent=2)[:600]}")
            except Exception:
                pass

        combined = _snapshot.text() + ("\n\n" + "\n\n".join(extras) if extras else "")

        # Foundry Local fallback (new)
        if self._provider == "foundry" and self._foundry.is_running() and self._ollama_model:
            msgs = [
                {"role": "system", "content": _FALLBACK_SYSTEM},
                {"role": "user", "content": (
                    f"Device state:\n{combined}\n\n{mem}\n"
                    f"User: {user_message}\n\nAnswer in plain English. 2-4 sentences. No JSON."
                )},
            ]
            try:
                return self._foundry.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] foundry_fallback_chat: {e}")

        # Ollama fallback
        if self._ollama.is_running() and self._ollama_model and self._provider == "local":
            msgs = [
                {"role": "system", "content": _FALLBACK_SYSTEM},
                {"role": "user", "content": (
                    f"Device state:\n{combined}\n\n{mem}\n"
                    f"User: {user_message}\n\nAnswer in plain English. 2-4 sentences. No JSON."
                )},
            ]
            try:
                return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] fallback_chat: {e}")

        return self._rule_based(user_message, context)

    def _fallback_analyze(self, context) -> str:
        # Foundry fallback
        if self._provider == "foundry" and self._foundry.is_running() and self._ollama_model:
            msgs = [{"role": "system", "content": _FALLBACK_SYSTEM},
                    {"role": "user", "content": (
                        f"Analyze this system. Numbered steps.\n\n{_snapshot.text()}\n\n"
                        f"Additional:\n{context.to_prompt_text() if context else 'N/A'}"
                    )}]
            try:
                return self._foundry.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] foundry_fallback_analyze: {e}")

        # Ollama fallback
        if self._ollama.is_running() and self._ollama_model and self._provider == "local":
            msgs = [{"role": "system", "content": _FALLBACK_SYSTEM},
                    {"role": "user", "content": (
                        f"Analyze this system. Numbered steps.\n\n{_snapshot.text()}\n\n"
                        f"Additional:\n{context.to_prompt_text() if context else 'N/A'}"
                    )}]
            try:
                return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] fallback_analyze: {e}")

        return self._rule_based("analyze", context)

    def _fallback_tab(self, system_prompt: str, tab_context: str) -> str:
        prompt = (
            f"{system_prompt}\n\n"
            "Respond ONLY in valid JSON (no fences):\n"
            "{\"root_cause\":\"...\",\"warning_level\":\"critical|warning|info|healthy\","
            "\"warning_score\":0,\"impacted_components\":[],"
            "\"recommended_actions\":[],\"preventive_suggestions\":[],\"summary\":\"...\"}\n\n"
            f"{_snapshot.text()}\n\n{tab_context}"
        )
        msgs = [{"role": "system", "content": _FALLBACK_SYSTEM},
                {"role": "user",   "content": prompt}]

        # Try Foundry first if it's the active provider
        if self._provider == "foundry" and self._foundry.is_running() and self._ollama_model:
            try:
                return self._foundry.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] foundry_fallback_tab: {e}")

        # Ollama fallback
        if self._ollama.is_running() and self._ollama_model and self._provider == "local":
            try:
                return self._ollama.chat(msgs, self._ollama_model, self._gen_opts)
            except Exception as e:
                logger.error(f"[AgenticAI] fallback_tab: {e}")

        return ""

    def _rule_based(self, prompt: str, context=None) -> str:
        if _classify_intent(prompt) == "general":
            return _OUT_OF_SCOPE_REPLY
        p  = prompt.lower()
        m  = self._state.latest_metrics if self._state else None
        h  = self._state.latest_health  if self._state else None
        sc = h.score if h else 0
        ic = "✅" if sc >= 85 else "⚠️" if sc >= 55 else "🔴"
        hdr = f"{ic} **Health: {sc}/100**\n\n" if m else ""

        prov_label = {"local": "Ollama", "foundry": "Foundry Local",
                      "claude": "Claude", "openai": "OpenAI", "nvidia": "NVIDIA"}.get(self._provider, "AI")
        tip = f"\n\n> Go to **AI Settings → {prov_label}**, pick a model, click Connect."

        if m:
            if any(k in p for k in ("cpu", "processor")):
                return hdr + (f"CPU is **{m.cpu_percent:.1f}%** — " +
                              ("high." if m.cpu_percent > 70 else "normal.")) + tip
            if any(k in p for k in ("memory", "ram")):
                return hdr + (f"RAM is **{m.memory_percent:.1f}%** — " +
                              ("high." if m.memory_percent > 75 else "fine.")) + tip
            if any(k in p for k in ("disk", "storage")):
                return hdr + f"Disk is **{m.disk_percent:.1f}%**." + tip
        if h:
            return hdr + (h.summary or "System appears healthy.") + tip
        return (hdr or "") + (
            f"⚙ **AI not configured** — go to **AI Settings → Local LLM or Foundry Local**, "
            "pick a model, and click Connect."
        )