"""
Workplace Assist — Security & Compliance Collector
=======================================================
Checks:
  1. Antivirus status (Windows Security Center WMI + cross-platform fallback)
  2. BitLocker / disk encryption status
  3. Windows Firewall status
  4. Suspicious process detection
  5. Unusual network connections
"""
import logging
import os
import platform
import re
import subprocess
import time
from typing import List

import psutil

logger = logging.getLogger(__name__)

_SUSPICIOUS_NAMES = {
    'mimikatz', 'netcat', 'xmrig', 'minerd', 'cpuminer', 'ethminer',
    'keylogger', 'pwdump', 'gsecdump', 'procdump', 'wce', 'fgdump',
    'metasploit', 'msfconsole', 'backdoor', 'exploit', 'rootkit',
}
_SUSPICIOUS_PATH_PATTERNS = [
    r'\\temp\\', r'/tmp/', r'\\appdata\\local\\temp\\',
    r'\\downloads\\', r'\\desktop\\', r'\\public\\',
]
_TRUSTED = {
    'svchost', 'lsass', 'csrss', 'wininit', 'services', 'explorer',
    'ntoskrnl', 'system', 'smss', 'winlogon', 'dwm', 'audiodg',
    'searchindexer', 'spoolsv', 'taskhost', 'taskhostw',
}
_UNUSUAL_PORTS = {
    4444, 5555, 6666, 7777, 8888, 9999, 31337, 1337,
    12345, 54321, 65535, 4321, 1234, 11211,
}

IS_WINDOWS = platform.system() == 'Windows'


def _run_ps(cmd: str, timeout: int = 8) -> str:
    """Run a PowerShell command, return stdout or '' on failure."""
    if not IS_WINDOWS:
        return ''
    try:
        r = subprocess.run(
            ['powershell', '-NonInteractive', '-NoProfile', '-Command', cmd],
            capture_output=True, text=True, timeout=timeout,creationflags=0x08000000
        )
        return r.stdout.strip()
    except Exception as e:
        logger.debug(f'PS cmd failed: {e}')
        return ''


def _check_antivirus() -> dict:
    """Check antivirus via WMI SecurityCenter2 (Windows) or process scan."""
    result = {
        'enabled': None,
        'products': [],
        'status': 'Unknown',
        'color': 'orange',
        'details': '',
    }
    if IS_WINDOWS:
        out = _run_ps(
            "Get-WmiObject -Namespace root/SecurityCenter2 -Class AntiVirusProduct 2>$null | "
            "Select-Object displayName,productState | ConvertTo-Json -Compress 2>$null"
        )
        if out:
            try:
                import json as _j
                items = _j.loads(out)
                if isinstance(items, dict):
                    items = [items]
                for item in items:
                    name = item.get('displayName', 'Unknown AV')
                    state = item.get('productState', 0)
                    # productState bit 12-13: 0=off, 1=on
                    enabled = bool((state >> 12) & 0xF == 1)
                    result['products'].append({'name': name, 'enabled': enabled})
                if result['products']:
                    any_enabled = any(p['enabled'] for p in result['products'])
                    result['enabled'] = any_enabled
                    result['status'] = 'Active' if any_enabled else 'Disabled'
                    result['color'] = 'green' if any_enabled else 'red'
                    result['details'] = ', '.join(p['name'] for p in result['products'])
            except Exception as e:
                logger.debug(f'AV parse error: {e}')

        if result['enabled'] is None:
            # Fallback: check if Windows Defender is running
            out2 = _run_ps(
                "Get-Service -Name 'WinDefend' -ErrorAction SilentlyContinue | "
                "Select-Object Status | ConvertTo-Json -Compress 2>$null"
            )
            if out2:
                running = 'Running' in out2
                result['enabled'] = running
                result['status'] = 'Windows Defender Active' if running else 'Windows Defender Not Running'
                result['color'] = 'green' if running else 'red'
                result['details'] = 'Windows Defender'
                result['products'] = [{'name': 'Windows Defender', 'enabled': running}]
    else:
        # Linux/macOS: look for known AV processes
        av_procs = ['clamav', 'clamd', 'sophos', 'symantec', 'avast', 'avg',
                    'bitdefender', 'kaspersky', 'malwarebytes']
        found = []
        for p in psutil.process_iter(['name']):
            try:
                n = p.info['name'].lower()
                if any(av in n for av in av_procs):
                    found.append(p.info['name'])
            except Exception:
                pass
        result['enabled'] = bool(found)
        result['status'] = f'Found: {", ".join(found)}' if found else 'No AV detected'
        result['color'] = 'green' if found else 'orange'
        result['products'] = [{'name': n, 'enabled': True} for n in found]

    return result


def _check_bitlocker() -> dict:
    result = {
        'enabled': None,
        'drives': [],
        'status': 'Unknown',
        'color': 'orange',
        'details': '',
    }
    if IS_WINDOWS:
        out = _run_ps(
            "Get-BitLockerVolume 2>$null | "
            "Select-Object MountPoint,VolumeStatus,ProtectionStatus | "
            "ConvertTo-Json -Compress 2>$null"
        )
        if out and out != 'null':
            try:
                import json as _j
                items = _j.loads(out)
                if isinstance(items, dict):
                    items = [items]
                for item in items:
                    mp = item.get('MountPoint', '?')
                    vs = item.get('VolumeStatus', '')
                    ps = item.get('ProtectionStatus', 0)
                    encrypted = (ps == 1)
                    result['drives'].append({
                        'drive': mp, 'status': vs,
                        'protected': encrypted,
                    })
                c_drive = next((d for d in result['drives'] if d['drive'] == 'C:'), None)
                if c_drive:
                    result['enabled'] = c_drive['protected']
                elif result['drives']:
                    result['enabled'] = any(d['protected'] for d in result['drives'])
                result['status'] = 'Enabled' if result['enabled'] else 'Disabled'
                result['color'] = 'green' if result['enabled'] else 'red'
                result['details'] = ', '.join(
                    f"{d['drive']} ({'🔒' if d['protected'] else '🔓'})"
                    for d in result['drives']
                )
            except Exception as e:
                logger.debug(f'BitLocker parse error: {e}')
        else:
            # BitLocker may not be available (Home edition)
            result['status'] = 'Not Available (Home Edition or not configured)'
            result['color'] = 'orange'
            result['enabled'] = False
    else:
        # Linux: check dm-crypt/LUKS
        try:
            out = subprocess.run(['lsblk', '-o', 'NAME,TYPE'], capture_output=True, text=True).stdout
            luks = 'crypt' in out.lower()
            result['enabled'] = luks
            result['status'] = 'LUKS Encryption Active' if luks else 'No disk encryption detected'
            result['color'] = 'green' if luks else 'orange'
        except Exception:
            result['status'] = 'Unable to check (run as root)'
            result['color'] = 'orange'

    return result


def _check_firewall() -> dict:
    result = {
        'enabled': None,
        'profiles': [],
        'status': 'Unknown',
        'color': 'orange',
        'details': '',
    }
    if IS_WINDOWS:
        out = _run_ps(
            "Get-NetFirewallProfile -ErrorAction SilentlyContinue | "
            "Select-Object Name,Enabled | ConvertTo-Json -Compress 2>$null"
        )
        if out:
            try:
                import json as _j
                items = _j.loads(out)
                if isinstance(items, dict):
                    items = [items]
                for item in items:
                    name = item.get('Name', '?')
                    en = item.get('Enabled', False)
                    if isinstance(en, str):
                        en = en.lower() == 'true'
                    result['profiles'].append({'name': name, 'enabled': bool(en)})
                any_enabled = any(p['enabled'] for p in result['profiles'])
                all_enabled = all(p['enabled'] for p in result['profiles'])
                result['enabled'] = any_enabled
                result['status'] = 'All Profiles Active' if all_enabled else \
                                   'Partially Active' if any_enabled else 'Disabled'
                result['color'] = 'green' if all_enabled else 'orange' if any_enabled else 'red'
                result['details'] = ', '.join(
                    f"{p['name']} {'✓' if p['enabled'] else '✗'}"
                    for p in result['profiles']
                )
            except Exception as e:
                logger.debug(f'Firewall parse error: {e}')
    else:
        # Linux: check ufw or iptables
        try:
            out = subprocess.run(['ufw', 'status'], capture_output=True, text=True).stdout.lower()
            active = 'active' in out
            result['enabled'] = active
            result['status'] = 'UFW Active' if active else 'UFW Inactive'
            result['color'] = 'green' if active else 'orange'
        except Exception:
            try:
                out = subprocess.run(['iptables', '-L', '-n'], capture_output=True, text=True).stdout
                result['enabled'] = bool(out)
                result['status'] = 'iptables rules found' if out else 'No firewall detected'
                result['color'] = 'green' if out else 'orange'
            except Exception:
                result['status'] = 'Unable to check'
                result['color'] = 'orange'

    return result


def _check_suspicious_processes() -> List[dict]:
    found = []
    try:
        for p in psutil.process_iter(['pid', 'name', 'exe', 'username', 'cpu_percent']):
            try:
                info = p.info
                name = (info.get('name') or '').lower().rstrip('.exe')
                exe = info.get('exe') or ''
                cpu = info.get('cpu_percent') or 0

                if name in _SUSPICIOUS_NAMES:
                    found.append({
                        'pid': info['pid'], 'name': info.get('name'),
                        'reason': 'Known malicious process name',
                        'risk': 'critical', 'exe': exe, 'cpu': cpu,
                    })
                    continue

                if exe:
                    for pat in _SUSPICIOUS_PATH_PATTERNS:
                        if re.search(pat, exe.lower()):
                            found.append({
                                'pid': info['pid'], 'name': info.get('name'),
                                'reason': f'Running from suspicious path',
                                'risk': 'warning', 'exe': exe[:70], 'cpu': cpu,
                            })
                            break

                if cpu > 85 and name not in _TRUSTED:
                    found.append({
                        'pid': info['pid'], 'name': info.get('name'),
                        'reason': f'Extremely high CPU ({cpu:.1f}%)',
                        'risk': 'warning', 'exe': exe[:70], 'cpu': cpu,
                    })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    except Exception as e:
        logger.warning(f'Process scan error: {e}')
    return found[:10]


def _check_network_anomalies() -> List[dict]:
    found = []
    try:
        for c in psutil.net_connections(kind='inet'):
            if c.status == 'ESTABLISHED' and c.raddr:
                if c.raddr.port in _UNUSUAL_PORTS:
                    pname = 'Unknown'
                    try:
                        if c.pid:
                            pname = psutil.Process(c.pid).name()
                    except Exception:
                        pass
                    found.append({
                        'type': 'Unusual Port Connection',
                        'detail': f'{pname} → {c.raddr.ip}:{c.raddr.port}',
                        'risk': 'warning',
                        'remote': f'{c.raddr.ip}:{c.raddr.port}',
                    })
    except Exception as e:
        logger.debug(f'Network scan: {e}')
    return found[:8]


class SecurityCollector:
    def __init__(self):
        self._cache = {}
        self._cache_ts = 0.0
        self._cache_ttl = 60.0  # refresh every 60s

    def collect(self) -> dict:
        now = time.time()
        if self._cache and (now - self._cache_ts) < self._cache_ttl:
            return self._cache

        av        = _check_antivirus()
        bitlocker = _check_bitlocker()
        firewall  = _check_firewall()
        susp_procs= _check_suspicious_processes()
        net_anom  = _check_network_anomalies()

        # Compliance score (0-100)
        compliance = 100
        issues = []
        recommendations = []

        if av['enabled'] is False:
            compliance -= 35
            issues.append('Antivirus is DISABLED')
            recommendations.append('⚠ Enable antivirus immediately — system is unprotected against malware')
        elif av['enabled'] is None:
            compliance -= 15
            recommendations.append('🔍 Could not verify antivirus status — ensure AV software is installed')

        if bitlocker['enabled'] is False:
            compliance -= 25
            issues.append('Disk encryption is NOT enabled')
            recommendations.append('🔒 Enable BitLocker on C: drive to protect data at rest (Settings → BitLocker)')
        elif bitlocker['enabled'] is None:
            compliance -= 10

        if firewall['enabled'] is False:
            compliance -= 25
            issues.append('Firewall is DISABLED')
            recommendations.append('🛡 Enable Windows Firewall immediately (Settings → Windows Security → Firewall)')
        elif firewall['enabled'] is None:
            compliance -= 8

        if susp_procs:
            deduction = min(len(susp_procs) * 5, 15)
            compliance -= deduction
            recommendations.append(f'🔴 Investigate {len(susp_procs)} suspicious process(es)')

        if net_anom:
            compliance -= min(len(net_anom) * 3, 10)
            recommendations.append(f'🌐 Review {len(net_anom)} unusual network connection(s)')

        compliance = max(0, compliance)

        if not recommendations:
            recommendations.append('✅ All security checks passed — endpoint is well-protected')

        risk_level = 'Secure' if compliance >= 80 else \
                     'Moderate Risk' if compliance >= 50 else \
                     'High Risk'
        risk_color = 'green' if compliance >= 80 else \
                     'orange' if compliance >= 50 else 'red'

        result = {
            'compliance_score': compliance,
            'risk_level':       risk_level,
            'risk_color':       risk_color,
            'issues':           issues,
            'antivirus':        av,
            'bitlocker':        bitlocker,
            'firewall':         firewall,
            'suspicious_processes':  susp_procs,
            'network_anomalies':     net_anom,
            'recommendations':  recommendations,
            'scanned_at':       now,
            'platform':         platform.system(),
        }
        self._cache = result
        self._cache_ts = now
        return result

    def invalidate_cache(self):
        self._cache = {}
        self._cache_ts = 0.0


security_collector = SecurityCollector()
