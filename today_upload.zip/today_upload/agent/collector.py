"""
System metrics collector using psutil.
Gathers CPU, memory, disk, GPU, network, and process data.
"""
import psutil
import platform
import subprocess
import time
from typing import Optional,List
from dataclasses import dataclass, field
import logging
import re
logger = logging.getLogger(__name__)

@dataclass
class SystemMetrics:
    cpu_percent: float = 0.0
    cpu_freq_mhz: float = 0.0
    cpu_core_count: int = 0
    memory_percent: float = 0.0
    memory_used_gb: float = 0.0
    memory_total_gb: float = 0.0
    disk_percent: float = 0.0
    disk_used_gb: float = 0.0
    disk_total_gb: float = 0.0
    disk_read_mbps: float = 0.0
    disk_write_mbps: float = 0.0
    gpu_percent: float = 0.0
    gpu_memory_percent: float = 0.0
    gpu_name: str = "N/A"
    network_sent_mbps: float = 0.0
    network_recv_mbps: float = 0.0
    network_latency_ms: float = 0.0
    # 🔥 NEW FIELDS FOR AGENT CONTEXT
    active_window_name: str = "Unknown"
    active_window_pid: int = 0
    saved_networks_strength: List[dict] = field(default_factory=list) 
    timestamp: float = field(default_factory=time.time)


@dataclass
class ProcessInfo:
    pid: int
    name: str
    cpu_percent: float
    memory_mb: float
    status: str
    username: str
    threads: int
    cpu_bar_color: str = "green"


class MetricsCollector:
    """Collects system performance metrics."""

    def __init__(self):
        self._last_net_io = psutil.net_io_counters()
        self._last_disk_io = psutil.disk_io_counters()
        self._last_io_time = time.time()
        self._gpu_available = self._check_gpu()

    def _check_gpu(self) -> bool:
        try:
            import subprocess
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=2,creationflags=0x08000000
            )
            return result.returncode == 0
        except Exception:
            return False

    def collect(self) -> SystemMetrics:
        metrics = SystemMetrics()
        now = time.time()
        elapsed = now - self._last_io_time

        # CPU
        metrics.cpu_percent = psutil.cpu_percent(interval=None)
        try:
            freq = psutil.cpu_freq()
            metrics.cpu_freq_mhz = freq.current if freq else 0.0
        except Exception:
            metrics.cpu_freq_mhz = 0.0
        metrics.cpu_core_count = psutil.cpu_count(logical=True) or 0

        # Memory
        mem = psutil.virtual_memory()
        metrics.memory_percent = mem.percent
        metrics.memory_used_gb = mem.used / (1024 ** 3)
        metrics.memory_total_gb = mem.total / (1024 ** 3)

        # Disk
        disk = psutil.disk_usage("/")
        metrics.disk_percent = disk.percent
        metrics.disk_used_gb = disk.used / (1024 ** 3)
        metrics.disk_total_gb = disk.total / (1024 ** 3)

        # Disk I/O
        try:
            curr_disk = psutil.disk_io_counters()
            if curr_disk and self._last_disk_io and elapsed > 0:
                read_bytes = curr_disk.read_bytes - self._last_disk_io.read_bytes
                write_bytes = curr_disk.write_bytes - self._last_disk_io.write_bytes
                metrics.disk_read_mbps = max(0, (read_bytes / elapsed) / (1024 ** 2))
                metrics.disk_write_mbps = max(0, (write_bytes / elapsed) / (1024 ** 2))
            self._last_disk_io = curr_disk
        except Exception:
            pass

        # Network
        try:
            curr_net = psutil.net_io_counters()
            if curr_net and self._last_net_io and elapsed > 0:
                sent = curr_net.bytes_sent - self._last_net_io.bytes_sent
                recv = curr_net.bytes_recv - self._last_net_io.bytes_recv
                metrics.network_sent_mbps = max(0, (sent / elapsed) / (1024 ** 2))
                metrics.network_recv_mbps = max(0, (recv / elapsed) / (1024 ** 2))
            self._last_net_io = curr_net
        except Exception:
            pass

        # Network latency (ping local router)
        metrics.network_latency_ms = self._measure_latency()


        # 3. 🔥 CALL THE NEW WIFI SCANNER
        # We use a timer so we don't spam the system with WiFi scans every second 
        # (Scanning WiFi is heavy, so once every 30 seconds is plenty)
        # if not hasattr(self, '_last_wifi_scan') or (now - self._last_wifi_scan > 10):
        #     # This is where the execution happens!
        #     metrics.saved_networks_strength = self._get_saved_and_available_wifi() 
        #     self._last_wifi_scan = now
        #     self._prev_networks = metrics.nearby_networks # Cache it
        # else:
        #     # Use the cached version for intermediate seconds
        #     metrics.nearby_networks = getattr(self, '_prev_networks', [])
        try:
            metrics.saved_networks_strength=self._get_saved_and_available_wifi()
            logger.log("I have use this in collector.py file")
            print(metrics.saved_networks_strength)
        except Exception:
            pass



        # GPU
        if self._gpu_available:
            gpu_data = self._collect_gpu()
            metrics.gpu_percent = gpu_data.get("util", 0.0)
            metrics.gpu_memory_percent = gpu_data.get("mem_pct", 0.0)
            metrics.gpu_name = gpu_data.get("name", "GPU")
        else:
            metrics.gpu_percent = 0.0
            metrics.gpu_name = "N/A"

        self._last_io_time = now
        metrics.timestamp = now
        return metrics

    def _measure_latency(self) -> float:
        """Ping localhost as a baseline latency indicator."""
        try:
            start = time.time()
            # Simple socket connect to measure local stack latency
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.5)
            try:
                s.connect(("8.8.8.8", 53))
            except Exception:
                pass
            s.close()
            return round((time.time() - start) * 1000, 2)
        except Exception:
            return 0.0

    def _collect_gpu(self) -> dict:
        try:
            result = subprocess.run(
                ["nvidia-smi",
                 "--query-gpu=utilization.gpu,memory.used,memory.total,name",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=2,creationflags=0x08000000
            )
            if result.returncode == 0:
                parts = result.stdout.strip().split(",")
                if len(parts) >= 4:
                    util = float(parts[0].strip())
                    mem_used = float(parts[1].strip())
                    mem_total = float(parts[2].strip())
                    name = parts[3].strip()
                    mem_pct = (mem_used / mem_total * 100) if mem_total > 0 else 0
                    return {"util": util, "mem_pct": mem_pct, "name": name}
        except Exception:
            pass
        return {}

    def get_top_processes(self, n: int = 15) -> list[ProcessInfo]:
        """Return top N processes by CPU usage."""
        processes = []
        try:
            for proc in psutil.process_iter(
                ["pid", "name", "cpu_percent", "memory_info", "status", "username", "num_threads"]
            ):
                try:
                    info = proc.info
                    mem_mb = (info["memory_info"].rss / (1024 ** 2)) if info.get("memory_info") else 0
                    cpu = info.get("cpu_percent") or 0.0
                    color = "red" if cpu > 30 else ("orange" if cpu > 10 else ("yellow" if cpu > 5 else "green"))
                    processes.append(ProcessInfo(
                        pid=info["pid"],
                        name=info.get("name", "unknown"),
                        cpu_percent=round(cpu, 1),
                        memory_mb=round(mem_mb, 1),
                        status=info.get("status", "unknown"),
                        username=info.get("username", "") or "",
                        threads=info.get("num_threads", 1) or 1,
                        cpu_bar_color=color,
                    ))
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception:
            pass

        processes.sort(key=lambda p: p.cpu_percent, reverse=True)
        return processes[:n]

    def get_system_info(self) -> dict:
        return {
            "os": platform.system(),
            "os_version": platform.version(),
            "hostname": platform.node(),
            "processor": platform.processor(),
            "cpu_cores": psutil.cpu_count(logical=False),
            "cpu_threads": psutil.cpu_count(logical=True),
            "total_memory_gb": round(psutil.virtual_memory().total / (1024 ** 3), 2),
            "python_version": platform.python_version(),
        }
    

    def _get_saved_and_available_wifi(self) -> list[dict]:
        if platform.system() != "Windows":
            return []

        try:
            # 1. Get ALL SAVED profile names
            profile_cmd = "netsh wlan show profiles"
            profiles_res = subprocess.run(profile_cmd, capture_output=True, text=True, creationflags=0x08000000)
            saved_ssids = re.findall(r"All User Profile\s+:\s+(.*)", profiles_res.stdout)
            saved_ssids = [s.strip() for s in saved_ssids]

            # 2. Get LIVE networks with mode=bssid
            scan_cmd = "netsh wlan show networks mode=bssid"
            scan_res = subprocess.run(scan_cmd, capture_output=True, text=True, creationflags=0x08000000)
            stdout = scan_res.stdout

            available_with_signal = {}
            current_ssid = None

            # 3. Robust Line-by-Line Parsing
            for line in stdout.splitlines():
                line = line.strip()
                
                # Detect new SSID block
                if line.startswith("SSID"):
                    match = re.search(r"SSID \d+ : (.*)", line)
                    current_ssid = match.group(1).strip() if match else None
                    continue
                
                # Detect Signal line within an SSID block
                if current_ssid and line.startswith("Signal"):
                    sig_match = re.search(r"Signal\s+:\s+(\d+)%", line)
                    if sig_match:
                        signal_val = int(sig_match.group(1))
                        # Keep the strongest signal for this SSID
                        if current_ssid not in available_with_signal or signal_val > available_with_signal[current_ssid]:
                            available_with_signal[current_ssid] = signal_val

            # 4. Join and Filter
            switchable_networks = []
            for ssid in saved_ssids:
                # Match saved SSIDs against visible ones (case-insensitive for safety)
                if ssid in available_with_signal:
                    switchable_networks.append({
                        "ssid": ssid,
                        "signal_strength": available_with_signal[ssid],
                    })
            
            # Sort by strongest signal
            switchable_networks.sort(key=lambda x: x['signal_strength'], reverse=True)
            
            return switchable_networks[:5]

        except Exception as e:
            logger.error(f"WiFi parsing error: {e}")
            return []



