class _FoundryClient:
    def __init__(self, base_url: str = "http://127.0.0.1:62998", timeout: int = 120):
        self.base_url = base_url.rstrip("/")
        self.timeout  = timeout

    def is_running(self) -> bool:
        try:
            with socket.create_connection(("127.0.0.1", 62998), timeout=2):
                return True
        except OSError:
            return False

    def list_models(self) -> list:
        try:
            req = urllib.request.Request(f"{self.base_url}/v1/models")
            with urllib.request.urlopen(req, timeout=5) as r:
                data = json.loads(r.read())
                return [m.get("id", "") for m in data.get("data", [])]
        except Exception:
            return []

    def chat(self, messages: list, model: str, options: dict) -> str:
        payload = json.dumps({
            "model": model,
            "messages": messages,
            "temperature": options.get("temperature", 0.3),
            "max_tokens": options.get("num_predict", 512)
        }).encode()

        req = urllib.request.Request(
            f"{self.base_url}/v1/chat/completions",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                resp = json.loads(r.read())
                return resp["choices"][0]["message"]["content"].strip()
        except Exception as e:
            return f"[Foundry Error] {e}"